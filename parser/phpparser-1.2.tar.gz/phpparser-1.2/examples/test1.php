<?php

echo 'Just a test 1';

function abc($a, $b){
   $c;
   $d = 1;
   $c = $a*$b+$d;
   return $c;
}

if ($a > $b) {
    echo "a is bigger than b";
} elseif ($a == $b) {
    echo "a is equal to b";
} else {
    echo "a is smaller than b";
}


for ($i = 1; $i <= 10; $i++) {
    echo $i;
}

?>
