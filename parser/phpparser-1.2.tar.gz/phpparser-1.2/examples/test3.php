<?php

echo 'Just a test 1';

function abc($a, $b){
   $c;
   $d = 1;
   $c = $a*$b+$d;
   $d = (unset) $c;
    throw new Exception('Division by zero.');
   return $c;
}

try{
if ($a < $b) {
    if ($a ==1)
	echo "a is bigger than b";
    echo $a;
    throw new Exception('blabla');
} elseif ($a == $b) {
    echo "a is equal to b";
} else {
    echo "a is smaller than b";
}
} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
    throw $e;
} catch (Exception $e) {
    echo 'Caught exception: ',  $e;
}

$j = 0;
echo $j;

for ($i = 1; $i <= 10; $i++) {
    echo $i;
    $j = $j + $i;
    echo $j;
}

?>
