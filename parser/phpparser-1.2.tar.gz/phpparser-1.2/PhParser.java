import org.homeunix.awap.php.parser.*;

import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import org.antlr.stringtemplate.*;
import java.io.*;
import java.util.*;

public class PhParser {
	public static void main(String[] args) throws Exception {
		int j = 0;

        	if ((args.length == 0) || ((args.length == 1) && (args[0].equals("-dot")))){
	    		System.out.println("Please specify one or more PHP files to be parsed.");
	    		System.exit(1);
        	}

		if (args[0].equals("-dot"))
			j=1;
		else
			j=0;

	        for (int i = j; i < args.length; i++) {
	            String filename = args[i];
		    InputStream is = new FileInputStream(filename);

		try {
			// Create input stream from standard input
		        ANTLRInputStream input = new ANTLRInputStream(is);
		        // Create a lexer attached to that input stream
		        PhpLexer lexer = new PhpLexer(input);
		        // Create a stream of tokens pulled from the lexer
		        CommonTokenStream tokens = new CommonTokenStream(lexer);

		        // Create a parser attached to the token stream
		        PhpParser parser = new PhpParser(tokens);
		        // Invoke the program rule in get return value
		        PhpParser.prog_return r = parser.prog();
		        CommonTree t = (CommonTree)r.getTree();

			System.out.println("*** Printing nodes for file " + filename + "...\n");
		        // If -dot option then generate DOT diagram for AST
		        if ( args.length>0 && args[0].equals("-dot") ) {
			        DOTTreeGenerator gen = new DOTTreeGenerator();
			        StringTemplate st = gen.toDOT(t);
			        System.out.println(st);
			}
		        else {
			        System.out.println("\n\n");
			        int n = t.getChildren().size();
			        System.out.println(n);
		            	for (int m=0; m<n; m++){
		                Tree node = (Tree)t.getChild(m);
		                System.out.println("+++ CHILD " + (m+1) + " +++" + node.toStringTree());
			}
        	}

	        // Walk resulting tree; create treenode stream first
        	CommonTreeNodeStream nodes = new CommonTreeNodeStream(t);
        	// AST nodes have payloads that point into token stream
        	nodes.setTokenStream(tokens);
        	// Create a tree Walker attached to the nodes stream
        	PhpTree walker = new PhpTree(nodes);
        	// Invoke the start symbol, rule program
        	PhpTree.prog_return r1 = walker.prog();

		} catch (FileNotFoundException e) {
      			System.err.println("File not found: " + filename);
                	System.exit(1);
		} catch (Exception e) {
                	System.err.println("Error parsing " + filename);
                	System.err.println(e.getMessage());
                	e.printStackTrace();
                	System.exit(1);
      		}
	}
    }
}

