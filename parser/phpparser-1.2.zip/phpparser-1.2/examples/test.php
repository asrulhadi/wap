<?php

echo 'Just a test';

?>
