<?php
        
    for($i=0; $i<10; $i++){
        echo "aa"; 
        $a=2;
        echo "hello world";
    }


    class c{
	var $x;
      function f(){
     echo "Yo baby!";
        }
    }

    function g(){
	echo "aa"; 
	$a=2;
	for($i=0; $i<10; $i++){
		echo $a;
	}  
    }

    g($a, $b);
?>
