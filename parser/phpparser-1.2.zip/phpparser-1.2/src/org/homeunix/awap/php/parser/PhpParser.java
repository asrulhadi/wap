// $ANTLR 3.2 Sep 23, 2009 12:02:23 /home/iberiam/phpparser-1.2/grammar/Php.g 2010-05-09 19:46:42

package org.homeunix.awap.php.parser; 


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class PhpParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "SEMICOLON", "COMMA", "OPEN_BRACE", "CLOSE_BRACE", "OPEN_SQUARE_BRACE", "CLOSE_SQUARE_BRACE", "OPEN_CURLY_BRACE", "CLOSE_CURLY_BRACE", "ARRAY_ASSIGN", "LOGICAL_OR", "LOGICAL_AND", "CLASS_MEMBER", "INSTANCE_MEMBER", "SUPPRESS_WARNINGS", "QUESTION_MARK", "DOLLAR", "COLON", "DOT", "AMPERSAND", "PIPE", "BANG", "PLUS", "MINUS", "ASTERISK", "PERCENT", "FORWARD_SLASH", "TILDE", "EQUALS", "NEW", "CLONE", "ECHO", "PRINT", "IF", "ELSE", "ELSE_IF", "FOR", "FOR_EACH", "WHILE", "DO", "SWITCH", "CASE", "DEFAULT", "FUNCTION", "BREAK", "CONTINUE", "RETURN", "GLOBAL", "STATIC", "AND", "OR", "XOR", "INSTANCE_OF", "CLASS", "INTERFACE", "Extends", "IMPLEMENTS", "ABSTRACT", "VAR", "CONST", "TRY", "CATCH", "THROW", "DECLARE", "USE", "Modifiers", "ClassDefinition", "Block", "Params", "Apply", "Member", "Reference", "Prefix", "Postfix", "IfExpression", "Label", "Cast", "ForInit", "ForCondition", "ForUpdate", "DeclareList", "Field", "Method", "BodyString", "UnquotedString", "AccessModifier", "Integer", "RequireOperator", "AsignmentOperator", "EqualityOperator", "ComparisionOperator", "ShiftOperator", "PrimitiveType", "IncrementOperator", "Array", "SingleQuotedString", "DoubleQuotedString", "HereDoc", "Real", "Boolean", "FirstBodyString", "MultilineComment", "SinglelineComment", "UnixComment", "Decimal", "Hexadecimal", "Octal", "Digits", "DNum", "Exponent_DNum", "EscapeCharector", "HereDocContents", "Eol", "WhiteSpace", "'final'", "'as'"
    };
    public static final int FUNCTION=46;
    public static final int ARRAY_ASSIGN=12;
    public static final int CLOSE_SQUARE_BRACE=9;
    public static final int Method=85;
    public static final int ForCondition=81;
    public static final int WHILE=41;
    public static final int Array=97;
    public static final int CONST=62;
    public static final int CLONE=33;
    public static final int CASE=44;
    public static final int NEW=32;
    public static final int DO=42;
    public static final int EQUALS=31;
    public static final int Decimal=107;
    public static final int Extends=58;
    public static final int EOF=-1;
    public static final int LOGICAL_AND=14;
    public static final int BREAK=47;
    public static final int DoubleQuotedString=99;
    public static final int Digits=110;
    public static final int SUPPRESS_WARNINGS=17;
    public static final int INSTANCE_OF=55;
    public static final int QUESTION_MARK=18;
    public static final int RETURN=49;
    public static final int WhiteSpace=116;
    public static final int VAR=61;
    public static final int UnixComment=106;
    public static final int OPEN_CURLY_BRACE=10;
    public static final int CLOSE_CURLY_BRACE=11;
    public static final int Member=73;
    public static final int Hexadecimal=108;
    public static final int STATIC=51;
    public static final int SWITCH=43;
    public static final int ELSE=37;
    public static final int PrimitiveType=95;
    public static final int SEMICOLON=4;
    public static final int HereDoc=100;
    public static final int Apply=72;
    public static final int TRY=63;
    public static final int Block=70;
    public static final int ForUpdate=82;
    public static final int EscapeCharector=113;
    public static final int OR=53;
    public static final int BodyString=86;
    public static final int DNum=111;
    public static final int FirstBodyString=103;
    public static final int USE=67;
    public static final int CATCH=64;
    public static final int Params=71;
    public static final int Label=78;
    public static final int THROW=65;
    public static final int SingleQuotedString=98;
    public static final int DOLLAR=19;
    public static final int CLASS=56;
    public static final int T__118=118;
    public static final int CLASS_MEMBER=15;
    public static final int Modifiers=68;
    public static final int T__117=117;
    public static final int IfExpression=77;
    public static final int FOR=39;
    public static final int SinglelineComment=105;
    public static final int ABSTRACT=60;
    public static final int Cast=79;
    public static final int AND=52;
    public static final int DeclareList=83;
    public static final int ComparisionOperator=93;
    public static final int ASTERISK=27;
    public static final int IF=36;
    public static final int Exponent_DNum=112;
    public static final int IncrementOperator=96;
    public static final int IMPLEMENTS=59;
    public static final int ClassDefinition=69;
    public static final int CONTINUE=48;
    public static final int COMMA=5;
    public static final int Prefix=75;
    public static final int TILDE=30;
    public static final int LOGICAL_OR=13;
    public static final int Real=101;
    public static final int PLUS=25;
    public static final int PIPE=23;
    public static final int UnquotedString=87;
    public static final int DOT=21;
    public static final int INSTANCE_MEMBER=16;
    public static final int AsignmentOperator=91;
    public static final int Reference=74;
    public static final int ELSE_IF=38;
    public static final int Postfix=76;
    public static final int Field=84;
    public static final int XOR=54;
    public static final int PERCENT=28;
    public static final int ShiftOperator=94;
    public static final int DEFAULT=45;
    public static final int AccessModifier=88;
    public static final int AMPERSAND=22;
    public static final int BANG=24;
    public static final int CLOSE_BRACE=7;
    public static final int MINUS=26;
    public static final int ForInit=80;
    public static final int PRINT=35;
    public static final int OPEN_SQUARE_BRACE=8;
    public static final int Eol=115;
    public static final int RequireOperator=90;
    public static final int COLON=20;
    public static final int ECHO=34;
    public static final int Boolean=102;
    public static final int Octal=109;
    public static final int HereDocContents=114;
    public static final int DECLARE=66;
    public static final int INTERFACE=57;
    public static final int EqualityOperator=92;
    public static final int GLOBAL=50;
    public static final int MultilineComment=104;
    public static final int FOR_EACH=40;
    public static final int OPEN_BRACE=6;
    public static final int Integer=89;
    public static final int FORWARD_SLASH=29;

    // delegates
    // delegators


        public PhpParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public PhpParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
            this.state.ruleMemo = new HashMap[185+1];
             
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return PhpParser.tokenNames; }
    public String getGrammarFileName() { return "/home/iberiam/phpparser-1.2/grammar/Php.g"; }


    public static class prog_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:139:1: prog : ( statement )* ;
    public final PhpParser.prog_return prog() throws RecognitionException {
        PhpParser.prog_return retval = new PhpParser.prog_return();
        retval.start = input.LT(1);
        int prog_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.statement_return statement1 = null;



        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 1) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:139:6: ( ( statement )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:139:8: ( statement )*
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/Php.g:139:8: ( statement )*
            loop1:
            do {
                int alt1=2;
                alt1 = dfa1.predict(input);
                switch (alt1) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_prog945);
            	    statement1=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement1.getTree());

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 1, prog_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class statement_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:141:1: statement : ( ( simpleStatement )? BodyString | '{' statement '}' -> statement | bracketedBlock | classDefinition | interfaceDefinition | complexStatement | simpleStatement ';' );
    public final PhpParser.statement_return statement() throws RecognitionException {
        PhpParser.statement_return retval = new PhpParser.statement_return();
        retval.start = input.LT(1);
        int statement_StartIndex = input.index();
        CommonTree root_0 = null;

        Token BodyString3=null;
        Token char_literal4=null;
        Token char_literal6=null;
        Token char_literal12=null;
        PhpParser.simpleStatement_return simpleStatement2 = null;

        PhpParser.statement_return statement5 = null;

        PhpParser.bracketedBlock_return bracketedBlock7 = null;

        PhpParser.classDefinition_return classDefinition8 = null;

        PhpParser.interfaceDefinition_return interfaceDefinition9 = null;

        PhpParser.complexStatement_return complexStatement10 = null;

        PhpParser.simpleStatement_return simpleStatement11 = null;


        CommonTree BodyString3_tree=null;
        CommonTree char_literal4_tree=null;
        CommonTree char_literal6_tree=null;
        CommonTree char_literal12_tree=null;
        RewriteRuleTokenStream stream_OPEN_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_CURLY_BRACE");
        RewriteRuleTokenStream stream_CLOSE_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_CURLY_BRACE");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 2) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:142:5: ( ( simpleStatement )? BodyString | '{' statement '}' -> statement | bracketedBlock | classDefinition | interfaceDefinition | complexStatement | simpleStatement ';' )
            int alt3=7;
            alt3 = dfa3.predict(input);
            switch (alt3) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:142:7: ( simpleStatement )? BodyString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:142:7: ( simpleStatement )?
                    int alt2=2;
                    alt2 = dfa2.predict(input);
                    switch (alt2) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: simpleStatement
                            {
                            pushFollow(FOLLOW_simpleStatement_in_statement958);
                            simpleStatement2=simpleStatement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleStatement2.getTree());

                            }
                            break;

                    }

                    BodyString3=(Token)match(input,BodyString,FOLLOW_BodyString_in_statement961); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BodyString3_tree = (CommonTree)adaptor.create(BodyString3);
                    adaptor.addChild(root_0, BodyString3_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:143:7: '{' statement '}'
                    {
                    char_literal4=(Token)match(input,OPEN_CURLY_BRACE,FOLLOW_OPEN_CURLY_BRACE_in_statement969); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_CURLY_BRACE.add(char_literal4);

                    pushFollow(FOLLOW_statement_in_statement971);
                    statement5=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement5.getTree());
                    char_literal6=(Token)match(input,CLOSE_CURLY_BRACE,FOLLOW_CLOSE_CURLY_BRACE_in_statement973); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_CURLY_BRACE.add(char_literal6);



                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 143:25: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:144:7: bracketedBlock
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_bracketedBlock_in_statement985);
                    bracketedBlock7=bracketedBlock();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, bracketedBlock7.getTree());

                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:146:7: classDefinition
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_classDefinition_in_statement998);
                    classDefinition8=classDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, classDefinition8.getTree());

                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:147:7: interfaceDefinition
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_interfaceDefinition_in_statement1006);
                    interfaceDefinition9=interfaceDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, interfaceDefinition9.getTree());

                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:148:7: complexStatement
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_complexStatement_in_statement1014);
                    complexStatement10=complexStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, complexStatement10.getTree());

                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:149:7: simpleStatement ';'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_simpleStatement_in_statement1022);
                    simpleStatement11=simpleStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleStatement11.getTree());
                    char_literal12=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_statement1024); if (state.failed) return retval;

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 2, statement_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class bracketedBlock_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bracketedBlock"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:156:1: bracketedBlock : '{' ( statement )* '}' -> ^( Block ( statement )* ) ;
    public final PhpParser.bracketedBlock_return bracketedBlock() throws RecognitionException {
        PhpParser.bracketedBlock_return retval = new PhpParser.bracketedBlock_return();
        retval.start = input.LT(1);
        int bracketedBlock_StartIndex = input.index();
        CommonTree root_0 = null;

        Token char_literal13=null;
        Token char_literal15=null;
        PhpParser.statement_return statement14 = null;


        CommonTree char_literal13_tree=null;
        CommonTree char_literal15_tree=null;
        RewriteRuleTokenStream stream_OPEN_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_CURLY_BRACE");
        RewriteRuleTokenStream stream_CLOSE_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_CURLY_BRACE");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 3) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:157:5: ( '{' ( statement )* '}' -> ^( Block ( statement )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:157:7: '{' ( statement )* '}'
            {
            char_literal13=(Token)match(input,OPEN_CURLY_BRACE,FOLLOW_OPEN_CURLY_BRACE_in_bracketedBlock1050); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_OPEN_CURLY_BRACE.add(char_literal13);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:157:11: ( statement )*
            loop4:
            do {
                int alt4=2;
                alt4 = dfa4.predict(input);
                switch (alt4) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_bracketedBlock1052);
            	    statement14=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_statement.add(statement14.getTree());

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            char_literal15=(Token)match(input,CLOSE_CURLY_BRACE,FOLLOW_CLOSE_CURLY_BRACE_in_bracketedBlock1055); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLOSE_CURLY_BRACE.add(char_literal15);



            // AST REWRITE
            // elements: statement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 157:26: -> ^( Block ( statement )* )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:157:29: ^( Block ( statement )* )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Block, "Block"), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:157:37: ( statement )*
                while ( stream_statement.hasNext() ) {
                    adaptor.addChild(root_1, stream_statement.nextTree());

                }
                stream_statement.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 3, bracketedBlock_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "bracketedBlock"

    public static class interfaceDefinition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "interfaceDefinition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:160:1: interfaceDefinition : INTERFACE interfaceName= UnquotedString ( interfaceExtends )? OPEN_CURLY_BRACE ( interfaceMember )* CLOSE_CURLY_BRACE -> ^( INTERFACE $interfaceName ( interfaceExtends )? ( interfaceMember )* ) ;
    public final PhpParser.interfaceDefinition_return interfaceDefinition() throws RecognitionException {
        PhpParser.interfaceDefinition_return retval = new PhpParser.interfaceDefinition_return();
        retval.start = input.LT(1);
        int interfaceDefinition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token interfaceName=null;
        Token INTERFACE16=null;
        Token OPEN_CURLY_BRACE18=null;
        Token CLOSE_CURLY_BRACE20=null;
        PhpParser.interfaceExtends_return interfaceExtends17 = null;

        PhpParser.interfaceMember_return interfaceMember19 = null;


        CommonTree interfaceName_tree=null;
        CommonTree INTERFACE16_tree=null;
        CommonTree OPEN_CURLY_BRACE18_tree=null;
        CommonTree CLOSE_CURLY_BRACE20_tree=null;
        RewriteRuleTokenStream stream_INTERFACE=new RewriteRuleTokenStream(adaptor,"token INTERFACE");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleTokenStream stream_OPEN_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_CURLY_BRACE");
        RewriteRuleTokenStream stream_CLOSE_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_CURLY_BRACE");
        RewriteRuleSubtreeStream stream_interfaceMember=new RewriteRuleSubtreeStream(adaptor,"rule interfaceMember");
        RewriteRuleSubtreeStream stream_interfaceExtends=new RewriteRuleSubtreeStream(adaptor,"rule interfaceExtends");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 4) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:161:5: ( INTERFACE interfaceName= UnquotedString ( interfaceExtends )? OPEN_CURLY_BRACE ( interfaceMember )* CLOSE_CURLY_BRACE -> ^( INTERFACE $interfaceName ( interfaceExtends )? ( interfaceMember )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:161:7: INTERFACE interfaceName= UnquotedString ( interfaceExtends )? OPEN_CURLY_BRACE ( interfaceMember )* CLOSE_CURLY_BRACE
            {
            INTERFACE16=(Token)match(input,INTERFACE,FOLLOW_INTERFACE_in_interfaceDefinition1081); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_INTERFACE.add(INTERFACE16);

            interfaceName=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceDefinition1085); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_UnquotedString.add(interfaceName);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:161:46: ( interfaceExtends )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==Extends) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: interfaceExtends
                    {
                    pushFollow(FOLLOW_interfaceExtends_in_interfaceDefinition1087);
                    interfaceExtends17=interfaceExtends();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_interfaceExtends.add(interfaceExtends17.getTree());

                    }
                    break;

            }

            OPEN_CURLY_BRACE18=(Token)match(input,OPEN_CURLY_BRACE,FOLLOW_OPEN_CURLY_BRACE_in_interfaceDefinition1098); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_OPEN_CURLY_BRACE.add(OPEN_CURLY_BRACE18);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:163:9: ( interfaceMember )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==FUNCTION||LA6_0==STATIC||LA6_0==ABSTRACT||LA6_0==CONST||LA6_0==AccessModifier||LA6_0==117) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: interfaceMember
            	    {
            	    pushFollow(FOLLOW_interfaceMember_in_interfaceDefinition1108);
            	    interfaceMember19=interfaceMember();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_interfaceMember.add(interfaceMember19.getTree());

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            CLOSE_CURLY_BRACE20=(Token)match(input,CLOSE_CURLY_BRACE,FOLLOW_CLOSE_CURLY_BRACE_in_interfaceDefinition1119); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLOSE_CURLY_BRACE.add(CLOSE_CURLY_BRACE20);



            // AST REWRITE
            // elements: INTERFACE, interfaceMember, interfaceName, interfaceExtends
            // token labels: interfaceName
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleTokenStream stream_interfaceName=new RewriteRuleTokenStream(adaptor,"token interfaceName",interfaceName);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 165:9: -> ^( INTERFACE $interfaceName ( interfaceExtends )? ( interfaceMember )* )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:165:12: ^( INTERFACE $interfaceName ( interfaceExtends )? ( interfaceMember )* )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(stream_INTERFACE.nextNode(), root_1);

                adaptor.addChild(root_1, stream_interfaceName.nextNode());
                // /home/iberiam/phpparser-1.2/grammar/Php.g:165:39: ( interfaceExtends )?
                if ( stream_interfaceExtends.hasNext() ) {
                    adaptor.addChild(root_1, stream_interfaceExtends.nextTree());

                }
                stream_interfaceExtends.reset();
                // /home/iberiam/phpparser-1.2/grammar/Php.g:165:57: ( interfaceMember )*
                while ( stream_interfaceMember.hasNext() ) {
                    adaptor.addChild(root_1, stream_interfaceMember.nextTree());

                }
                stream_interfaceMember.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 4, interfaceDefinition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "interfaceDefinition"

    public static class interfaceExtends_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "interfaceExtends"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:168:1: interfaceExtends : Extends UnquotedString ( COMMA UnquotedString )* ;
    public final PhpParser.interfaceExtends_return interfaceExtends() throws RecognitionException {
        PhpParser.interfaceExtends_return retval = new PhpParser.interfaceExtends_return();
        retval.start = input.LT(1);
        int interfaceExtends_StartIndex = input.index();
        CommonTree root_0 = null;

        Token Extends21=null;
        Token UnquotedString22=null;
        Token COMMA23=null;
        Token UnquotedString24=null;

        CommonTree Extends21_tree=null;
        CommonTree UnquotedString22_tree=null;
        CommonTree COMMA23_tree=null;
        CommonTree UnquotedString24_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 5) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:169:5: ( Extends UnquotedString ( COMMA UnquotedString )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:169:7: Extends UnquotedString ( COMMA UnquotedString )*
            {
            root_0 = (CommonTree)adaptor.nil();

            Extends21=(Token)match(input,Extends,FOLLOW_Extends_in_interfaceExtends1159); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Extends21_tree = (CommonTree)adaptor.create(Extends21);
            root_0 = (CommonTree)adaptor.becomeRoot(Extends21_tree, root_0);
            }
            UnquotedString22=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceExtends1162); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString22_tree = (CommonTree)adaptor.create(UnquotedString22);
            adaptor.addChild(root_0, UnquotedString22_tree);
            }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:169:31: ( COMMA UnquotedString )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==COMMA) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:169:32: COMMA UnquotedString
            	    {
            	    COMMA23=(Token)match(input,COMMA,FOLLOW_COMMA_in_interfaceExtends1165); if (state.failed) return retval;
            	    UnquotedString24=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceExtends1168); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    UnquotedString24_tree = (CommonTree)adaptor.create(UnquotedString24);
            	    adaptor.addChild(root_0, UnquotedString24_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 5, interfaceExtends_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "interfaceExtends"

    public static class interfaceMember_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "interfaceMember"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:171:1: interfaceMember : ( CONST UnquotedString ( EQUALS atom )? ';' -> ^( CONST UnquotedString ( atom )? ) | ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ';' -> ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition ) );
    public final PhpParser.interfaceMember_return interfaceMember() throws RecognitionException {
        PhpParser.interfaceMember_return retval = new PhpParser.interfaceMember_return();
        retval.start = input.LT(1);
        int interfaceMember_StartIndex = input.index();
        CommonTree root_0 = null;

        Token CONST25=null;
        Token UnquotedString26=null;
        Token EQUALS27=null;
        Token char_literal29=null;
        Token FUNCTION31=null;
        Token UnquotedString32=null;
        Token char_literal34=null;
        PhpParser.atom_return atom28 = null;

        PhpParser.fieldModifier_return fieldModifier30 = null;

        PhpParser.parametersDefinition_return parametersDefinition33 = null;


        CommonTree CONST25_tree=null;
        CommonTree UnquotedString26_tree=null;
        CommonTree EQUALS27_tree=null;
        CommonTree char_literal29_tree=null;
        CommonTree FUNCTION31_tree=null;
        CommonTree UnquotedString32_tree=null;
        CommonTree char_literal34_tree=null;
        RewriteRuleTokenStream stream_FUNCTION=new RewriteRuleTokenStream(adaptor,"token FUNCTION");
        RewriteRuleTokenStream stream_EQUALS=new RewriteRuleTokenStream(adaptor,"token EQUALS");
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleTokenStream stream_CONST=new RewriteRuleTokenStream(adaptor,"token CONST");
        RewriteRuleSubtreeStream stream_atom=new RewriteRuleSubtreeStream(adaptor,"rule atom");
        RewriteRuleSubtreeStream stream_parametersDefinition=new RewriteRuleSubtreeStream(adaptor,"rule parametersDefinition");
        RewriteRuleSubtreeStream stream_fieldModifier=new RewriteRuleSubtreeStream(adaptor,"rule fieldModifier");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 6) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:172:5: ( CONST UnquotedString ( EQUALS atom )? ';' -> ^( CONST UnquotedString ( atom )? ) | ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ';' -> ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==CONST) ) {
                alt10=1;
            }
            else if ( (LA10_0==FUNCTION||LA10_0==STATIC||LA10_0==ABSTRACT||LA10_0==AccessModifier||LA10_0==117) ) {
                alt10=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:172:7: CONST UnquotedString ( EQUALS atom )? ';'
                    {
                    CONST25=(Token)match(input,CONST,FOLLOW_CONST_in_interfaceMember1186); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONST.add(CONST25);

                    UnquotedString26=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceMember1188); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString26);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:172:28: ( EQUALS atom )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==EQUALS) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:172:29: EQUALS atom
                            {
                            EQUALS27=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_interfaceMember1191); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EQUALS.add(EQUALS27);

                            pushFollow(FOLLOW_atom_in_interfaceMember1193);
                            atom28=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_atom.add(atom28.getTree());

                            }
                            break;

                    }

                    char_literal29=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_interfaceMember1197); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal29);



                    // AST REWRITE
                    // elements: atom, CONST, UnquotedString
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 173:9: -> ^( CONST UnquotedString ( atom )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:173:12: ^( CONST UnquotedString ( atom )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_CONST.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_UnquotedString.nextNode());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:173:35: ( atom )?
                        if ( stream_atom.hasNext() ) {
                            adaptor.addChild(root_1, stream_atom.nextTree());

                        }
                        stream_atom.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:174:7: ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ';'
                    {
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:174:7: ( fieldModifier )*
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( (LA9_0==STATIC||LA9_0==ABSTRACT||LA9_0==AccessModifier||LA9_0==117) ) {
                            alt9=1;
                        }


                        switch (alt9) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: fieldModifier
                    	    {
                    	    pushFollow(FOLLOW_fieldModifier_in_interfaceMember1225);
                    	    fieldModifier30=fieldModifier();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_fieldModifier.add(fieldModifier30.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop9;
                        }
                    } while (true);

                    FUNCTION31=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_interfaceMember1228); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FUNCTION.add(FUNCTION31);

                    UnquotedString32=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceMember1230); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString32);

                    pushFollow(FOLLOW_parametersDefinition_in_interfaceMember1232);
                    parametersDefinition33=parametersDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parametersDefinition.add(parametersDefinition33.getTree());
                    char_literal34=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_interfaceMember1234); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal34);



                    // AST REWRITE
                    // elements: UnquotedString, fieldModifier, parametersDefinition
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 175:9: -> ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:175:12: ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Method, "Method"), root_1);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:175:21: ^( Modifiers ( fieldModifier )* )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Modifiers, "Modifiers"), root_2);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:175:33: ( fieldModifier )*
                        while ( stream_fieldModifier.hasNext() ) {
                            adaptor.addChild(root_2, stream_fieldModifier.nextTree());

                        }
                        stream_fieldModifier.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_UnquotedString.nextNode());
                        adaptor.addChild(root_1, stream_parametersDefinition.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 6, interfaceMember_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "interfaceMember"

    public static class classDefinition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classDefinition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:178:1: classDefinition : ( classModifier )? CLASS className= UnquotedString ( Extends extendsclass= UnquotedString )? ( classImplements )? OPEN_CURLY_BRACE ( classMember )* CLOSE_CURLY_BRACE -> ^( CLASS ^( Modifiers ( classModifier )? ) $className ( ^( Extends $extendsclass) )? ( classImplements )? ( classMember )* ) ;
    public final PhpParser.classDefinition_return classDefinition() throws RecognitionException {
        PhpParser.classDefinition_return retval = new PhpParser.classDefinition_return();
        retval.start = input.LT(1);
        int classDefinition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token className=null;
        Token extendsclass=null;
        Token CLASS36=null;
        Token Extends37=null;
        Token OPEN_CURLY_BRACE39=null;
        Token CLOSE_CURLY_BRACE41=null;
        PhpParser.classModifier_return classModifier35 = null;

        PhpParser.classImplements_return classImplements38 = null;

        PhpParser.classMember_return classMember40 = null;


        CommonTree className_tree=null;
        CommonTree extendsclass_tree=null;
        CommonTree CLASS36_tree=null;
        CommonTree Extends37_tree=null;
        CommonTree OPEN_CURLY_BRACE39_tree=null;
        CommonTree CLOSE_CURLY_BRACE41_tree=null;
        RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
        RewriteRuleTokenStream stream_Extends=new RewriteRuleTokenStream(adaptor,"token Extends");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleTokenStream stream_OPEN_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_CURLY_BRACE");
        RewriteRuleTokenStream stream_CLOSE_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_CURLY_BRACE");
        RewriteRuleSubtreeStream stream_classModifier=new RewriteRuleSubtreeStream(adaptor,"rule classModifier");
        RewriteRuleSubtreeStream stream_classMember=new RewriteRuleSubtreeStream(adaptor,"rule classMember");
        RewriteRuleSubtreeStream stream_classImplements=new RewriteRuleSubtreeStream(adaptor,"rule classImplements");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 7) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:179:5: ( ( classModifier )? CLASS className= UnquotedString ( Extends extendsclass= UnquotedString )? ( classImplements )? OPEN_CURLY_BRACE ( classMember )* CLOSE_CURLY_BRACE -> ^( CLASS ^( Modifiers ( classModifier )? ) $className ( ^( Extends $extendsclass) )? ( classImplements )? ( classMember )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:179:9: ( classModifier )? CLASS className= UnquotedString ( Extends extendsclass= UnquotedString )? ( classImplements )? OPEN_CURLY_BRACE ( classMember )* CLOSE_CURLY_BRACE
            {
            // /home/iberiam/phpparser-1.2/grammar/Php.g:179:9: ( classModifier )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==ABSTRACT) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: classModifier
                    {
                    pushFollow(FOLLOW_classModifier_in_classDefinition1278);
                    classModifier35=classModifier();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_classModifier.add(classModifier35.getTree());

                    }
                    break;

            }

            CLASS36=(Token)match(input,CLASS,FOLLOW_CLASS_in_classDefinition1290); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLASS.add(CLASS36);

            className=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classDefinition1294); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_UnquotedString.add(className);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:181:9: ( Extends extendsclass= UnquotedString )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==Extends) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:181:10: Extends extendsclass= UnquotedString
                    {
                    Extends37=(Token)match(input,Extends,FOLLOW_Extends_in_classDefinition1306); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_Extends.add(Extends37);

                    extendsclass=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classDefinition1310); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(extendsclass);


                    }
                    break;

            }

            // /home/iberiam/phpparser-1.2/grammar/Php.g:182:9: ( classImplements )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==IMPLEMENTS) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: classImplements
                    {
                    pushFollow(FOLLOW_classImplements_in_classDefinition1323);
                    classImplements38=classImplements();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_classImplements.add(classImplements38.getTree());

                    }
                    break;

            }

            OPEN_CURLY_BRACE39=(Token)match(input,OPEN_CURLY_BRACE,FOLLOW_OPEN_CURLY_BRACE_in_classDefinition1334); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_OPEN_CURLY_BRACE.add(OPEN_CURLY_BRACE39);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:184:9: ( classMember )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==DOLLAR||LA14_0==FUNCTION||LA14_0==STATIC||(LA14_0>=ABSTRACT && LA14_0<=CONST)||LA14_0==AccessModifier||LA14_0==117) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: classMember
            	    {
            	    pushFollow(FOLLOW_classMember_in_classDefinition1344);
            	    classMember40=classMember();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_classMember.add(classMember40.getTree());

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            CLOSE_CURLY_BRACE41=(Token)match(input,CLOSE_CURLY_BRACE,FOLLOW_CLOSE_CURLY_BRACE_in_classDefinition1355); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLOSE_CURLY_BRACE.add(CLOSE_CURLY_BRACE41);



            // AST REWRITE
            // elements: Extends, classImplements, classModifier, CLASS, extendsclass, classMember, className
            // token labels: className, extendsclass
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleTokenStream stream_className=new RewriteRuleTokenStream(adaptor,"token className",className);
            RewriteRuleTokenStream stream_extendsclass=new RewriteRuleTokenStream(adaptor,"token extendsclass",extendsclass);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 186:9: -> ^( CLASS ^( Modifiers ( classModifier )? ) $className ( ^( Extends $extendsclass) )? ( classImplements )? ( classMember )* )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:186:12: ^( CLASS ^( Modifiers ( classModifier )? ) $className ( ^( Extends $extendsclass) )? ( classImplements )? ( classMember )* )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(stream_CLASS.nextNode(), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:186:20: ^( Modifiers ( classModifier )? )
                {
                CommonTree root_2 = (CommonTree)adaptor.nil();
                root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Modifiers, "Modifiers"), root_2);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:186:32: ( classModifier )?
                if ( stream_classModifier.hasNext() ) {
                    adaptor.addChild(root_2, stream_classModifier.nextTree());

                }
                stream_classModifier.reset();

                adaptor.addChild(root_1, root_2);
                }
                adaptor.addChild(root_1, stream_className.nextNode());
                // /home/iberiam/phpparser-1.2/grammar/Php.g:186:59: ( ^( Extends $extendsclass) )?
                if ( stream_Extends.hasNext()||stream_extendsclass.hasNext() ) {
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:186:59: ^( Extends $extendsclass)
                    {
                    CommonTree root_2 = (CommonTree)adaptor.nil();
                    root_2 = (CommonTree)adaptor.becomeRoot(stream_Extends.nextNode(), root_2);

                    adaptor.addChild(root_2, stream_extendsclass.nextNode());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_Extends.reset();
                stream_extendsclass.reset();
                // /home/iberiam/phpparser-1.2/grammar/Php.g:186:85: ( classImplements )?
                if ( stream_classImplements.hasNext() ) {
                    adaptor.addChild(root_1, stream_classImplements.nextTree());

                }
                stream_classImplements.reset();
                // /home/iberiam/phpparser-1.2/grammar/Php.g:187:13: ( classMember )*
                while ( stream_classMember.hasNext() ) {
                    adaptor.addChild(root_1, stream_classMember.nextTree());

                }
                stream_classMember.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 7, classDefinition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "classDefinition"

    public static class classImplements_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classImplements"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:191:1: classImplements : IMPLEMENTS ( UnquotedString ( COMMA UnquotedString )* ) ;
    public final PhpParser.classImplements_return classImplements() throws RecognitionException {
        PhpParser.classImplements_return retval = new PhpParser.classImplements_return();
        retval.start = input.LT(1);
        int classImplements_StartIndex = input.index();
        CommonTree root_0 = null;

        Token IMPLEMENTS42=null;
        Token UnquotedString43=null;
        Token COMMA44=null;
        Token UnquotedString45=null;

        CommonTree IMPLEMENTS42_tree=null;
        CommonTree UnquotedString43_tree=null;
        CommonTree COMMA44_tree=null;
        CommonTree UnquotedString45_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 8) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:192:5: ( IMPLEMENTS ( UnquotedString ( COMMA UnquotedString )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:192:8: IMPLEMENTS ( UnquotedString ( COMMA UnquotedString )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            IMPLEMENTS42=(Token)match(input,IMPLEMENTS,FOLLOW_IMPLEMENTS_in_classImplements1437); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IMPLEMENTS42_tree = (CommonTree)adaptor.create(IMPLEMENTS42);
            root_0 = (CommonTree)adaptor.becomeRoot(IMPLEMENTS42_tree, root_0);
            }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:192:20: ( UnquotedString ( COMMA UnquotedString )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:192:21: UnquotedString ( COMMA UnquotedString )*
            {
            UnquotedString43=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classImplements1441); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString43_tree = (CommonTree)adaptor.create(UnquotedString43);
            adaptor.addChild(root_0, UnquotedString43_tree);
            }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:192:36: ( COMMA UnquotedString )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==COMMA) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:192:37: COMMA UnquotedString
            	    {
            	    COMMA44=(Token)match(input,COMMA,FOLLOW_COMMA_in_classImplements1444); if (state.failed) return retval;
            	    UnquotedString45=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classImplements1447); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    UnquotedString45_tree = (CommonTree)adaptor.create(UnquotedString45);
            	    adaptor.addChild(root_0, UnquotedString45_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 8, classImplements_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "classImplements"

    public static class classMember_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classMember"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:195:1: classMember : ( ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ( bracketedBlock | ';' ) -> ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition ( bracketedBlock )? ) | VAR DOLLAR UnquotedString ( EQUALS atom )? ';' -> ^( VAR ^( DOLLAR UnquotedString ) ( atom )? ) | CONST UnquotedString ( EQUALS atom )? ';' -> ^( CONST UnquotedString ( atom )? ) | ( fieldModifier )* ( DOLLAR UnquotedString ) ( EQUALS atom )? ';' -> ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? ) );
    public final PhpParser.classMember_return classMember() throws RecognitionException {
        PhpParser.classMember_return retval = new PhpParser.classMember_return();
        retval.start = input.LT(1);
        int classMember_StartIndex = input.index();
        CommonTree root_0 = null;

        Token FUNCTION47=null;
        Token UnquotedString48=null;
        Token char_literal51=null;
        Token VAR52=null;
        Token DOLLAR53=null;
        Token UnquotedString54=null;
        Token EQUALS55=null;
        Token char_literal57=null;
        Token CONST58=null;
        Token UnquotedString59=null;
        Token EQUALS60=null;
        Token char_literal62=null;
        Token DOLLAR64=null;
        Token UnquotedString65=null;
        Token EQUALS66=null;
        Token char_literal68=null;
        PhpParser.fieldModifier_return fieldModifier46 = null;

        PhpParser.parametersDefinition_return parametersDefinition49 = null;

        PhpParser.bracketedBlock_return bracketedBlock50 = null;

        PhpParser.atom_return atom56 = null;

        PhpParser.atom_return atom61 = null;

        PhpParser.fieldModifier_return fieldModifier63 = null;

        PhpParser.atom_return atom67 = null;


        CommonTree FUNCTION47_tree=null;
        CommonTree UnquotedString48_tree=null;
        CommonTree char_literal51_tree=null;
        CommonTree VAR52_tree=null;
        CommonTree DOLLAR53_tree=null;
        CommonTree UnquotedString54_tree=null;
        CommonTree EQUALS55_tree=null;
        CommonTree char_literal57_tree=null;
        CommonTree CONST58_tree=null;
        CommonTree UnquotedString59_tree=null;
        CommonTree EQUALS60_tree=null;
        CommonTree char_literal62_tree=null;
        CommonTree DOLLAR64_tree=null;
        CommonTree UnquotedString65_tree=null;
        CommonTree EQUALS66_tree=null;
        CommonTree char_literal68_tree=null;
        RewriteRuleTokenStream stream_DOLLAR=new RewriteRuleTokenStream(adaptor,"token DOLLAR");
        RewriteRuleTokenStream stream_FUNCTION=new RewriteRuleTokenStream(adaptor,"token FUNCTION");
        RewriteRuleTokenStream stream_VAR=new RewriteRuleTokenStream(adaptor,"token VAR");
        RewriteRuleTokenStream stream_EQUALS=new RewriteRuleTokenStream(adaptor,"token EQUALS");
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleTokenStream stream_CONST=new RewriteRuleTokenStream(adaptor,"token CONST");
        RewriteRuleSubtreeStream stream_atom=new RewriteRuleSubtreeStream(adaptor,"rule atom");
        RewriteRuleSubtreeStream stream_parametersDefinition=new RewriteRuleSubtreeStream(adaptor,"rule parametersDefinition");
        RewriteRuleSubtreeStream stream_fieldModifier=new RewriteRuleSubtreeStream(adaptor,"rule fieldModifier");
        RewriteRuleSubtreeStream stream_bracketedBlock=new RewriteRuleSubtreeStream(adaptor,"rule bracketedBlock");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 9) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:196:5: ( ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ( bracketedBlock | ';' ) -> ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition ( bracketedBlock )? ) | VAR DOLLAR UnquotedString ( EQUALS atom )? ';' -> ^( VAR ^( DOLLAR UnquotedString ) ( atom )? ) | CONST UnquotedString ( EQUALS atom )? ';' -> ^( CONST UnquotedString ( atom )? ) | ( fieldModifier )* ( DOLLAR UnquotedString ) ( EQUALS atom )? ';' -> ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? ) )
            int alt22=4;
            switch ( input.LA(1) ) {
            case STATIC:
            case ABSTRACT:
            case AccessModifier:
            case 117:
                {
                switch ( input.LA(2) ) {
                case FUNCTION:
                    {
                    alt22=1;
                    }
                    break;
                case STATIC:
                case ABSTRACT:
                case AccessModifier:
                case 117:
                    {
                    int LA22_7 = input.LA(3);

                    if ( (synpred23_Php()) ) {
                        alt22=1;
                    }
                    else if ( (true) ) {
                        alt22=4;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 22, 7, input);

                        throw nvae;
                    }
                    }
                    break;
                case DOLLAR:
                    {
                    alt22=4;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 22, 1, input);

                    throw nvae;
                }

                }
                break;
            case FUNCTION:
                {
                alt22=1;
                }
                break;
            case VAR:
                {
                alt22=2;
                }
                break;
            case CONST:
                {
                alt22=3;
                }
                break;
            case DOLLAR:
                {
                alt22=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }

            switch (alt22) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:196:7: ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ( bracketedBlock | ';' )
                    {
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:196:7: ( fieldModifier )*
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( (LA16_0==STATIC||LA16_0==ABSTRACT||LA16_0==AccessModifier||LA16_0==117) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: fieldModifier
                    	    {
                    	    pushFollow(FOLLOW_fieldModifier_in_classMember1467);
                    	    fieldModifier46=fieldModifier();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_fieldModifier.add(fieldModifier46.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop16;
                        }
                    } while (true);

                    FUNCTION47=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_classMember1470); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FUNCTION.add(FUNCTION47);

                    UnquotedString48=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember1472); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString48);

                    pushFollow(FOLLOW_parametersDefinition_in_classMember1474);
                    parametersDefinition49=parametersDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_parametersDefinition.add(parametersDefinition49.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:197:9: ( bracketedBlock | ';' )
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==OPEN_CURLY_BRACE) ) {
                        alt17=1;
                    }
                    else if ( (LA17_0==SEMICOLON) ) {
                        alt17=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }
                    switch (alt17) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:197:10: bracketedBlock
                            {
                            pushFollow(FOLLOW_bracketedBlock_in_classMember1486);
                            bracketedBlock50=bracketedBlock();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_bracketedBlock.add(bracketedBlock50.getTree());

                            }
                            break;
                        case 2 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:197:27: ';'
                            {
                            char_literal51=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_classMember1490); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal51);


                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: bracketedBlock, parametersDefinition, UnquotedString, fieldModifier
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 198:9: -> ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition ( bracketedBlock )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:198:12: ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString parametersDefinition ( bracketedBlock )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Method, "Method"), root_1);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:198:21: ^( Modifiers ( fieldModifier )* )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Modifiers, "Modifiers"), root_2);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:198:33: ( fieldModifier )*
                        while ( stream_fieldModifier.hasNext() ) {
                            adaptor.addChild(root_2, stream_fieldModifier.nextTree());

                        }
                        stream_fieldModifier.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_UnquotedString.nextNode());
                        adaptor.addChild(root_1, stream_parametersDefinition.nextTree());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:198:85: ( bracketedBlock )?
                        if ( stream_bracketedBlock.hasNext() ) {
                            adaptor.addChild(root_1, stream_bracketedBlock.nextTree());

                        }
                        stream_bracketedBlock.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:199:7: VAR DOLLAR UnquotedString ( EQUALS atom )? ';'
                    {
                    VAR52=(Token)match(input,VAR,FOLLOW_VAR_in_classMember1527); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_VAR.add(VAR52);

                    DOLLAR53=(Token)match(input,DOLLAR,FOLLOW_DOLLAR_in_classMember1529); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOLLAR.add(DOLLAR53);

                    UnquotedString54=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember1531); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString54);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:199:33: ( EQUALS atom )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==EQUALS) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:199:34: EQUALS atom
                            {
                            EQUALS55=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_classMember1534); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EQUALS.add(EQUALS55);

                            pushFollow(FOLLOW_atom_in_classMember1536);
                            atom56=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_atom.add(atom56.getTree());

                            }
                            break;

                    }

                    char_literal57=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_classMember1540); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal57);



                    // AST REWRITE
                    // elements: atom, UnquotedString, VAR, DOLLAR
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 200:9: -> ^( VAR ^( DOLLAR UnquotedString ) ( atom )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:200:12: ^( VAR ^( DOLLAR UnquotedString ) ( atom )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_VAR.nextNode(), root_1);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:200:18: ^( DOLLAR UnquotedString )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot(stream_DOLLAR.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_UnquotedString.nextNode());

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:200:43: ( atom )?
                        if ( stream_atom.hasNext() ) {
                            adaptor.addChild(root_1, stream_atom.nextTree());

                        }
                        stream_atom.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:201:7: CONST UnquotedString ( EQUALS atom )? ';'
                    {
                    CONST58=(Token)match(input,CONST,FOLLOW_CONST_in_classMember1573); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CONST.add(CONST58);

                    UnquotedString59=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember1575); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString59);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:201:28: ( EQUALS atom )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==EQUALS) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:201:29: EQUALS atom
                            {
                            EQUALS60=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_classMember1578); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EQUALS.add(EQUALS60);

                            pushFollow(FOLLOW_atom_in_classMember1580);
                            atom61=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_atom.add(atom61.getTree());

                            }
                            break;

                    }

                    char_literal62=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_classMember1584); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal62);



                    // AST REWRITE
                    // elements: atom, CONST, UnquotedString
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 202:9: -> ^( CONST UnquotedString ( atom )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:202:12: ^( CONST UnquotedString ( atom )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_CONST.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_UnquotedString.nextNode());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:202:35: ( atom )?
                        if ( stream_atom.hasNext() ) {
                            adaptor.addChild(root_1, stream_atom.nextTree());

                        }
                        stream_atom.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:203:7: ( fieldModifier )* ( DOLLAR UnquotedString ) ( EQUALS atom )? ';'
                    {
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:203:7: ( fieldModifier )*
                    loop20:
                    do {
                        int alt20=2;
                        int LA20_0 = input.LA(1);

                        if ( (LA20_0==STATIC||LA20_0==ABSTRACT||LA20_0==AccessModifier||LA20_0==117) ) {
                            alt20=1;
                        }


                        switch (alt20) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: fieldModifier
                    	    {
                    	    pushFollow(FOLLOW_fieldModifier_in_classMember1612);
                    	    fieldModifier63=fieldModifier();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_fieldModifier.add(fieldModifier63.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop20;
                        }
                    } while (true);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:203:22: ( DOLLAR UnquotedString )
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:203:23: DOLLAR UnquotedString
                    {
                    DOLLAR64=(Token)match(input,DOLLAR,FOLLOW_DOLLAR_in_classMember1616); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOLLAR.add(DOLLAR64);

                    UnquotedString65=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember1618); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString65);


                    }

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:203:46: ( EQUALS atom )?
                    int alt21=2;
                    int LA21_0 = input.LA(1);

                    if ( (LA21_0==EQUALS) ) {
                        alt21=1;
                    }
                    switch (alt21) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:203:47: EQUALS atom
                            {
                            EQUALS66=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_classMember1622); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_EQUALS.add(EQUALS66);

                            pushFollow(FOLLOW_atom_in_classMember1624);
                            atom67=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_atom.add(atom67.getTree());

                            }
                            break;

                    }

                    char_literal68=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_classMember1628); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal68);



                    // AST REWRITE
                    // elements: DOLLAR, atom, UnquotedString, fieldModifier
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 204:9: -> ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:204:12: ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Field, "Field"), root_1);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:204:20: ^( Modifiers ( fieldModifier )* )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Modifiers, "Modifiers"), root_2);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:204:32: ( fieldModifier )*
                        while ( stream_fieldModifier.hasNext() ) {
                            adaptor.addChild(root_2, stream_fieldModifier.nextTree());

                        }
                        stream_fieldModifier.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:204:48: ^( DOLLAR UnquotedString )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot(stream_DOLLAR.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_UnquotedString.nextNode());

                        adaptor.addChild(root_1, root_2);
                        }
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:204:73: ( atom )?
                        if ( stream_atom.hasNext() ) {
                            adaptor.addChild(root_1, stream_atom.nextTree());

                        }
                        stream_atom.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 9, classMember_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "classMember"

    public static class fieldDefinition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldDefinition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:207:1: fieldDefinition : DOLLAR UnquotedString ( EQUALS atom )? ';' -> ^( Field ^( DOLLAR UnquotedString ) ( atom )? ) ;
    public final PhpParser.fieldDefinition_return fieldDefinition() throws RecognitionException {
        PhpParser.fieldDefinition_return retval = new PhpParser.fieldDefinition_return();
        retval.start = input.LT(1);
        int fieldDefinition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token DOLLAR69=null;
        Token UnquotedString70=null;
        Token EQUALS71=null;
        Token char_literal73=null;
        PhpParser.atom_return atom72 = null;


        CommonTree DOLLAR69_tree=null;
        CommonTree UnquotedString70_tree=null;
        CommonTree EQUALS71_tree=null;
        CommonTree char_literal73_tree=null;
        RewriteRuleTokenStream stream_DOLLAR=new RewriteRuleTokenStream(adaptor,"token DOLLAR");
        RewriteRuleTokenStream stream_EQUALS=new RewriteRuleTokenStream(adaptor,"token EQUALS");
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleSubtreeStream stream_atom=new RewriteRuleSubtreeStream(adaptor,"rule atom");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 10) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:208:5: ( DOLLAR UnquotedString ( EQUALS atom )? ';' -> ^( Field ^( DOLLAR UnquotedString ) ( atom )? ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:208:7: DOLLAR UnquotedString ( EQUALS atom )? ';'
            {
            DOLLAR69=(Token)match(input,DOLLAR,FOLLOW_DOLLAR_in_fieldDefinition1676); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_DOLLAR.add(DOLLAR69);

            UnquotedString70=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_fieldDefinition1678); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString70);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:208:29: ( EQUALS atom )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==EQUALS) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:208:30: EQUALS atom
                    {
                    EQUALS71=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_fieldDefinition1681); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_EQUALS.add(EQUALS71);

                    pushFollow(FOLLOW_atom_in_fieldDefinition1683);
                    atom72=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_atom.add(atom72.getTree());

                    }
                    break;

            }

            char_literal73=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_fieldDefinition1687); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal73);



            // AST REWRITE
            // elements: atom, UnquotedString, DOLLAR
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 208:47: -> ^( Field ^( DOLLAR UnquotedString ) ( atom )? )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:208:50: ^( Field ^( DOLLAR UnquotedString ) ( atom )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Field, "Field"), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:208:58: ^( DOLLAR UnquotedString )
                {
                CommonTree root_2 = (CommonTree)adaptor.nil();
                root_2 = (CommonTree)adaptor.becomeRoot(stream_DOLLAR.nextNode(), root_2);

                adaptor.addChild(root_2, stream_UnquotedString.nextNode());

                adaptor.addChild(root_1, root_2);
                }
                // /home/iberiam/phpparser-1.2/grammar/Php.g:208:83: ( atom )?
                if ( stream_atom.hasNext() ) {
                    adaptor.addChild(root_1, stream_atom.nextTree());

                }
                stream_atom.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 10, fieldDefinition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "fieldDefinition"

    public static class classModifier_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classModifier"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:211:1: classModifier : 'abstract' ;
    public final PhpParser.classModifier_return classModifier() throws RecognitionException {
        PhpParser.classModifier_return retval = new PhpParser.classModifier_return();
        retval.start = input.LT(1);
        int classModifier_StartIndex = input.index();
        CommonTree root_0 = null;

        Token string_literal74=null;

        CommonTree string_literal74_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 11) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:212:5: ( 'abstract' )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:212:7: 'abstract'
            {
            root_0 = (CommonTree)adaptor.nil();

            string_literal74=(Token)match(input,ABSTRACT,FOLLOW_ABSTRACT_in_classModifier1722); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            string_literal74_tree = (CommonTree)adaptor.create(string_literal74);
            adaptor.addChild(root_0, string_literal74_tree);
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 11, classModifier_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "classModifier"

    public static class fieldModifier_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldModifier"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:214:1: fieldModifier : ( AccessModifier | 'abstract' | 'static' | 'final' );
    public final PhpParser.fieldModifier_return fieldModifier() throws RecognitionException {
        PhpParser.fieldModifier_return retval = new PhpParser.fieldModifier_return();
        retval.start = input.LT(1);
        int fieldModifier_StartIndex = input.index();
        CommonTree root_0 = null;

        Token set75=null;

        CommonTree set75_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 12) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:215:5: ( AccessModifier | 'abstract' | 'static' | 'final' )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:
            {
            root_0 = (CommonTree)adaptor.nil();

            set75=(Token)input.LT(1);
            if ( input.LA(1)==STATIC||input.LA(1)==ABSTRACT||input.LA(1)==AccessModifier||input.LA(1)==117 ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set75));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 12, fieldModifier_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "fieldModifier"

    public static class complexStatement_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "complexStatement"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:219:1: complexStatement : ( IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )? -> ^( IF expression $ifTrue ( conditional )? ) | FOR '(' forInit forCondition forUpdate ')' statement -> ^( FOR forInit forCondition forUpdate statement ) | FOR_EACH '(' variable 'as' arrayEntry ')' statement -> ^( FOR_EACH variable arrayEntry statement ) | WHILE '(' (whileCondition= expression )? ')' statement -> ^( WHILE $whileCondition statement ) | DO statement WHILE '(' doCondition= expression ')' ';' -> ^( DO statement $doCondition) | SWITCH '(' expression ')' '{' cases '}' -> ^( SWITCH expression cases ) | TRY statement catchStatement -> ^( TRY statement catchStatement ) | THROW throwException ';' -> ^( THROW throwException ) | DECLARE '(' declareList ')' ( ';' | statement ) -> ^( DECLARE declareList ( statement )? ) | USE useFilename ';' -> ^( USE useFilename ) | functionDefinition );
    public final PhpParser.complexStatement_return complexStatement() throws RecognitionException {
        PhpParser.complexStatement_return retval = new PhpParser.complexStatement_return();
        retval.start = input.LT(1);
        int complexStatement_StartIndex = input.index();
        CommonTree root_0 = null;

        Token IF76=null;
        Token char_literal77=null;
        Token char_literal78=null;
        Token FOR80=null;
        Token char_literal81=null;
        Token char_literal85=null;
        Token FOR_EACH87=null;
        Token char_literal88=null;
        Token string_literal90=null;
        Token char_literal92=null;
        Token WHILE94=null;
        Token char_literal95=null;
        Token char_literal96=null;
        Token DO98=null;
        Token WHILE100=null;
        Token char_literal101=null;
        Token char_literal102=null;
        Token char_literal103=null;
        Token SWITCH104=null;
        Token char_literal105=null;
        Token char_literal107=null;
        Token char_literal108=null;
        Token char_literal110=null;
        Token TRY111=null;
        Token THROW114=null;
        Token char_literal116=null;
        Token DECLARE117=null;
        Token char_literal118=null;
        Token char_literal120=null;
        Token char_literal121=null;
        Token USE123=null;
        Token char_literal125=null;
        PhpParser.expression_return ifCondition = null;

        PhpParser.statement_return ifTrue = null;

        PhpParser.expression_return whileCondition = null;

        PhpParser.expression_return doCondition = null;

        PhpParser.conditional_return conditional79 = null;

        PhpParser.forInit_return forInit82 = null;

        PhpParser.forCondition_return forCondition83 = null;

        PhpParser.forUpdate_return forUpdate84 = null;

        PhpParser.statement_return statement86 = null;

        PhpParser.variable_return variable89 = null;

        PhpParser.arrayEntry_return arrayEntry91 = null;

        PhpParser.statement_return statement93 = null;

        PhpParser.statement_return statement97 = null;

        PhpParser.statement_return statement99 = null;

        PhpParser.expression_return expression106 = null;

        PhpParser.cases_return cases109 = null;

        PhpParser.statement_return statement112 = null;

        PhpParser.catchStatement_return catchStatement113 = null;

        PhpParser.throwException_return throwException115 = null;

        PhpParser.declareList_return declareList119 = null;

        PhpParser.statement_return statement122 = null;

        PhpParser.useFilename_return useFilename124 = null;

        PhpParser.functionDefinition_return functionDefinition126 = null;


        CommonTree IF76_tree=null;
        CommonTree char_literal77_tree=null;
        CommonTree char_literal78_tree=null;
        CommonTree FOR80_tree=null;
        CommonTree char_literal81_tree=null;
        CommonTree char_literal85_tree=null;
        CommonTree FOR_EACH87_tree=null;
        CommonTree char_literal88_tree=null;
        CommonTree string_literal90_tree=null;
        CommonTree char_literal92_tree=null;
        CommonTree WHILE94_tree=null;
        CommonTree char_literal95_tree=null;
        CommonTree char_literal96_tree=null;
        CommonTree DO98_tree=null;
        CommonTree WHILE100_tree=null;
        CommonTree char_literal101_tree=null;
        CommonTree char_literal102_tree=null;
        CommonTree char_literal103_tree=null;
        CommonTree SWITCH104_tree=null;
        CommonTree char_literal105_tree=null;
        CommonTree char_literal107_tree=null;
        CommonTree char_literal108_tree=null;
        CommonTree char_literal110_tree=null;
        CommonTree TRY111_tree=null;
        CommonTree THROW114_tree=null;
        CommonTree char_literal116_tree=null;
        CommonTree DECLARE117_tree=null;
        CommonTree char_literal118_tree=null;
        CommonTree char_literal120_tree=null;
        CommonTree char_literal121_tree=null;
        CommonTree USE123_tree=null;
        CommonTree char_literal125_tree=null;
        RewriteRuleTokenStream stream_WHILE=new RewriteRuleTokenStream(adaptor,"token WHILE");
        RewriteRuleTokenStream stream_SWITCH=new RewriteRuleTokenStream(adaptor,"token SWITCH");
        RewriteRuleTokenStream stream_118=new RewriteRuleTokenStream(adaptor,"token 118");
        RewriteRuleTokenStream stream_DECLARE=new RewriteRuleTokenStream(adaptor,"token DECLARE");
        RewriteRuleTokenStream stream_FOR=new RewriteRuleTokenStream(adaptor,"token FOR");
        RewriteRuleTokenStream stream_DO=new RewriteRuleTokenStream(adaptor,"token DO");
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleTokenStream stream_USE=new RewriteRuleTokenStream(adaptor,"token USE");
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleTokenStream stream_FOR_EACH=new RewriteRuleTokenStream(adaptor,"token FOR_EACH");
        RewriteRuleTokenStream stream_OPEN_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_CURLY_BRACE");
        RewriteRuleTokenStream stream_CLOSE_CURLY_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_CURLY_BRACE");
        RewriteRuleTokenStream stream_THROW=new RewriteRuleTokenStream(adaptor,"token THROW");
        RewriteRuleTokenStream stream_TRY=new RewriteRuleTokenStream(adaptor,"token TRY");
        RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_useFilename=new RewriteRuleSubtreeStream(adaptor,"rule useFilename");
        RewriteRuleSubtreeStream stream_cases=new RewriteRuleSubtreeStream(adaptor,"rule cases");
        RewriteRuleSubtreeStream stream_forCondition=new RewriteRuleSubtreeStream(adaptor,"rule forCondition");
        RewriteRuleSubtreeStream stream_catchStatement=new RewriteRuleSubtreeStream(adaptor,"rule catchStatement");
        RewriteRuleSubtreeStream stream_forUpdate=new RewriteRuleSubtreeStream(adaptor,"rule forUpdate");
        RewriteRuleSubtreeStream stream_arrayEntry=new RewriteRuleSubtreeStream(adaptor,"rule arrayEntry");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_declareList=new RewriteRuleSubtreeStream(adaptor,"rule declareList");
        RewriteRuleSubtreeStream stream_throwException=new RewriteRuleSubtreeStream(adaptor,"rule throwException");
        RewriteRuleSubtreeStream stream_conditional=new RewriteRuleSubtreeStream(adaptor,"rule conditional");
        RewriteRuleSubtreeStream stream_forInit=new RewriteRuleSubtreeStream(adaptor,"rule forInit");
        RewriteRuleSubtreeStream stream_variable=new RewriteRuleSubtreeStream(adaptor,"rule variable");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 13) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:220:5: ( IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )? -> ^( IF expression $ifTrue ( conditional )? ) | FOR '(' forInit forCondition forUpdate ')' statement -> ^( FOR forInit forCondition forUpdate statement ) | FOR_EACH '(' variable 'as' arrayEntry ')' statement -> ^( FOR_EACH variable arrayEntry statement ) | WHILE '(' (whileCondition= expression )? ')' statement -> ^( WHILE $whileCondition statement ) | DO statement WHILE '(' doCondition= expression ')' ';' -> ^( DO statement $doCondition) | SWITCH '(' expression ')' '{' cases '}' -> ^( SWITCH expression cases ) | TRY statement catchStatement -> ^( TRY statement catchStatement ) | THROW throwException ';' -> ^( THROW throwException ) | DECLARE '(' declareList ')' ( ';' | statement ) -> ^( DECLARE declareList ( statement )? ) | USE useFilename ';' -> ^( USE useFilename ) | functionDefinition )
            int alt27=11;
            alt27 = dfa27.predict(input);
            switch (alt27) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:220:7: IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )?
                    {
                    IF76=(Token)match(input,IF,FOLLOW_IF_in_complexStatement1768); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IF.add(IF76);

                    char_literal77=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement1770); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal77);

                    pushFollow(FOLLOW_expression_in_complexStatement1774);
                    ifCondition=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(ifCondition.getTree());
                    char_literal78=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement1776); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal78);

                    pushFollow(FOLLOW_statement_in_complexStatement1780);
                    ifTrue=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(ifTrue.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:220:58: ( conditional )?
                    int alt24=2;
                    alt24 = dfa24.predict(input);
                    switch (alt24) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: conditional
                            {
                            pushFollow(FOLLOW_conditional_in_complexStatement1782);
                            conditional79=conditional();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_conditional.add(conditional79.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: conditional, ifTrue, expression, IF
                    // token labels: 
                    // rule labels: ifTrue, retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_ifTrue=new RewriteRuleSubtreeStream(adaptor,"rule ifTrue",ifTrue!=null?ifTrue.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 220:71: -> ^( IF expression $ifTrue ( conditional )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:220:74: ^( IF expression $ifTrue ( conditional )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_IF.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());
                        adaptor.addChild(root_1, stream_ifTrue.nextTree());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:220:98: ( conditional )?
                        if ( stream_conditional.hasNext() ) {
                            adaptor.addChild(root_1, stream_conditional.nextTree());

                        }
                        stream_conditional.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:221:7: FOR '(' forInit forCondition forUpdate ')' statement
                    {
                    FOR80=(Token)match(input,FOR,FOLLOW_FOR_in_complexStatement1805); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOR.add(FOR80);

                    char_literal81=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement1807); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal81);

                    pushFollow(FOLLOW_forInit_in_complexStatement1809);
                    forInit82=forInit();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_forInit.add(forInit82.getTree());
                    pushFollow(FOLLOW_forCondition_in_complexStatement1811);
                    forCondition83=forCondition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_forCondition.add(forCondition83.getTree());
                    pushFollow(FOLLOW_forUpdate_in_complexStatement1813);
                    forUpdate84=forUpdate();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_forUpdate.add(forUpdate84.getTree());
                    char_literal85=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement1815); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal85);

                    pushFollow(FOLLOW_statement_in_complexStatement1817);
                    statement86=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement86.getTree());


                    // AST REWRITE
                    // elements: FOR, statement, forCondition, forUpdate, forInit
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 221:60: -> ^( FOR forInit forCondition forUpdate statement )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:221:63: ^( FOR forInit forCondition forUpdate statement )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_FOR.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_forInit.nextTree());
                        adaptor.addChild(root_1, stream_forCondition.nextTree());
                        adaptor.addChild(root_1, stream_forUpdate.nextTree());
                        adaptor.addChild(root_1, stream_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:222:7: FOR_EACH '(' variable 'as' arrayEntry ')' statement
                    {
                    FOR_EACH87=(Token)match(input,FOR_EACH,FOLLOW_FOR_EACH_in_complexStatement1839); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_FOR_EACH.add(FOR_EACH87);

                    char_literal88=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement1841); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal88);

                    pushFollow(FOLLOW_variable_in_complexStatement1843);
                    variable89=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_variable.add(variable89.getTree());
                    string_literal90=(Token)match(input,118,FOLLOW_118_in_complexStatement1845); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_118.add(string_literal90);

                    pushFollow(FOLLOW_arrayEntry_in_complexStatement1847);
                    arrayEntry91=arrayEntry();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_arrayEntry.add(arrayEntry91.getTree());
                    char_literal92=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement1849); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal92);

                    pushFollow(FOLLOW_statement_in_complexStatement1851);
                    statement93=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement93.getTree());


                    // AST REWRITE
                    // elements: arrayEntry, FOR_EACH, variable, statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 222:59: -> ^( FOR_EACH variable arrayEntry statement )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:222:62: ^( FOR_EACH variable arrayEntry statement )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_FOR_EACH.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_variable.nextTree());
                        adaptor.addChild(root_1, stream_arrayEntry.nextTree());
                        adaptor.addChild(root_1, stream_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:223:7: WHILE '(' (whileCondition= expression )? ')' statement
                    {
                    WHILE94=(Token)match(input,WHILE,FOLLOW_WHILE_in_complexStatement1871); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WHILE.add(WHILE94);

                    char_literal95=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement1873); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal95);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:223:31: (whileCondition= expression )?
                    int alt25=2;
                    alt25 = dfa25.predict(input);
                    switch (alt25) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: whileCondition= expression
                            {
                            pushFollow(FOLLOW_expression_in_complexStatement1877);
                            whileCondition=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(whileCondition.getTree());

                            }
                            break;

                    }

                    char_literal96=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement1880); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal96);

                    pushFollow(FOLLOW_statement_in_complexStatement1882);
                    statement97=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement97.getTree());


                    // AST REWRITE
                    // elements: WHILE, whileCondition, statement
                    // token labels: 
                    // rule labels: retval, whileCondition
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_whileCondition=new RewriteRuleSubtreeStream(adaptor,"rule whileCondition",whileCondition!=null?whileCondition.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 223:58: -> ^( WHILE $whileCondition statement )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:223:61: ^( WHILE $whileCondition statement )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_WHILE.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_whileCondition.nextTree());
                        adaptor.addChild(root_1, stream_statement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:224:7: DO statement WHILE '(' doCondition= expression ')' ';'
                    {
                    DO98=(Token)match(input,DO,FOLLOW_DO_in_complexStatement1901); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DO.add(DO98);

                    pushFollow(FOLLOW_statement_in_complexStatement1903);
                    statement99=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement99.getTree());
                    WHILE100=(Token)match(input,WHILE,FOLLOW_WHILE_in_complexStatement1905); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_WHILE.add(WHILE100);

                    char_literal101=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement1907); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal101);

                    pushFollow(FOLLOW_expression_in_complexStatement1911);
                    doCondition=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(doCondition.getTree());
                    char_literal102=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement1913); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal102);

                    char_literal103=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_complexStatement1915); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal103);



                    // AST REWRITE
                    // elements: DO, statement, doCondition
                    // token labels: 
                    // rule labels: retval, doCondition
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_doCondition=new RewriteRuleSubtreeStream(adaptor,"rule doCondition",doCondition!=null?doCondition.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 224:61: -> ^( DO statement $doCondition)
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:224:64: ^( DO statement $doCondition)
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_DO.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_statement.nextTree());
                        adaptor.addChild(root_1, stream_doCondition.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:225:7: SWITCH '(' expression ')' '{' cases '}'
                    {
                    SWITCH104=(Token)match(input,SWITCH,FOLLOW_SWITCH_in_complexStatement1934); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SWITCH.add(SWITCH104);

                    char_literal105=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement1936); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal105);

                    pushFollow(FOLLOW_expression_in_complexStatement1938);
                    expression106=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression106.getTree());
                    char_literal107=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement1940); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal107);

                    char_literal108=(Token)match(input,OPEN_CURLY_BRACE,FOLLOW_OPEN_CURLY_BRACE_in_complexStatement1942); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_CURLY_BRACE.add(char_literal108);

                    pushFollow(FOLLOW_cases_in_complexStatement1943);
                    cases109=cases();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_cases.add(cases109.getTree());
                    char_literal110=(Token)match(input,CLOSE_CURLY_BRACE,FOLLOW_CLOSE_CURLY_BRACE_in_complexStatement1944); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_CURLY_BRACE.add(char_literal110);



                    // AST REWRITE
                    // elements: cases, expression, SWITCH
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 225:45: -> ^( SWITCH expression cases )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:225:48: ^( SWITCH expression cases )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_SWITCH.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());
                        adaptor.addChild(root_1, stream_cases.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:226:7: TRY statement catchStatement
                    {
                    TRY111=(Token)match(input,TRY,FOLLOW_TRY_in_complexStatement1962); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_TRY.add(TRY111);

                    pushFollow(FOLLOW_statement_in_complexStatement1964);
                    statement112=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement112.getTree());
                    pushFollow(FOLLOW_catchStatement_in_complexStatement1966);
                    catchStatement113=catchStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_catchStatement.add(catchStatement113.getTree());


                    // AST REWRITE
                    // elements: TRY, catchStatement, statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 226:36: -> ^( TRY statement catchStatement )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:226:39: ^( TRY statement catchStatement )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_TRY.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_statement.nextTree());
                        adaptor.addChild(root_1, stream_catchStatement.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:227:7: THROW throwException ';'
                    {
                    THROW114=(Token)match(input,THROW,FOLLOW_THROW_in_complexStatement1984); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_THROW.add(THROW114);

                    pushFollow(FOLLOW_throwException_in_complexStatement1986);
                    throwException115=throwException();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_throwException.add(throwException115.getTree());
                    char_literal116=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_complexStatement1988); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal116);



                    // AST REWRITE
                    // elements: throwException, THROW
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 227:32: -> ^( THROW throwException )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:227:35: ^( THROW throwException )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_THROW.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_throwException.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 9 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:228:7: DECLARE '(' declareList ')' ( ';' | statement )
                    {
                    DECLARE117=(Token)match(input,DECLARE,FOLLOW_DECLARE_in_complexStatement2004); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DECLARE.add(DECLARE117);

                    char_literal118=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_complexStatement2006); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal118);

                    pushFollow(FOLLOW_declareList_in_complexStatement2008);
                    declareList119=declareList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_declareList.add(declareList119.getTree());
                    char_literal120=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_complexStatement2010); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal120);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:228:35: ( ';' | statement )
                    int alt26=2;
                    alt26 = dfa26.predict(input);
                    switch (alt26) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:228:36: ';'
                            {
                            char_literal121=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_complexStatement2013); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal121);


                            }
                            break;
                        case 2 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:228:42: statement
                            {
                            pushFollow(FOLLOW_statement_in_complexStatement2017);
                            statement122=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_statement.add(statement122.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: declareList, statement, DECLARE
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 228:53: -> ^( DECLARE declareList ( statement )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:228:56: ^( DECLARE declareList ( statement )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_DECLARE.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_declareList.nextTree());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:228:78: ( statement )?
                        if ( stream_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_statement.nextTree());

                        }
                        stream_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 10 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:229:7: USE useFilename ';'
                    {
                    USE123=(Token)match(input,USE,FOLLOW_USE_in_complexStatement2037); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_USE.add(USE123);

                    pushFollow(FOLLOW_useFilename_in_complexStatement2039);
                    useFilename124=useFilename();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_useFilename.add(useFilename124.getTree());
                    char_literal125=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_complexStatement2041); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal125);



                    // AST REWRITE
                    // elements: USE, useFilename
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 229:27: -> ^( USE useFilename )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:229:30: ^( USE useFilename )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_USE.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_useFilename.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 11 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:230:7: functionDefinition
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_functionDefinition_in_complexStatement2057);
                    functionDefinition126=functionDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, functionDefinition126.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 13, complexStatement_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "complexStatement"

    public static class simpleStatement_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleStatement"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:233:1: simpleStatement : ( ECHO commaList | PRINT commaList | GLOBAL name ( ',' name )* | STATIC variable EQUALS atom | BREAK ( Integer )? | CONTINUE ( Integer )? | RETURN ( expression )? | RequireOperator expression | expression );
    public final PhpParser.simpleStatement_return simpleStatement() throws RecognitionException {
        PhpParser.simpleStatement_return retval = new PhpParser.simpleStatement_return();
        retval.start = input.LT(1);
        int simpleStatement_StartIndex = input.index();
        CommonTree root_0 = null;

        Token ECHO127=null;
        Token PRINT129=null;
        Token GLOBAL131=null;
        Token char_literal133=null;
        Token STATIC135=null;
        Token EQUALS137=null;
        Token BREAK139=null;
        Token Integer140=null;
        Token CONTINUE141=null;
        Token Integer142=null;
        Token RETURN143=null;
        Token RequireOperator145=null;
        PhpParser.commaList_return commaList128 = null;

        PhpParser.commaList_return commaList130 = null;

        PhpParser.name_return name132 = null;

        PhpParser.name_return name134 = null;

        PhpParser.variable_return variable136 = null;

        PhpParser.atom_return atom138 = null;

        PhpParser.expression_return expression144 = null;

        PhpParser.expression_return expression146 = null;

        PhpParser.expression_return expression147 = null;


        CommonTree ECHO127_tree=null;
        CommonTree PRINT129_tree=null;
        CommonTree GLOBAL131_tree=null;
        CommonTree char_literal133_tree=null;
        CommonTree STATIC135_tree=null;
        CommonTree EQUALS137_tree=null;
        CommonTree BREAK139_tree=null;
        CommonTree Integer140_tree=null;
        CommonTree CONTINUE141_tree=null;
        CommonTree Integer142_tree=null;
        CommonTree RETURN143_tree=null;
        CommonTree RequireOperator145_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 14) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:234:5: ( ECHO commaList | PRINT commaList | GLOBAL name ( ',' name )* | STATIC variable EQUALS atom | BREAK ( Integer )? | CONTINUE ( Integer )? | RETURN ( expression )? | RequireOperator expression | expression )
            int alt32=9;
            alt32 = dfa32.predict(input);
            switch (alt32) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:234:7: ECHO commaList
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ECHO127=(Token)match(input,ECHO,FOLLOW_ECHO_in_simpleStatement2074); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ECHO127_tree = (CommonTree)adaptor.create(ECHO127);
                    root_0 = (CommonTree)adaptor.becomeRoot(ECHO127_tree, root_0);
                    }
                    pushFollow(FOLLOW_commaList_in_simpleStatement2077);
                    commaList128=commaList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, commaList128.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:235:7: PRINT commaList
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    PRINT129=(Token)match(input,PRINT,FOLLOW_PRINT_in_simpleStatement2085); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    PRINT129_tree = (CommonTree)adaptor.create(PRINT129);
                    root_0 = (CommonTree)adaptor.becomeRoot(PRINT129_tree, root_0);
                    }
                    pushFollow(FOLLOW_commaList_in_simpleStatement2088);
                    commaList130=commaList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, commaList130.getTree());

                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:236:7: GLOBAL name ( ',' name )*
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    GLOBAL131=(Token)match(input,GLOBAL,FOLLOW_GLOBAL_in_simpleStatement2096); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    GLOBAL131_tree = (CommonTree)adaptor.create(GLOBAL131);
                    root_0 = (CommonTree)adaptor.becomeRoot(GLOBAL131_tree, root_0);
                    }
                    pushFollow(FOLLOW_name_in_simpleStatement2099);
                    name132=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, name132.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:236:20: ( ',' name )*
                    loop28:
                    do {
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==COMMA) ) {
                            alt28=1;
                        }


                        switch (alt28) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/Php.g:236:21: ',' name
                    	    {
                    	    char_literal133=(Token)match(input,COMMA,FOLLOW_COMMA_in_simpleStatement2102); if (state.failed) return retval;
                    	    pushFollow(FOLLOW_name_in_simpleStatement2105);
                    	    name134=name();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) adaptor.addChild(root_0, name134.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop28;
                        }
                    } while (true);


                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:237:7: STATIC variable EQUALS atom
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    STATIC135=(Token)match(input,STATIC,FOLLOW_STATIC_in_simpleStatement2115); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STATIC135_tree = (CommonTree)adaptor.create(STATIC135);
                    root_0 = (CommonTree)adaptor.becomeRoot(STATIC135_tree, root_0);
                    }
                    pushFollow(FOLLOW_variable_in_simpleStatement2118);
                    variable136=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable136.getTree());
                    EQUALS137=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_simpleStatement2120); if (state.failed) return retval;
                    pushFollow(FOLLOW_atom_in_simpleStatement2123);
                    atom138=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, atom138.getTree());

                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:239:7: BREAK ( Integer )?
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    BREAK139=(Token)match(input,BREAK,FOLLOW_BREAK_in_simpleStatement2136); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BREAK139_tree = (CommonTree)adaptor.create(BREAK139);
                    root_0 = (CommonTree)adaptor.becomeRoot(BREAK139_tree, root_0);
                    }
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:239:14: ( Integer )?
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==Integer) ) {
                        alt29=1;
                    }
                    switch (alt29) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: Integer
                            {
                            Integer140=(Token)match(input,Integer,FOLLOW_Integer_in_simpleStatement2139); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            Integer140_tree = (CommonTree)adaptor.create(Integer140);
                            adaptor.addChild(root_0, Integer140_tree);
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:240:7: CONTINUE ( Integer )?
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    CONTINUE141=(Token)match(input,CONTINUE,FOLLOW_CONTINUE_in_simpleStatement2148); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CONTINUE141_tree = (CommonTree)adaptor.create(CONTINUE141);
                    root_0 = (CommonTree)adaptor.becomeRoot(CONTINUE141_tree, root_0);
                    }
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:240:17: ( Integer )?
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==Integer) ) {
                        alt30=1;
                    }
                    switch (alt30) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: Integer
                            {
                            Integer142=(Token)match(input,Integer,FOLLOW_Integer_in_simpleStatement2151); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            Integer142_tree = (CommonTree)adaptor.create(Integer142);
                            adaptor.addChild(root_0, Integer142_tree);
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:242:7: RETURN ( expression )?
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    RETURN143=(Token)match(input,RETURN,FOLLOW_RETURN_in_simpleStatement2165); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RETURN143_tree = (CommonTree)adaptor.create(RETURN143);
                    root_0 = (CommonTree)adaptor.becomeRoot(RETURN143_tree, root_0);
                    }
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:242:15: ( expression )?
                    int alt31=2;
                    alt31 = dfa31.predict(input);
                    switch (alt31) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: expression
                            {
                            pushFollow(FOLLOW_expression_in_simpleStatement2168);
                            expression144=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) adaptor.addChild(root_0, expression144.getTree());

                            }
                            break;

                    }


                    }
                    break;
                case 8 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:243:7: RequireOperator expression
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    RequireOperator145=(Token)match(input,RequireOperator,FOLLOW_RequireOperator_in_simpleStatement2177); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RequireOperator145_tree = (CommonTree)adaptor.create(RequireOperator145);
                    root_0 = (CommonTree)adaptor.becomeRoot(RequireOperator145_tree, root_0);
                    }
                    pushFollow(FOLLOW_expression_in_simpleStatement2180);
                    expression146=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression146.getTree());

                    }
                    break;
                case 9 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:244:7: expression
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_expression_in_simpleStatement2188);
                    expression147=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression147.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 14, simpleStatement_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "simpleStatement"

    public static class conditional_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "conditional"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:248:1: conditional : ( ELSE_IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )? -> ^( IF $ifCondition $ifTrue ( conditional )? ) | ELSE statement -> statement );
    public final PhpParser.conditional_return conditional() throws RecognitionException {
        PhpParser.conditional_return retval = new PhpParser.conditional_return();
        retval.start = input.LT(1);
        int conditional_StartIndex = input.index();
        CommonTree root_0 = null;

        Token ELSE_IF148=null;
        Token char_literal149=null;
        Token char_literal150=null;
        Token ELSE152=null;
        PhpParser.expression_return ifCondition = null;

        PhpParser.statement_return ifTrue = null;

        PhpParser.conditional_return conditional151 = null;

        PhpParser.statement_return statement153 = null;


        CommonTree ELSE_IF148_tree=null;
        CommonTree char_literal149_tree=null;
        CommonTree char_literal150_tree=null;
        CommonTree ELSE152_tree=null;
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleTokenStream stream_ELSE_IF=new RewriteRuleTokenStream(adaptor,"token ELSE_IF");
        RewriteRuleTokenStream stream_ELSE=new RewriteRuleTokenStream(adaptor,"token ELSE");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_conditional=new RewriteRuleSubtreeStream(adaptor,"rule conditional");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 15) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:249:5: ( ELSE_IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )? -> ^( IF $ifCondition $ifTrue ( conditional )? ) | ELSE statement -> statement )
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==ELSE_IF) ) {
                alt34=1;
            }
            else if ( (LA34_0==ELSE) ) {
                alt34=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 34, 0, input);

                throw nvae;
            }
            switch (alt34) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:249:7: ELSE_IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )?
                    {
                    ELSE_IF148=(Token)match(input,ELSE_IF,FOLLOW_ELSE_IF_in_conditional2206); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ELSE_IF.add(ELSE_IF148);

                    char_literal149=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_conditional2208); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal149);

                    pushFollow(FOLLOW_expression_in_conditional2212);
                    ifCondition=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(ifCondition.getTree());
                    char_literal150=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_conditional2214); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal150);

                    pushFollow(FOLLOW_statement_in_conditional2218);
                    ifTrue=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(ifTrue.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:249:63: ( conditional )?
                    int alt33=2;
                    alt33 = dfa33.predict(input);
                    switch (alt33) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: conditional
                            {
                            pushFollow(FOLLOW_conditional_in_conditional2220);
                            conditional151=conditional();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_conditional.add(conditional151.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: conditional, ifCondition, ifTrue
                    // token labels: 
                    // rule labels: ifTrue, retval, ifCondition
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_ifTrue=new RewriteRuleSubtreeStream(adaptor,"rule ifTrue",ifTrue!=null?ifTrue.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_ifCondition=new RewriteRuleSubtreeStream(adaptor,"rule ifCondition",ifCondition!=null?ifCondition.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 249:76: -> ^( IF $ifCondition $ifTrue ( conditional )? )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:249:79: ^( IF $ifCondition $ifTrue ( conditional )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(IF, "IF"), root_1);

                        adaptor.addChild(root_1, stream_ifCondition.nextTree());
                        adaptor.addChild(root_1, stream_ifTrue.nextTree());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:249:105: ( conditional )?
                        if ( stream_conditional.hasNext() ) {
                            adaptor.addChild(root_1, stream_conditional.nextTree());

                        }
                        stream_conditional.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:250:7: ELSE statement
                    {
                    ELSE152=(Token)match(input,ELSE,FOLLOW_ELSE_in_conditional2244); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ELSE.add(ELSE152);

                    pushFollow(FOLLOW_statement_in_conditional2246);
                    statement153=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(statement153.getTree());


                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 250:22: -> statement
                    {
                        adaptor.addChild(root_0, stream_statement.nextTree());

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 15, conditional_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "conditional"

    public static class forInit_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forInit"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:253:1: forInit : ( commaList )? ';' -> ^( ForInit ( commaList )? ) ;
    public final PhpParser.forInit_return forInit() throws RecognitionException {
        PhpParser.forInit_return retval = new PhpParser.forInit_return();
        retval.start = input.LT(1);
        int forInit_StartIndex = input.index();
        CommonTree root_0 = null;

        Token char_literal155=null;
        PhpParser.commaList_return commaList154 = null;


        CommonTree char_literal155_tree=null;
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleSubtreeStream stream_commaList=new RewriteRuleSubtreeStream(adaptor,"rule commaList");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 16) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:254:5: ( ( commaList )? ';' -> ^( ForInit ( commaList )? ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:254:7: ( commaList )? ';'
            {
            // /home/iberiam/phpparser-1.2/grammar/Php.g:254:7: ( commaList )?
            int alt35=2;
            alt35 = dfa35.predict(input);
            switch (alt35) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: commaList
                    {
                    pushFollow(FOLLOW_commaList_in_forInit2267);
                    commaList154=commaList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_commaList.add(commaList154.getTree());

                    }
                    break;

            }

            char_literal155=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_forInit2270); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal155);



            // AST REWRITE
            // elements: commaList
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 254:22: -> ^( ForInit ( commaList )? )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:254:25: ^( ForInit ( commaList )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ForInit, "ForInit"), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:254:35: ( commaList )?
                if ( stream_commaList.hasNext() ) {
                    adaptor.addChild(root_1, stream_commaList.nextTree());

                }
                stream_commaList.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 16, forInit_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "forInit"

    public static class forCondition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forCondition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:257:1: forCondition : ( commaList )? ';' -> ^( ForCondition ( commaList )? ) ;
    public final PhpParser.forCondition_return forCondition() throws RecognitionException {
        PhpParser.forCondition_return retval = new PhpParser.forCondition_return();
        retval.start = input.LT(1);
        int forCondition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token char_literal157=null;
        PhpParser.commaList_return commaList156 = null;


        CommonTree char_literal157_tree=null;
        RewriteRuleTokenStream stream_SEMICOLON=new RewriteRuleTokenStream(adaptor,"token SEMICOLON");
        RewriteRuleSubtreeStream stream_commaList=new RewriteRuleSubtreeStream(adaptor,"rule commaList");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 17) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:258:5: ( ( commaList )? ';' -> ^( ForCondition ( commaList )? ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:258:7: ( commaList )? ';'
            {
            // /home/iberiam/phpparser-1.2/grammar/Php.g:258:7: ( commaList )?
            int alt36=2;
            alt36 = dfa36.predict(input);
            switch (alt36) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: commaList
                    {
                    pushFollow(FOLLOW_commaList_in_forCondition2296);
                    commaList156=commaList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_commaList.add(commaList156.getTree());

                    }
                    break;

            }

            char_literal157=(Token)match(input,SEMICOLON,FOLLOW_SEMICOLON_in_forCondition2299); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_SEMICOLON.add(char_literal157);



            // AST REWRITE
            // elements: commaList
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 258:22: -> ^( ForCondition ( commaList )? )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:258:25: ^( ForCondition ( commaList )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ForCondition, "ForCondition"), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:258:40: ( commaList )?
                if ( stream_commaList.hasNext() ) {
                    adaptor.addChild(root_1, stream_commaList.nextTree());

                }
                stream_commaList.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 17, forCondition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "forCondition"

    public static class forUpdate_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forUpdate"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:261:1: forUpdate : ( commaList )? -> ^( ForUpdate ( commaList )? ) ;
    public final PhpParser.forUpdate_return forUpdate() throws RecognitionException {
        PhpParser.forUpdate_return retval = new PhpParser.forUpdate_return();
        retval.start = input.LT(1);
        int forUpdate_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.commaList_return commaList158 = null;


        RewriteRuleSubtreeStream stream_commaList=new RewriteRuleSubtreeStream(adaptor,"rule commaList");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 18) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:262:5: ( ( commaList )? -> ^( ForUpdate ( commaList )? ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:262:7: ( commaList )?
            {
            // /home/iberiam/phpparser-1.2/grammar/Php.g:262:7: ( commaList )?
            int alt37=2;
            alt37 = dfa37.predict(input);
            switch (alt37) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: commaList
                    {
                    pushFollow(FOLLOW_commaList_in_forUpdate2329);
                    commaList158=commaList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_commaList.add(commaList158.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: commaList
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 262:18: -> ^( ForUpdate ( commaList )? )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:262:21: ^( ForUpdate ( commaList )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ForUpdate, "ForUpdate"), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:262:33: ( commaList )?
                if ( stream_commaList.hasNext() ) {
                    adaptor.addChild(root_1, stream_commaList.nextTree());

                }
                stream_commaList.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 18, forUpdate_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "forUpdate"

    public static class cases_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cases"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:265:1: cases : ( casestatement )* defaultcase ;
    public final PhpParser.cases_return cases() throws RecognitionException {
        PhpParser.cases_return retval = new PhpParser.cases_return();
        retval.start = input.LT(1);
        int cases_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.casestatement_return casestatement159 = null;

        PhpParser.defaultcase_return defaultcase160 = null;



        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 19) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:266:5: ( ( casestatement )* defaultcase )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:266:7: ( casestatement )* defaultcase
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/Php.g:266:7: ( casestatement )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==CASE) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: casestatement
            	    {
            	    pushFollow(FOLLOW_casestatement_in_cases2357);
            	    casestatement159=casestatement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, casestatement159.getTree());

            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);

            pushFollow(FOLLOW_defaultcase_in_cases2361);
            defaultcase160=defaultcase();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, defaultcase160.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 19, cases_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "cases"

    public static class casestatement_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "casestatement"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:269:1: casestatement : CASE expression ':' ( statement )* ;
    public final PhpParser.casestatement_return casestatement() throws RecognitionException {
        PhpParser.casestatement_return retval = new PhpParser.casestatement_return();
        retval.start = input.LT(1);
        int casestatement_StartIndex = input.index();
        CommonTree root_0 = null;

        Token CASE161=null;
        Token char_literal163=null;
        PhpParser.expression_return expression162 = null;

        PhpParser.statement_return statement164 = null;


        CommonTree CASE161_tree=null;
        CommonTree char_literal163_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 20) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:270:5: ( CASE expression ':' ( statement )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:270:7: CASE expression ':' ( statement )*
            {
            root_0 = (CommonTree)adaptor.nil();

            CASE161=(Token)match(input,CASE,FOLLOW_CASE_in_casestatement2378); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            CASE161_tree = (CommonTree)adaptor.create(CASE161);
            root_0 = (CommonTree)adaptor.becomeRoot(CASE161_tree, root_0);
            }
            pushFollow(FOLLOW_expression_in_casestatement2381);
            expression162=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, expression162.getTree());
            char_literal163=(Token)match(input,COLON,FOLLOW_COLON_in_casestatement2383); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/Php.g:270:29: ( statement )*
            loop39:
            do {
                int alt39=2;
                alt39 = dfa39.predict(input);
                switch (alt39) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_casestatement2386);
            	    statement164=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement164.getTree());

            	    }
            	    break;

            	default :
            	    break loop39;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 20, casestatement_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "casestatement"

    public static class defaultcase_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "defaultcase"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:273:1: defaultcase : ( DEFAULT ':' ( statement )* ) ;
    public final PhpParser.defaultcase_return defaultcase() throws RecognitionException {
        PhpParser.defaultcase_return retval = new PhpParser.defaultcase_return();
        retval.start = input.LT(1);
        int defaultcase_StartIndex = input.index();
        CommonTree root_0 = null;

        Token DEFAULT165=null;
        Token char_literal166=null;
        PhpParser.statement_return statement167 = null;


        CommonTree DEFAULT165_tree=null;
        CommonTree char_literal166_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 21) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:274:5: ( ( DEFAULT ':' ( statement )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:274:7: ( DEFAULT ':' ( statement )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/Php.g:274:7: ( DEFAULT ':' ( statement )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:274:8: DEFAULT ':' ( statement )*
            {
            DEFAULT165=(Token)match(input,DEFAULT,FOLLOW_DEFAULT_in_defaultcase2406); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            DEFAULT165_tree = (CommonTree)adaptor.create(DEFAULT165);
            root_0 = (CommonTree)adaptor.becomeRoot(DEFAULT165_tree, root_0);
            }
            char_literal166=(Token)match(input,COLON,FOLLOW_COLON_in_defaultcase2409); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/Php.g:274:22: ( statement )*
            loop40:
            do {
                int alt40=2;
                alt40 = dfa40.predict(input);
                switch (alt40) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_defaultcase2412);
            	    statement167=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, statement167.getTree());

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);


            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 21, defaultcase_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "defaultcase"

    public static class catchStatement_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catchStatement"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:277:1: catchStatement : CATCH '(' catchException ')' statement ( catchStatement )? -> ^( CATCH catchException statement ( catchStatement )? ) ;
    public final PhpParser.catchStatement_return catchStatement() throws RecognitionException {
        PhpParser.catchStatement_return retval = new PhpParser.catchStatement_return();
        retval.start = input.LT(1);
        int catchStatement_StartIndex = input.index();
        CommonTree root_0 = null;

        Token CATCH168=null;
        Token char_literal169=null;
        Token char_literal171=null;
        PhpParser.catchException_return catchException170 = null;

        PhpParser.statement_return statement172 = null;

        PhpParser.catchStatement_return catchStatement173 = null;


        CommonTree CATCH168_tree=null;
        CommonTree char_literal169_tree=null;
        CommonTree char_literal171_tree=null;
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_CATCH=new RewriteRuleTokenStream(adaptor,"token CATCH");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        RewriteRuleSubtreeStream stream_catchException=new RewriteRuleSubtreeStream(adaptor,"rule catchException");
        RewriteRuleSubtreeStream stream_catchStatement=new RewriteRuleSubtreeStream(adaptor,"rule catchStatement");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 22) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:278:5: ( CATCH '(' catchException ')' statement ( catchStatement )? -> ^( CATCH catchException statement ( catchStatement )? ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:278:7: CATCH '(' catchException ')' statement ( catchStatement )?
            {
            CATCH168=(Token)match(input,CATCH,FOLLOW_CATCH_in_catchStatement2431); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CATCH.add(CATCH168);

            char_literal169=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_catchStatement2433); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal169);

            pushFollow(FOLLOW_catchException_in_catchStatement2435);
            catchException170=catchException();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_catchException.add(catchException170.getTree());
            char_literal171=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_catchStatement2437); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal171);

            pushFollow(FOLLOW_statement_in_catchStatement2439);
            statement172=statement();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_statement.add(statement172.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:278:46: ( catchStatement )?
            int alt41=2;
            alt41 = dfa41.predict(input);
            switch (alt41) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: catchStatement
                    {
                    pushFollow(FOLLOW_catchStatement_in_catchStatement2441);
                    catchStatement173=catchStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_catchStatement.add(catchStatement173.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: catchStatement, catchException, CATCH, statement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 278:62: -> ^( CATCH catchException statement ( catchStatement )? )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:278:65: ^( CATCH catchException statement ( catchStatement )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(stream_CATCH.nextNode(), root_1);

                adaptor.addChild(root_1, stream_catchException.nextTree());
                adaptor.addChild(root_1, stream_statement.nextTree());
                // /home/iberiam/phpparser-1.2/grammar/Php.g:278:98: ( catchStatement )?
                if ( stream_catchStatement.hasNext() ) {
                    adaptor.addChild(root_1, stream_catchStatement.nextTree());

                }
                stream_catchStatement.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 22, catchStatement_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "catchStatement"

    public static class catchException_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catchException"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:281:1: catchException : UnquotedString variable ;
    public final PhpParser.catchException_return catchException() throws RecognitionException {
        PhpParser.catchException_return retval = new PhpParser.catchException_return();
        retval.start = input.LT(1);
        int catchException_StartIndex = input.index();
        CommonTree root_0 = null;

        Token UnquotedString174=null;
        PhpParser.variable_return variable175 = null;


        CommonTree UnquotedString174_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 23) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:282:5: ( UnquotedString variable )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:282:7: UnquotedString variable
            {
            root_0 = (CommonTree)adaptor.nil();

            UnquotedString174=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_catchException2472); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString174_tree = (CommonTree)adaptor.create(UnquotedString174);
            adaptor.addChild(root_0, UnquotedString174_tree);
            }
            pushFollow(FOLLOW_variable_in_catchException2474);
            variable175=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, variable175.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 23, catchException_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "catchException"

    public static class throwException_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "throwException"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:285:1: throwException : ( 'new' UnquotedString '(' atom ')' -> ^( NEW UnquotedString atom ) | variable );
    public final PhpParser.throwException_return throwException() throws RecognitionException {
        PhpParser.throwException_return retval = new PhpParser.throwException_return();
        retval.start = input.LT(1);
        int throwException_StartIndex = input.index();
        CommonTree root_0 = null;

        Token string_literal176=null;
        Token UnquotedString177=null;
        Token char_literal178=null;
        Token char_literal180=null;
        PhpParser.atom_return atom179 = null;

        PhpParser.variable_return variable181 = null;


        CommonTree string_literal176_tree=null;
        CommonTree UnquotedString177_tree=null;
        CommonTree char_literal178_tree=null;
        CommonTree char_literal180_tree=null;
        RewriteRuleTokenStream stream_NEW=new RewriteRuleTokenStream(adaptor,"token NEW");
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleSubtreeStream stream_atom=new RewriteRuleSubtreeStream(adaptor,"rule atom");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 24) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:286:5: ( 'new' UnquotedString '(' atom ')' -> ^( NEW UnquotedString atom ) | variable )
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==NEW) ) {
                alt42=1;
            }
            else if ( (LA42_0==DOLLAR||LA42_0==UnquotedString) ) {
                alt42=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 42, 0, input);

                throw nvae;
            }
            switch (alt42) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:286:7: 'new' UnquotedString '(' atom ')'
                    {
                    string_literal176=(Token)match(input,NEW,FOLLOW_NEW_in_throwException2491); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_NEW.add(string_literal176);

                    UnquotedString177=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_throwException2493); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString177);

                    char_literal178=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_throwException2495); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(char_literal178);

                    pushFollow(FOLLOW_atom_in_throwException2497);
                    atom179=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_atom.add(atom179.getTree());
                    char_literal180=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_throwException2499); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(char_literal180);



                    // AST REWRITE
                    // elements: UnquotedString, atom
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 286:41: -> ^( NEW UnquotedString atom )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:286:44: ^( NEW UnquotedString atom )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(NEW, "NEW"), root_1);

                        adaptor.addChild(root_1, stream_UnquotedString.nextNode());
                        adaptor.addChild(root_1, stream_atom.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:287:7: variable
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_throwException2517);
                    variable181=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable181.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 24, throwException_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "throwException"

    public static class declareList_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declareList"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:290:1: declareList : commaList -> ^( DeclareList commaList ) ;
    public final PhpParser.declareList_return declareList() throws RecognitionException {
        PhpParser.declareList_return retval = new PhpParser.declareList_return();
        retval.start = input.LT(1);
        int declareList_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.commaList_return commaList182 = null;


        RewriteRuleSubtreeStream stream_commaList=new RewriteRuleSubtreeStream(adaptor,"rule commaList");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 25) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:291:5: ( commaList -> ^( DeclareList commaList ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:291:7: commaList
            {
            pushFollow(FOLLOW_commaList_in_declareList2534);
            commaList182=commaList();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_commaList.add(commaList182.getTree());


            // AST REWRITE
            // elements: commaList
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 291:17: -> ^( DeclareList commaList )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:291:20: ^( DeclareList commaList )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(DeclareList, "DeclareList"), root_1);

                adaptor.addChild(root_1, stream_commaList.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 25, declareList_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "declareList"

    public static class useFilename_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "useFilename"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:294:1: useFilename : ( atom | '(' atom ')' );
    public final PhpParser.useFilename_return useFilename() throws RecognitionException {
        PhpParser.useFilename_return retval = new PhpParser.useFilename_return();
        retval.start = input.LT(1);
        int useFilename_StartIndex = input.index();
        CommonTree root_0 = null;

        Token char_literal184=null;
        Token char_literal186=null;
        PhpParser.atom_return atom183 = null;

        PhpParser.atom_return atom185 = null;


        CommonTree char_literal184_tree=null;
        CommonTree char_literal186_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 26) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:295:5: ( atom | '(' atom ')' )
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==Integer||(LA43_0>=Array && LA43_0<=Boolean)) ) {
                alt43=1;
            }
            else if ( (LA43_0==OPEN_BRACE) ) {
                alt43=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 43, 0, input);

                throw nvae;
            }
            switch (alt43) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:295:7: atom
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_atom_in_useFilename2559);
                    atom183=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, atom183.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:296:7: '(' atom ')'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    char_literal184=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_useFilename2567); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    char_literal184_tree = (CommonTree)adaptor.create(char_literal184);
                    adaptor.addChild(root_0, char_literal184_tree);
                    }
                    pushFollow(FOLLOW_atom_in_useFilename2569);
                    atom185=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, atom185.getTree());
                    char_literal186=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_useFilename2571); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    char_literal186_tree = (CommonTree)adaptor.create(char_literal186);
                    adaptor.addChild(root_0, char_literal186_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 26, useFilename_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "useFilename"

    public static class functionDefinition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "functionDefinition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:299:1: functionDefinition : FUNCTION UnquotedString parametersDefinition bracketedBlock -> ^( FUNCTION UnquotedString parametersDefinition bracketedBlock ) ;
    public final PhpParser.functionDefinition_return functionDefinition() throws RecognitionException {
        PhpParser.functionDefinition_return retval = new PhpParser.functionDefinition_return();
        retval.start = input.LT(1);
        int functionDefinition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token FUNCTION187=null;
        Token UnquotedString188=null;
        PhpParser.parametersDefinition_return parametersDefinition189 = null;

        PhpParser.bracketedBlock_return bracketedBlock190 = null;


        CommonTree FUNCTION187_tree=null;
        CommonTree UnquotedString188_tree=null;
        RewriteRuleTokenStream stream_FUNCTION=new RewriteRuleTokenStream(adaptor,"token FUNCTION");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");
        RewriteRuleSubtreeStream stream_parametersDefinition=new RewriteRuleSubtreeStream(adaptor,"rule parametersDefinition");
        RewriteRuleSubtreeStream stream_bracketedBlock=new RewriteRuleSubtreeStream(adaptor,"rule bracketedBlock");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 27) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:300:5: ( FUNCTION UnquotedString parametersDefinition bracketedBlock -> ^( FUNCTION UnquotedString parametersDefinition bracketedBlock ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:300:7: FUNCTION UnquotedString parametersDefinition bracketedBlock
            {
            FUNCTION187=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_functionDefinition2588); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_FUNCTION.add(FUNCTION187);

            UnquotedString188=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_functionDefinition2590); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString188);

            pushFollow(FOLLOW_parametersDefinition_in_functionDefinition2592);
            parametersDefinition189=parametersDefinition();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_parametersDefinition.add(parametersDefinition189.getTree());
            pushFollow(FOLLOW_bracketedBlock_in_functionDefinition2594);
            bracketedBlock190=bracketedBlock();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_bracketedBlock.add(bracketedBlock190.getTree());


            // AST REWRITE
            // elements: parametersDefinition, FUNCTION, UnquotedString, bracketedBlock
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 300:67: -> ^( FUNCTION UnquotedString parametersDefinition bracketedBlock )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:301:9: ^( FUNCTION UnquotedString parametersDefinition bracketedBlock )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(stream_FUNCTION.nextNode(), root_1);

                adaptor.addChild(root_1, stream_UnquotedString.nextNode());
                adaptor.addChild(root_1, stream_parametersDefinition.nextTree());
                adaptor.addChild(root_1, stream_bracketedBlock.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 27, functionDefinition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "functionDefinition"

    public static class parametersDefinition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parametersDefinition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:304:1: parametersDefinition : OPEN_BRACE ( paramDef ( COMMA paramDef )* )? CLOSE_BRACE -> ^( Params ( paramDef )* ) ;
    public final PhpParser.parametersDefinition_return parametersDefinition() throws RecognitionException {
        PhpParser.parametersDefinition_return retval = new PhpParser.parametersDefinition_return();
        retval.start = input.LT(1);
        int parametersDefinition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token OPEN_BRACE191=null;
        Token COMMA193=null;
        Token CLOSE_BRACE195=null;
        PhpParser.paramDef_return paramDef192 = null;

        PhpParser.paramDef_return paramDef194 = null;


        CommonTree OPEN_BRACE191_tree=null;
        CommonTree COMMA193_tree=null;
        CommonTree CLOSE_BRACE195_tree=null;
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleSubtreeStream stream_paramDef=new RewriteRuleSubtreeStream(adaptor,"rule paramDef");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 28) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:305:5: ( OPEN_BRACE ( paramDef ( COMMA paramDef )* )? CLOSE_BRACE -> ^( Params ( paramDef )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:305:7: OPEN_BRACE ( paramDef ( COMMA paramDef )* )? CLOSE_BRACE
            {
            OPEN_BRACE191=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_parametersDefinition2632); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_OPEN_BRACE.add(OPEN_BRACE191);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:305:18: ( paramDef ( COMMA paramDef )* )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==DOLLAR||LA45_0==AMPERSAND) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:305:19: paramDef ( COMMA paramDef )*
                    {
                    pushFollow(FOLLOW_paramDef_in_parametersDefinition2635);
                    paramDef192=paramDef();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_paramDef.add(paramDef192.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:305:28: ( COMMA paramDef )*
                    loop44:
                    do {
                        int alt44=2;
                        int LA44_0 = input.LA(1);

                        if ( (LA44_0==COMMA) ) {
                            alt44=1;
                        }


                        switch (alt44) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/Php.g:305:29: COMMA paramDef
                    	    {
                    	    COMMA193=(Token)match(input,COMMA,FOLLOW_COMMA_in_parametersDefinition2638); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_COMMA.add(COMMA193);

                    	    pushFollow(FOLLOW_paramDef_in_parametersDefinition2640);
                    	    paramDef194=paramDef();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_paramDef.add(paramDef194.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop44;
                        }
                    } while (true);


                    }
                    break;

            }

            CLOSE_BRACE195=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_parametersDefinition2646); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(CLOSE_BRACE195);



            // AST REWRITE
            // elements: paramDef
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 305:60: -> ^( Params ( paramDef )* )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:305:63: ^( Params ( paramDef )* )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Params, "Params"), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:305:72: ( paramDef )*
                while ( stream_paramDef.hasNext() ) {
                    adaptor.addChild(root_1, stream_paramDef.nextTree());

                }
                stream_paramDef.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 28, parametersDefinition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "parametersDefinition"

    public static class paramDef_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "paramDef"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:308:1: paramDef : paramName ( EQUALS atom )? ;
    public final PhpParser.paramDef_return paramDef() throws RecognitionException {
        PhpParser.paramDef_return retval = new PhpParser.paramDef_return();
        retval.start = input.LT(1);
        int paramDef_StartIndex = input.index();
        CommonTree root_0 = null;

        Token EQUALS197=null;
        PhpParser.paramName_return paramName196 = null;

        PhpParser.atom_return atom198 = null;


        CommonTree EQUALS197_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 29) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:309:5: ( paramName ( EQUALS atom )? )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:309:7: paramName ( EQUALS atom )?
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_paramName_in_paramDef2673);
            paramName196=paramName();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, paramName196.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:309:17: ( EQUALS atom )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==EQUALS) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:309:18: EQUALS atom
                    {
                    EQUALS197=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_paramDef2676); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EQUALS197_tree = (CommonTree)adaptor.create(EQUALS197);
                    root_0 = (CommonTree)adaptor.becomeRoot(EQUALS197_tree, root_0);
                    }
                    pushFollow(FOLLOW_atom_in_paramDef2679);
                    atom198=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, atom198.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 29, paramDef_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "paramDef"

    public static class paramName_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "paramName"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:312:1: paramName : ( DOLLAR UnquotedString | AMPERSAND DOLLAR UnquotedString -> ^( AMPERSAND ^( DOLLAR UnquotedString ) ) );
    public final PhpParser.paramName_return paramName() throws RecognitionException {
        PhpParser.paramName_return retval = new PhpParser.paramName_return();
        retval.start = input.LT(1);
        int paramName_StartIndex = input.index();
        CommonTree root_0 = null;

        Token DOLLAR199=null;
        Token UnquotedString200=null;
        Token AMPERSAND201=null;
        Token DOLLAR202=null;
        Token UnquotedString203=null;

        CommonTree DOLLAR199_tree=null;
        CommonTree UnquotedString200_tree=null;
        CommonTree AMPERSAND201_tree=null;
        CommonTree DOLLAR202_tree=null;
        CommonTree UnquotedString203_tree=null;
        RewriteRuleTokenStream stream_DOLLAR=new RewriteRuleTokenStream(adaptor,"token DOLLAR");
        RewriteRuleTokenStream stream_AMPERSAND=new RewriteRuleTokenStream(adaptor,"token AMPERSAND");
        RewriteRuleTokenStream stream_UnquotedString=new RewriteRuleTokenStream(adaptor,"token UnquotedString");

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 30) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:313:5: ( DOLLAR UnquotedString | AMPERSAND DOLLAR UnquotedString -> ^( AMPERSAND ^( DOLLAR UnquotedString ) ) )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==DOLLAR) ) {
                alt47=1;
            }
            else if ( (LA47_0==AMPERSAND) ) {
                alt47=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:313:7: DOLLAR UnquotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    DOLLAR199=(Token)match(input,DOLLAR,FOLLOW_DOLLAR_in_paramName2698); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR199_tree = (CommonTree)adaptor.create(DOLLAR199);
                    root_0 = (CommonTree)adaptor.becomeRoot(DOLLAR199_tree, root_0);
                    }
                    UnquotedString200=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_paramName2701); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString200_tree = (CommonTree)adaptor.create(UnquotedString200);
                    adaptor.addChild(root_0, UnquotedString200_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:314:7: AMPERSAND DOLLAR UnquotedString
                    {
                    AMPERSAND201=(Token)match(input,AMPERSAND,FOLLOW_AMPERSAND_in_paramName2709); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_AMPERSAND.add(AMPERSAND201);

                    DOLLAR202=(Token)match(input,DOLLAR,FOLLOW_DOLLAR_in_paramName2711); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_DOLLAR.add(DOLLAR202);

                    UnquotedString203=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_paramName2713); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_UnquotedString.add(UnquotedString203);



                    // AST REWRITE
                    // elements: DOLLAR, AMPERSAND, UnquotedString
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 314:39: -> ^( AMPERSAND ^( DOLLAR UnquotedString ) )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:314:42: ^( AMPERSAND ^( DOLLAR UnquotedString ) )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot(stream_AMPERSAND.nextNode(), root_1);

                        // /home/iberiam/phpparser-1.2/grammar/Php.g:314:54: ^( DOLLAR UnquotedString )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot(stream_DOLLAR.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_UnquotedString.nextNode());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 30, paramName_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "paramName"

    public static class commaList_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "commaList"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:317:1: commaList : expression ( ',' expression )* ;
    public final PhpParser.commaList_return commaList() throws RecognitionException {
        PhpParser.commaList_return retval = new PhpParser.commaList_return();
        retval.start = input.LT(1);
        int commaList_StartIndex = input.index();
        CommonTree root_0 = null;

        Token char_literal205=null;
        PhpParser.expression_return expression204 = null;

        PhpParser.expression_return expression206 = null;


        CommonTree char_literal205_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 31) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:318:5: ( expression ( ',' expression )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:318:7: expression ( ',' expression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_expression_in_commaList2742);
            expression204=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, expression204.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:318:18: ( ',' expression )*
            loop48:
            do {
                int alt48=2;
                int LA48_0 = input.LA(1);

                if ( (LA48_0==COMMA) ) {
                    alt48=1;
                }


                switch (alt48) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:318:19: ',' expression
            	    {
            	    char_literal205=(Token)match(input,COMMA,FOLLOW_COMMA_in_commaList2745); if (state.failed) return retval;
            	    pushFollow(FOLLOW_expression_in_commaList2748);
            	    expression206=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression206.getTree());

            	    }
            	    break;

            	default :
            	    break loop48;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 31, commaList_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "commaList"

    public static class expression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:321:1: expression : weakLogicalOr ;
    public final PhpParser.expression_return expression() throws RecognitionException {
        PhpParser.expression_return retval = new PhpParser.expression_return();
        retval.start = input.LT(1);
        int expression_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.weakLogicalOr_return weakLogicalOr207 = null;



        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 32) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:322:5: ( weakLogicalOr )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:322:7: weakLogicalOr
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_weakLogicalOr_in_expression2772);
            weakLogicalOr207=weakLogicalOr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, weakLogicalOr207.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 32, expression_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class weakLogicalOr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "weakLogicalOr"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:325:1: weakLogicalOr : weakLogicalXor ( OR weakLogicalXor )* ;
    public final PhpParser.weakLogicalOr_return weakLogicalOr() throws RecognitionException {
        PhpParser.weakLogicalOr_return retval = new PhpParser.weakLogicalOr_return();
        retval.start = input.LT(1);
        int weakLogicalOr_StartIndex = input.index();
        CommonTree root_0 = null;

        Token OR209=null;
        PhpParser.weakLogicalXor_return weakLogicalXor208 = null;

        PhpParser.weakLogicalXor_return weakLogicalXor210 = null;


        CommonTree OR209_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 33) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:326:5: ( weakLogicalXor ( OR weakLogicalXor )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:326:7: weakLogicalXor ( OR weakLogicalXor )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_weakLogicalXor_in_weakLogicalOr2789);
            weakLogicalXor208=weakLogicalXor();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, weakLogicalXor208.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:326:22: ( OR weakLogicalXor )*
            loop49:
            do {
                int alt49=2;
                alt49 = dfa49.predict(input);
                switch (alt49) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:326:23: OR weakLogicalXor
            	    {
            	    OR209=(Token)match(input,OR,FOLLOW_OR_in_weakLogicalOr2792); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    OR209_tree = (CommonTree)adaptor.create(OR209);
            	    root_0 = (CommonTree)adaptor.becomeRoot(OR209_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_weakLogicalXor_in_weakLogicalOr2795);
            	    weakLogicalXor210=weakLogicalXor();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, weakLogicalXor210.getTree());

            	    }
            	    break;

            	default :
            	    break loop49;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 33, weakLogicalOr_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "weakLogicalOr"

    public static class weakLogicalXor_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "weakLogicalXor"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:329:1: weakLogicalXor : weakLogicalAnd ( XOR weakLogicalAnd )* ;
    public final PhpParser.weakLogicalXor_return weakLogicalXor() throws RecognitionException {
        PhpParser.weakLogicalXor_return retval = new PhpParser.weakLogicalXor_return();
        retval.start = input.LT(1);
        int weakLogicalXor_StartIndex = input.index();
        CommonTree root_0 = null;

        Token XOR212=null;
        PhpParser.weakLogicalAnd_return weakLogicalAnd211 = null;

        PhpParser.weakLogicalAnd_return weakLogicalAnd213 = null;


        CommonTree XOR212_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 34) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:330:5: ( weakLogicalAnd ( XOR weakLogicalAnd )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:330:7: weakLogicalAnd ( XOR weakLogicalAnd )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_weakLogicalAnd_in_weakLogicalXor2814);
            weakLogicalAnd211=weakLogicalAnd();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, weakLogicalAnd211.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:330:22: ( XOR weakLogicalAnd )*
            loop50:
            do {
                int alt50=2;
                alt50 = dfa50.predict(input);
                switch (alt50) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:330:23: XOR weakLogicalAnd
            	    {
            	    XOR212=(Token)match(input,XOR,FOLLOW_XOR_in_weakLogicalXor2817); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    XOR212_tree = (CommonTree)adaptor.create(XOR212);
            	    root_0 = (CommonTree)adaptor.becomeRoot(XOR212_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_weakLogicalAnd_in_weakLogicalXor2820);
            	    weakLogicalAnd213=weakLogicalAnd();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, weakLogicalAnd213.getTree());

            	    }
            	    break;

            	default :
            	    break loop50;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 34, weakLogicalXor_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "weakLogicalXor"

    public static class weakLogicalAnd_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "weakLogicalAnd"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:333:1: weakLogicalAnd : assignment ( AND assignment )* ;
    public final PhpParser.weakLogicalAnd_return weakLogicalAnd() throws RecognitionException {
        PhpParser.weakLogicalAnd_return retval = new PhpParser.weakLogicalAnd_return();
        retval.start = input.LT(1);
        int weakLogicalAnd_StartIndex = input.index();
        CommonTree root_0 = null;

        Token AND215=null;
        PhpParser.assignment_return assignment214 = null;

        PhpParser.assignment_return assignment216 = null;


        CommonTree AND215_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 35) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:334:5: ( assignment ( AND assignment )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:334:7: assignment ( AND assignment )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_assignment_in_weakLogicalAnd2843);
            assignment214=assignment();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment214.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:334:18: ( AND assignment )*
            loop51:
            do {
                int alt51=2;
                alt51 = dfa51.predict(input);
                switch (alt51) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:334:19: AND assignment
            	    {
            	    AND215=(Token)match(input,AND,FOLLOW_AND_in_weakLogicalAnd2846); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    AND215_tree = (CommonTree)adaptor.create(AND215);
            	    root_0 = (CommonTree)adaptor.becomeRoot(AND215_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_assignment_in_weakLogicalAnd2849);
            	    assignment216=assignment();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment216.getTree());

            	    }
            	    break;

            	default :
            	    break loop51;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 35, weakLogicalAnd_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "weakLogicalAnd"

    public static class assignment_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:337:1: assignment : ( name ( ( EQUALS | AsignmentOperator ) assignment ) | ternary );
    public final PhpParser.assignment_return assignment() throws RecognitionException {
        PhpParser.assignment_return retval = new PhpParser.assignment_return();
        retval.start = input.LT(1);
        int assignment_StartIndex = input.index();
        CommonTree root_0 = null;

        Token set218=null;
        PhpParser.name_return name217 = null;

        PhpParser.assignment_return assignment219 = null;

        PhpParser.ternary_return ternary220 = null;


        CommonTree set218_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 36) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:338:5: ( name ( ( EQUALS | AsignmentOperator ) assignment ) | ternary )
            int alt52=2;
            alt52 = dfa52.predict(input);
            switch (alt52) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:338:7: name ( ( EQUALS | AsignmentOperator ) assignment )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_name_in_assignment2868);
                    name217=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, name217.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:338:12: ( ( EQUALS | AsignmentOperator ) assignment )
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:338:13: ( EQUALS | AsignmentOperator ) assignment
                    {
                    set218=(Token)input.LT(1);
                    set218=(Token)input.LT(1);
                    if ( input.LA(1)==EQUALS||input.LA(1)==AsignmentOperator ) {
                        input.consume();
                        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set218), root_0);
                        state.errorRecovery=false;state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }

                    pushFollow(FOLLOW_assignment_in_assignment2880);
                    assignment219=assignment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment219.getTree());

                    }


                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:339:7: ternary
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_ternary_in_assignment2889);
                    ternary220=ternary();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, ternary220.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 36, assignment_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "assignment"

    public static class ternary_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ternary"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:342:1: ternary : ( logicalOr QUESTION_MARK expression COLON expression -> ^( IfExpression logicalOr ( expression )* ) | logicalOr );
    public final PhpParser.ternary_return ternary() throws RecognitionException {
        PhpParser.ternary_return retval = new PhpParser.ternary_return();
        retval.start = input.LT(1);
        int ternary_StartIndex = input.index();
        CommonTree root_0 = null;

        Token QUESTION_MARK222=null;
        Token COLON224=null;
        PhpParser.logicalOr_return logicalOr221 = null;

        PhpParser.expression_return expression223 = null;

        PhpParser.expression_return expression225 = null;

        PhpParser.logicalOr_return logicalOr226 = null;


        CommonTree QUESTION_MARK222_tree=null;
        CommonTree COLON224_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_QUESTION_MARK=new RewriteRuleTokenStream(adaptor,"token QUESTION_MARK");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_logicalOr=new RewriteRuleSubtreeStream(adaptor,"rule logicalOr");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 37) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:343:5: ( logicalOr QUESTION_MARK expression COLON expression -> ^( IfExpression logicalOr ( expression )* ) | logicalOr )
            int alt53=2;
            alt53 = dfa53.predict(input);
            switch (alt53) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:343:7: logicalOr QUESTION_MARK expression COLON expression
                    {
                    pushFollow(FOLLOW_logicalOr_in_ternary2906);
                    logicalOr221=logicalOr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_logicalOr.add(logicalOr221.getTree());
                    QUESTION_MARK222=(Token)match(input,QUESTION_MARK,FOLLOW_QUESTION_MARK_in_ternary2908); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_QUESTION_MARK.add(QUESTION_MARK222);

                    pushFollow(FOLLOW_expression_in_ternary2910);
                    expression223=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression223.getTree());
                    COLON224=(Token)match(input,COLON,FOLLOW_COLON_in_ternary2912); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_COLON.add(COLON224);

                    pushFollow(FOLLOW_expression_in_ternary2914);
                    expression225=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression225.getTree());


                    // AST REWRITE
                    // elements: expression, logicalOr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 343:59: -> ^( IfExpression logicalOr ( expression )* )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:343:62: ^( IfExpression logicalOr ( expression )* )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(IfExpression, "IfExpression"), root_1);

                        adaptor.addChild(root_1, stream_logicalOr.nextTree());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:343:87: ( expression )*
                        while ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:344:7: logicalOr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_logicalOr_in_ternary2933);
                    logicalOr226=logicalOr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalOr226.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 37, ternary_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "ternary"

    public static class logicalOr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logicalOr"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:347:1: logicalOr : logicalAnd ( LOGICAL_OR logicalAnd )* ;
    public final PhpParser.logicalOr_return logicalOr() throws RecognitionException {
        PhpParser.logicalOr_return retval = new PhpParser.logicalOr_return();
        retval.start = input.LT(1);
        int logicalOr_StartIndex = input.index();
        CommonTree root_0 = null;

        Token LOGICAL_OR228=null;
        PhpParser.logicalAnd_return logicalAnd227 = null;

        PhpParser.logicalAnd_return logicalAnd229 = null;


        CommonTree LOGICAL_OR228_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 38) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:348:5: ( logicalAnd ( LOGICAL_OR logicalAnd )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:348:7: logicalAnd ( LOGICAL_OR logicalAnd )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_logicalAnd_in_logicalOr2954);
            logicalAnd227=logicalAnd();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalAnd227.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:348:18: ( LOGICAL_OR logicalAnd )*
            loop54:
            do {
                int alt54=2;
                alt54 = dfa54.predict(input);
                switch (alt54) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:348:19: LOGICAL_OR logicalAnd
            	    {
            	    LOGICAL_OR228=(Token)match(input,LOGICAL_OR,FOLLOW_LOGICAL_OR_in_logicalOr2957); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    LOGICAL_OR228_tree = (CommonTree)adaptor.create(LOGICAL_OR228);
            	    root_0 = (CommonTree)adaptor.becomeRoot(LOGICAL_OR228_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_logicalAnd_in_logicalOr2960);
            	    logicalAnd229=logicalAnd();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalAnd229.getTree());

            	    }
            	    break;

            	default :
            	    break loop54;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 38, logicalOr_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "logicalOr"

    public static class logicalAnd_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logicalAnd"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:351:1: logicalAnd : bitwiseOr ( LOGICAL_AND bitwiseOr )* ;
    public final PhpParser.logicalAnd_return logicalAnd() throws RecognitionException {
        PhpParser.logicalAnd_return retval = new PhpParser.logicalAnd_return();
        retval.start = input.LT(1);
        int logicalAnd_StartIndex = input.index();
        CommonTree root_0 = null;

        Token LOGICAL_AND231=null;
        PhpParser.bitwiseOr_return bitwiseOr230 = null;

        PhpParser.bitwiseOr_return bitwiseOr232 = null;


        CommonTree LOGICAL_AND231_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 39) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:352:5: ( bitwiseOr ( LOGICAL_AND bitwiseOr )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:352:7: bitwiseOr ( LOGICAL_AND bitwiseOr )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_bitwiseOr_in_logicalAnd2979);
            bitwiseOr230=bitwiseOr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwiseOr230.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:352:17: ( LOGICAL_AND bitwiseOr )*
            loop55:
            do {
                int alt55=2;
                alt55 = dfa55.predict(input);
                switch (alt55) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:352:18: LOGICAL_AND bitwiseOr
            	    {
            	    LOGICAL_AND231=(Token)match(input,LOGICAL_AND,FOLLOW_LOGICAL_AND_in_logicalAnd2982); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    LOGICAL_AND231_tree = (CommonTree)adaptor.create(LOGICAL_AND231);
            	    root_0 = (CommonTree)adaptor.becomeRoot(LOGICAL_AND231_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitwiseOr_in_logicalAnd2985);
            	    bitwiseOr232=bitwiseOr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, bitwiseOr232.getTree());

            	    }
            	    break;

            	default :
            	    break loop55;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 39, logicalAnd_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "logicalAnd"

    public static class bitwiseOr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitwiseOr"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:355:1: bitwiseOr : bitWiseAnd ( PIPE bitWiseAnd )* ;
    public final PhpParser.bitwiseOr_return bitwiseOr() throws RecognitionException {
        PhpParser.bitwiseOr_return retval = new PhpParser.bitwiseOr_return();
        retval.start = input.LT(1);
        int bitwiseOr_StartIndex = input.index();
        CommonTree root_0 = null;

        Token PIPE234=null;
        PhpParser.bitWiseAnd_return bitWiseAnd233 = null;

        PhpParser.bitWiseAnd_return bitWiseAnd235 = null;


        CommonTree PIPE234_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 40) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:356:5: ( bitWiseAnd ( PIPE bitWiseAnd )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:356:7: bitWiseAnd ( PIPE bitWiseAnd )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_bitWiseAnd_in_bitwiseOr3008);
            bitWiseAnd233=bitWiseAnd();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, bitWiseAnd233.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:356:18: ( PIPE bitWiseAnd )*
            loop56:
            do {
                int alt56=2;
                alt56 = dfa56.predict(input);
                switch (alt56) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:356:19: PIPE bitWiseAnd
            	    {
            	    PIPE234=(Token)match(input,PIPE,FOLLOW_PIPE_in_bitwiseOr3011); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    PIPE234_tree = (CommonTree)adaptor.create(PIPE234);
            	    root_0 = (CommonTree)adaptor.becomeRoot(PIPE234_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_bitWiseAnd_in_bitwiseOr3014);
            	    bitWiseAnd235=bitWiseAnd();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, bitWiseAnd235.getTree());

            	    }
            	    break;

            	default :
            	    break loop56;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 40, bitwiseOr_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "bitwiseOr"

    public static class bitWiseAnd_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitWiseAnd"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:359:1: bitWiseAnd : equalityCheck ( AMPERSAND equalityCheck )* ;
    public final PhpParser.bitWiseAnd_return bitWiseAnd() throws RecognitionException {
        PhpParser.bitWiseAnd_return retval = new PhpParser.bitWiseAnd_return();
        retval.start = input.LT(1);
        int bitWiseAnd_StartIndex = input.index();
        CommonTree root_0 = null;

        Token AMPERSAND237=null;
        PhpParser.equalityCheck_return equalityCheck236 = null;

        PhpParser.equalityCheck_return equalityCheck238 = null;


        CommonTree AMPERSAND237_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 41) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:360:5: ( equalityCheck ( AMPERSAND equalityCheck )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:360:7: equalityCheck ( AMPERSAND equalityCheck )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_equalityCheck_in_bitWiseAnd3033);
            equalityCheck236=equalityCheck();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, equalityCheck236.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:360:21: ( AMPERSAND equalityCheck )*
            loop57:
            do {
                int alt57=2;
                alt57 = dfa57.predict(input);
                switch (alt57) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:360:22: AMPERSAND equalityCheck
            	    {
            	    AMPERSAND237=(Token)match(input,AMPERSAND,FOLLOW_AMPERSAND_in_bitWiseAnd3036); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    AMPERSAND237_tree = (CommonTree)adaptor.create(AMPERSAND237);
            	    root_0 = (CommonTree)adaptor.becomeRoot(AMPERSAND237_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_equalityCheck_in_bitWiseAnd3039);
            	    equalityCheck238=equalityCheck();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, equalityCheck238.getTree());

            	    }
            	    break;

            	default :
            	    break loop57;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 41, bitWiseAnd_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "bitWiseAnd"

    public static class equalityCheck_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "equalityCheck"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:363:1: equalityCheck : comparisionCheck ( EqualityOperator comparisionCheck )? ;
    public final PhpParser.equalityCheck_return equalityCheck() throws RecognitionException {
        PhpParser.equalityCheck_return retval = new PhpParser.equalityCheck_return();
        retval.start = input.LT(1);
        int equalityCheck_StartIndex = input.index();
        CommonTree root_0 = null;

        Token EqualityOperator240=null;
        PhpParser.comparisionCheck_return comparisionCheck239 = null;

        PhpParser.comparisionCheck_return comparisionCheck241 = null;


        CommonTree EqualityOperator240_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 42) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:364:5: ( comparisionCheck ( EqualityOperator comparisionCheck )? )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:364:7: comparisionCheck ( EqualityOperator comparisionCheck )?
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_comparisionCheck_in_equalityCheck3058);
            comparisionCheck239=comparisionCheck();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, comparisionCheck239.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:364:24: ( EqualityOperator comparisionCheck )?
            int alt58=2;
            alt58 = dfa58.predict(input);
            switch (alt58) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:364:25: EqualityOperator comparisionCheck
                    {
                    EqualityOperator240=(Token)match(input,EqualityOperator,FOLLOW_EqualityOperator_in_equalityCheck3061); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EqualityOperator240_tree = (CommonTree)adaptor.create(EqualityOperator240);
                    root_0 = (CommonTree)adaptor.becomeRoot(EqualityOperator240_tree, root_0);
                    }
                    pushFollow(FOLLOW_comparisionCheck_in_equalityCheck3064);
                    comparisionCheck241=comparisionCheck();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, comparisionCheck241.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 42, equalityCheck_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "equalityCheck"

    public static class comparisionCheck_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "comparisionCheck"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:367:1: comparisionCheck : bitWiseShift ( ComparisionOperator bitWiseShift )? ;
    public final PhpParser.comparisionCheck_return comparisionCheck() throws RecognitionException {
        PhpParser.comparisionCheck_return retval = new PhpParser.comparisionCheck_return();
        retval.start = input.LT(1);
        int comparisionCheck_StartIndex = input.index();
        CommonTree root_0 = null;

        Token ComparisionOperator243=null;
        PhpParser.bitWiseShift_return bitWiseShift242 = null;

        PhpParser.bitWiseShift_return bitWiseShift244 = null;


        CommonTree ComparisionOperator243_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 43) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:368:5: ( bitWiseShift ( ComparisionOperator bitWiseShift )? )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:368:7: bitWiseShift ( ComparisionOperator bitWiseShift )?
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_bitWiseShift_in_comparisionCheck3087);
            bitWiseShift242=bitWiseShift();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, bitWiseShift242.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:368:20: ( ComparisionOperator bitWiseShift )?
            int alt59=2;
            alt59 = dfa59.predict(input);
            switch (alt59) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:368:21: ComparisionOperator bitWiseShift
                    {
                    ComparisionOperator243=(Token)match(input,ComparisionOperator,FOLLOW_ComparisionOperator_in_comparisionCheck3090); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ComparisionOperator243_tree = (CommonTree)adaptor.create(ComparisionOperator243);
                    root_0 = (CommonTree)adaptor.becomeRoot(ComparisionOperator243_tree, root_0);
                    }
                    pushFollow(FOLLOW_bitWiseShift_in_comparisionCheck3093);
                    bitWiseShift244=bitWiseShift();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, bitWiseShift244.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 43, comparisionCheck_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "comparisionCheck"

    public static class bitWiseShift_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bitWiseShift"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:371:1: bitWiseShift : addition ( ShiftOperator addition )* ;
    public final PhpParser.bitWiseShift_return bitWiseShift() throws RecognitionException {
        PhpParser.bitWiseShift_return retval = new PhpParser.bitWiseShift_return();
        retval.start = input.LT(1);
        int bitWiseShift_StartIndex = input.index();
        CommonTree root_0 = null;

        Token ShiftOperator246=null;
        PhpParser.addition_return addition245 = null;

        PhpParser.addition_return addition247 = null;


        CommonTree ShiftOperator246_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 44) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:372:5: ( addition ( ShiftOperator addition )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:372:7: addition ( ShiftOperator addition )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_addition_in_bitWiseShift3112);
            addition245=addition();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, addition245.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:372:16: ( ShiftOperator addition )*
            loop60:
            do {
                int alt60=2;
                alt60 = dfa60.predict(input);
                switch (alt60) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:372:17: ShiftOperator addition
            	    {
            	    ShiftOperator246=(Token)match(input,ShiftOperator,FOLLOW_ShiftOperator_in_bitWiseShift3115); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    ShiftOperator246_tree = (CommonTree)adaptor.create(ShiftOperator246);
            	    root_0 = (CommonTree)adaptor.becomeRoot(ShiftOperator246_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_addition_in_bitWiseShift3118);
            	    addition247=addition();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, addition247.getTree());

            	    }
            	    break;

            	default :
            	    break loop60;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 44, bitWiseShift_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "bitWiseShift"

    public static class addition_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "addition"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:375:1: addition : multiplication ( ( PLUS | MINUS | DOT ) multiplication )* ;
    public final PhpParser.addition_return addition() throws RecognitionException {
        PhpParser.addition_return retval = new PhpParser.addition_return();
        retval.start = input.LT(1);
        int addition_StartIndex = input.index();
        CommonTree root_0 = null;

        Token set249=null;
        PhpParser.multiplication_return multiplication248 = null;

        PhpParser.multiplication_return multiplication250 = null;


        CommonTree set249_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 45) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:376:5: ( multiplication ( ( PLUS | MINUS | DOT ) multiplication )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:376:7: multiplication ( ( PLUS | MINUS | DOT ) multiplication )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_multiplication_in_addition3141);
            multiplication248=multiplication();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, multiplication248.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:376:22: ( ( PLUS | MINUS | DOT ) multiplication )*
            loop61:
            do {
                int alt61=2;
                alt61 = dfa61.predict(input);
                switch (alt61) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:376:23: ( PLUS | MINUS | DOT ) multiplication
            	    {
            	    set249=(Token)input.LT(1);
            	    set249=(Token)input.LT(1);
            	    if ( input.LA(1)==DOT||(input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set249), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_multiplication_in_addition3157);
            	    multiplication250=multiplication();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, multiplication250.getTree());

            	    }
            	    break;

            	default :
            	    break loop61;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 45, addition_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "addition"

    public static class multiplication_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplication"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:379:1: multiplication : logicalNot ( ( ASTERISK | FORWARD_SLASH | PERCENT ) logicalNot )* ;
    public final PhpParser.multiplication_return multiplication() throws RecognitionException {
        PhpParser.multiplication_return retval = new PhpParser.multiplication_return();
        retval.start = input.LT(1);
        int multiplication_StartIndex = input.index();
        CommonTree root_0 = null;

        Token set252=null;
        PhpParser.logicalNot_return logicalNot251 = null;

        PhpParser.logicalNot_return logicalNot253 = null;


        CommonTree set252_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 46) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:380:5: ( logicalNot ( ( ASTERISK | FORWARD_SLASH | PERCENT ) logicalNot )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:380:7: logicalNot ( ( ASTERISK | FORWARD_SLASH | PERCENT ) logicalNot )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_logicalNot_in_multiplication3176);
            logicalNot251=logicalNot();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalNot251.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:380:18: ( ( ASTERISK | FORWARD_SLASH | PERCENT ) logicalNot )*
            loop62:
            do {
                int alt62=2;
                alt62 = dfa62.predict(input);
                switch (alt62) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:380:19: ( ASTERISK | FORWARD_SLASH | PERCENT ) logicalNot
            	    {
            	    set252=(Token)input.LT(1);
            	    set252=(Token)input.LT(1);
            	    if ( (input.LA(1)>=ASTERISK && input.LA(1)<=FORWARD_SLASH) ) {
            	        input.consume();
            	        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set252), root_0);
            	        state.errorRecovery=false;state.failed=false;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return retval;}
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_logicalNot_in_multiplication3192);
            	    logicalNot253=logicalNot();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalNot253.getTree());

            	    }
            	    break;

            	default :
            	    break loop62;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 46, multiplication_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "multiplication"

    public static class logicalNot_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logicalNot"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:383:1: logicalNot : ( BANG logicalNot | instanceOf );
    public final PhpParser.logicalNot_return logicalNot() throws RecognitionException {
        PhpParser.logicalNot_return retval = new PhpParser.logicalNot_return();
        retval.start = input.LT(1);
        int logicalNot_StartIndex = input.index();
        CommonTree root_0 = null;

        Token BANG254=null;
        PhpParser.logicalNot_return logicalNot255 = null;

        PhpParser.instanceOf_return instanceOf256 = null;


        CommonTree BANG254_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 47) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:384:5: ( BANG logicalNot | instanceOf )
            int alt63=2;
            alt63 = dfa63.predict(input);
            switch (alt63) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:384:7: BANG logicalNot
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    BANG254=(Token)match(input,BANG,FOLLOW_BANG_in_logicalNot3211); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BANG254_tree = (CommonTree)adaptor.create(BANG254);
                    root_0 = (CommonTree)adaptor.becomeRoot(BANG254_tree, root_0);
                    }
                    pushFollow(FOLLOW_logicalNot_in_logicalNot3214);
                    logicalNot255=logicalNot();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalNot255.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:385:7: instanceOf
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_instanceOf_in_logicalNot3222);
                    instanceOf256=instanceOf();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, instanceOf256.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 47, logicalNot_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "logicalNot"

    public static class instanceOf_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "instanceOf"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:388:1: instanceOf : negateOrCast ( INSTANCE_OF negateOrCast )? ;
    public final PhpParser.instanceOf_return instanceOf() throws RecognitionException {
        PhpParser.instanceOf_return retval = new PhpParser.instanceOf_return();
        retval.start = input.LT(1);
        int instanceOf_StartIndex = input.index();
        CommonTree root_0 = null;

        Token INSTANCE_OF258=null;
        PhpParser.negateOrCast_return negateOrCast257 = null;

        PhpParser.negateOrCast_return negateOrCast259 = null;


        CommonTree INSTANCE_OF258_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 48) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:389:5: ( negateOrCast ( INSTANCE_OF negateOrCast )? )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:389:7: negateOrCast ( INSTANCE_OF negateOrCast )?
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_negateOrCast_in_instanceOf3239);
            negateOrCast257=negateOrCast();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, negateOrCast257.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:389:20: ( INSTANCE_OF negateOrCast )?
            int alt64=2;
            alt64 = dfa64.predict(input);
            switch (alt64) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:389:21: INSTANCE_OF negateOrCast
                    {
                    INSTANCE_OF258=(Token)match(input,INSTANCE_OF,FOLLOW_INSTANCE_OF_in_instanceOf3242); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INSTANCE_OF258_tree = (CommonTree)adaptor.create(INSTANCE_OF258);
                    root_0 = (CommonTree)adaptor.becomeRoot(INSTANCE_OF258_tree, root_0);
                    }
                    pushFollow(FOLLOW_negateOrCast_in_instanceOf3245);
                    negateOrCast259=negateOrCast();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, negateOrCast259.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 48, instanceOf_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "instanceOf"

    public static class negateOrCast_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "negateOrCast"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:392:1: negateOrCast : ( ( TILDE | MINUS | SUPPRESS_WARNINGS ) increment | OPEN_BRACE PrimitiveType CLOSE_BRACE increment -> ^( Cast PrimitiveType increment ) | OPEN_BRACE weakLogicalAnd CLOSE_BRACE | increment );
    public final PhpParser.negateOrCast_return negateOrCast() throws RecognitionException {
        PhpParser.negateOrCast_return retval = new PhpParser.negateOrCast_return();
        retval.start = input.LT(1);
        int negateOrCast_StartIndex = input.index();
        CommonTree root_0 = null;

        Token set260=null;
        Token OPEN_BRACE262=null;
        Token PrimitiveType263=null;
        Token CLOSE_BRACE264=null;
        Token OPEN_BRACE266=null;
        Token CLOSE_BRACE268=null;
        PhpParser.increment_return increment261 = null;

        PhpParser.increment_return increment265 = null;

        PhpParser.weakLogicalAnd_return weakLogicalAnd267 = null;

        PhpParser.increment_return increment269 = null;


        CommonTree set260_tree=null;
        CommonTree OPEN_BRACE262_tree=null;
        CommonTree PrimitiveType263_tree=null;
        CommonTree CLOSE_BRACE264_tree=null;
        CommonTree OPEN_BRACE266_tree=null;
        CommonTree CLOSE_BRACE268_tree=null;
        RewriteRuleTokenStream stream_PrimitiveType=new RewriteRuleTokenStream(adaptor,"token PrimitiveType");
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleSubtreeStream stream_increment=new RewriteRuleSubtreeStream(adaptor,"rule increment");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 49) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:393:5: ( ( TILDE | MINUS | SUPPRESS_WARNINGS ) increment | OPEN_BRACE PrimitiveType CLOSE_BRACE increment -> ^( Cast PrimitiveType increment ) | OPEN_BRACE weakLogicalAnd CLOSE_BRACE | increment )
            int alt65=4;
            alt65 = dfa65.predict(input);
            switch (alt65) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:393:7: ( TILDE | MINUS | SUPPRESS_WARNINGS ) increment
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    set260=(Token)input.LT(1);
                    set260=(Token)input.LT(1);
                    if ( input.LA(1)==SUPPRESS_WARNINGS||input.LA(1)==MINUS||input.LA(1)==TILDE ) {
                        input.consume();
                        if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set260), root_0);
                        state.errorRecovery=false;state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }

                    pushFollow(FOLLOW_increment_in_negateOrCast3277);
                    increment261=increment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, increment261.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:394:7: OPEN_BRACE PrimitiveType CLOSE_BRACE increment
                    {
                    OPEN_BRACE262=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_negateOrCast3285); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(OPEN_BRACE262);

                    PrimitiveType263=(Token)match(input,PrimitiveType,FOLLOW_PrimitiveType_in_negateOrCast3287); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_PrimitiveType.add(PrimitiveType263);

                    CLOSE_BRACE264=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_negateOrCast3289); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(CLOSE_BRACE264);

                    pushFollow(FOLLOW_increment_in_negateOrCast3291);
                    increment265=increment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_increment.add(increment265.getTree());


                    // AST REWRITE
                    // elements: PrimitiveType, increment
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 394:54: -> ^( Cast PrimitiveType increment )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:394:57: ^( Cast PrimitiveType increment )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Cast, "Cast"), root_1);

                        adaptor.addChild(root_1, stream_PrimitiveType.nextNode());
                        adaptor.addChild(root_1, stream_increment.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:395:7: OPEN_BRACE weakLogicalAnd CLOSE_BRACE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    OPEN_BRACE266=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_negateOrCast3309); if (state.failed) return retval;
                    pushFollow(FOLLOW_weakLogicalAnd_in_negateOrCast3312);
                    weakLogicalAnd267=weakLogicalAnd();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, weakLogicalAnd267.getTree());
                    CLOSE_BRACE268=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_negateOrCast3314); if (state.failed) return retval;

                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:396:7: increment
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_increment_in_negateOrCast3323);
                    increment269=increment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, increment269.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 49, negateOrCast_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "negateOrCast"

    public static class increment_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "increment"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:399:1: increment : ( IncrementOperator name -> ^( Prefix IncrementOperator name ) | name IncrementOperator -> ^( Postfix IncrementOperator name ) | newOrClone );
    public final PhpParser.increment_return increment() throws RecognitionException {
        PhpParser.increment_return retval = new PhpParser.increment_return();
        retval.start = input.LT(1);
        int increment_StartIndex = input.index();
        CommonTree root_0 = null;

        Token IncrementOperator270=null;
        Token IncrementOperator273=null;
        PhpParser.name_return name271 = null;

        PhpParser.name_return name272 = null;

        PhpParser.newOrClone_return newOrClone274 = null;


        CommonTree IncrementOperator270_tree=null;
        CommonTree IncrementOperator273_tree=null;
        RewriteRuleTokenStream stream_IncrementOperator=new RewriteRuleTokenStream(adaptor,"token IncrementOperator");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 50) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:400:5: ( IncrementOperator name -> ^( Prefix IncrementOperator name ) | name IncrementOperator -> ^( Postfix IncrementOperator name ) | newOrClone )
            int alt66=3;
            alt66 = dfa66.predict(input);
            switch (alt66) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:400:7: IncrementOperator name
                    {
                    IncrementOperator270=(Token)match(input,IncrementOperator,FOLLOW_IncrementOperator_in_increment3340); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IncrementOperator.add(IncrementOperator270);

                    pushFollow(FOLLOW_name_in_increment3342);
                    name271=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_name.add(name271.getTree());


                    // AST REWRITE
                    // elements: IncrementOperator, name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 400:30: -> ^( Prefix IncrementOperator name )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:400:33: ^( Prefix IncrementOperator name )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Prefix, "Prefix"), root_1);

                        adaptor.addChild(root_1, stream_IncrementOperator.nextNode());
                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:401:7: name IncrementOperator
                    {
                    pushFollow(FOLLOW_name_in_increment3360);
                    name272=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_name.add(name272.getTree());
                    IncrementOperator273=(Token)match(input,IncrementOperator,FOLLOW_IncrementOperator_in_increment3362); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_IncrementOperator.add(IncrementOperator273);



                    // AST REWRITE
                    // elements: name, IncrementOperator
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 401:30: -> ^( Postfix IncrementOperator name )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:401:33: ^( Postfix IncrementOperator name )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Postfix, "Postfix"), root_1);

                        adaptor.addChild(root_1, stream_IncrementOperator.nextNode());
                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:402:7: newOrClone
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_newOrClone_in_increment3380);
                    newOrClone274=newOrClone();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, newOrClone274.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 50, increment_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "increment"

    public static class newOrClone_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "newOrClone"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:405:1: newOrClone : ( NEW nameOrFunctionCall | CLONE name | atomOrReference );
    public final PhpParser.newOrClone_return newOrClone() throws RecognitionException {
        PhpParser.newOrClone_return retval = new PhpParser.newOrClone_return();
        retval.start = input.LT(1);
        int newOrClone_StartIndex = input.index();
        CommonTree root_0 = null;

        Token NEW275=null;
        Token CLONE277=null;
        PhpParser.nameOrFunctionCall_return nameOrFunctionCall276 = null;

        PhpParser.name_return name278 = null;

        PhpParser.atomOrReference_return atomOrReference279 = null;


        CommonTree NEW275_tree=null;
        CommonTree CLONE277_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 51) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:406:5: ( NEW nameOrFunctionCall | CLONE name | atomOrReference )
            int alt67=3;
            alt67 = dfa67.predict(input);
            switch (alt67) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:406:7: NEW nameOrFunctionCall
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    NEW275=(Token)match(input,NEW,FOLLOW_NEW_in_newOrClone3397); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    NEW275_tree = (CommonTree)adaptor.create(NEW275);
                    root_0 = (CommonTree)adaptor.becomeRoot(NEW275_tree, root_0);
                    }
                    pushFollow(FOLLOW_nameOrFunctionCall_in_newOrClone3400);
                    nameOrFunctionCall276=nameOrFunctionCall();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, nameOrFunctionCall276.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:407:7: CLONE name
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    CLONE277=(Token)match(input,CLONE,FOLLOW_CLONE_in_newOrClone3408); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CLONE277_tree = (CommonTree)adaptor.create(CLONE277);
                    root_0 = (CommonTree)adaptor.becomeRoot(CLONE277_tree, root_0);
                    }
                    pushFollow(FOLLOW_name_in_newOrClone3411);
                    name278=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, name278.getTree());

                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:408:7: atomOrReference
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_atomOrReference_in_newOrClone3419);
                    atomOrReference279=atomOrReference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, atomOrReference279.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 51, newOrClone_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "newOrClone"

    public static class atomOrReference_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atomOrReference"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:411:1: atomOrReference : ( atom | reference );
    public final PhpParser.atomOrReference_return atomOrReference() throws RecognitionException {
        PhpParser.atomOrReference_return retval = new PhpParser.atomOrReference_return();
        retval.start = input.LT(1);
        int atomOrReference_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.atom_return atom280 = null;

        PhpParser.reference_return reference281 = null;



        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 52) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:412:5: ( atom | reference )
            int alt68=2;
            alt68 = dfa68.predict(input);
            switch (alt68) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:412:7: atom
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_atom_in_atomOrReference3436);
                    atom280=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, atom280.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:413:7: reference
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_reference_in_atomOrReference3444);
                    reference281=reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, reference281.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 52, atomOrReference_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "atomOrReference"

    public static class arrayDeclaration_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arrayDeclaration"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:416:1: arrayDeclaration : Array OPEN_BRACE ( arrayEntry ( COMMA arrayEntry )* )? CLOSE_BRACE -> ^( Array ( arrayEntry )* ) ;
    public final PhpParser.arrayDeclaration_return arrayDeclaration() throws RecognitionException {
        PhpParser.arrayDeclaration_return retval = new PhpParser.arrayDeclaration_return();
        retval.start = input.LT(1);
        int arrayDeclaration_StartIndex = input.index();
        CommonTree root_0 = null;

        Token Array282=null;
        Token OPEN_BRACE283=null;
        Token COMMA285=null;
        Token CLOSE_BRACE287=null;
        PhpParser.arrayEntry_return arrayEntry284 = null;

        PhpParser.arrayEntry_return arrayEntry286 = null;


        CommonTree Array282_tree=null;
        CommonTree OPEN_BRACE283_tree=null;
        CommonTree COMMA285_tree=null;
        CommonTree CLOSE_BRACE287_tree=null;
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_Array=new RewriteRuleTokenStream(adaptor,"token Array");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleSubtreeStream stream_arrayEntry=new RewriteRuleSubtreeStream(adaptor,"rule arrayEntry");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 53) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:417:5: ( Array OPEN_BRACE ( arrayEntry ( COMMA arrayEntry )* )? CLOSE_BRACE -> ^( Array ( arrayEntry )* ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:417:7: Array OPEN_BRACE ( arrayEntry ( COMMA arrayEntry )* )? CLOSE_BRACE
            {
            Array282=(Token)match(input,Array,FOLLOW_Array_in_arrayDeclaration3461); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_Array.add(Array282);

            OPEN_BRACE283=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_arrayDeclaration3463); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_OPEN_BRACE.add(OPEN_BRACE283);

            // /home/iberiam/phpparser-1.2/grammar/Php.g:417:24: ( arrayEntry ( COMMA arrayEntry )* )?
            int alt70=2;
            alt70 = dfa70.predict(input);
            switch (alt70) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:417:25: arrayEntry ( COMMA arrayEntry )*
                    {
                    pushFollow(FOLLOW_arrayEntry_in_arrayDeclaration3466);
                    arrayEntry284=arrayEntry();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_arrayEntry.add(arrayEntry284.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:417:36: ( COMMA arrayEntry )*
                    loop69:
                    do {
                        int alt69=2;
                        int LA69_0 = input.LA(1);

                        if ( (LA69_0==COMMA) ) {
                            alt69=1;
                        }


                        switch (alt69) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/Php.g:417:37: COMMA arrayEntry
                    	    {
                    	    COMMA285=(Token)match(input,COMMA,FOLLOW_COMMA_in_arrayDeclaration3469); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_COMMA.add(COMMA285);

                    	    pushFollow(FOLLOW_arrayEntry_in_arrayDeclaration3471);
                    	    arrayEntry286=arrayEntry();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_arrayEntry.add(arrayEntry286.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop69;
                        }
                    } while (true);


                    }
                    break;

            }

            CLOSE_BRACE287=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_arrayDeclaration3477); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(CLOSE_BRACE287);



            // AST REWRITE
            // elements: Array, arrayEntry
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 417:70: -> ^( Array ( arrayEntry )* )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:417:73: ^( Array ( arrayEntry )* )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(stream_Array.nextNode(), root_1);

                // /home/iberiam/phpparser-1.2/grammar/Php.g:417:81: ( arrayEntry )*
                while ( stream_arrayEntry.hasNext() ) {
                    adaptor.addChild(root_1, stream_arrayEntry.nextTree());

                }
                stream_arrayEntry.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 53, arrayDeclaration_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "arrayDeclaration"

    public static class arrayEntry_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arrayEntry"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:420:1: arrayEntry : ( keyValuePair | expression ) ;
    public final PhpParser.arrayEntry_return arrayEntry() throws RecognitionException {
        PhpParser.arrayEntry_return retval = new PhpParser.arrayEntry_return();
        retval.start = input.LT(1);
        int arrayEntry_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.keyValuePair_return keyValuePair288 = null;

        PhpParser.expression_return expression289 = null;



        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 54) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:421:5: ( ( keyValuePair | expression ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:421:7: ( keyValuePair | expression )
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/Php.g:421:7: ( keyValuePair | expression )
            int alt71=2;
            alt71 = dfa71.predict(input);
            switch (alt71) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:421:8: keyValuePair
                    {
                    pushFollow(FOLLOW_keyValuePair_in_arrayEntry3504);
                    keyValuePair288=keyValuePair();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, keyValuePair288.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:421:23: expression
                    {
                    pushFollow(FOLLOW_expression_in_arrayEntry3508);
                    expression289=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression289.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 54, arrayEntry_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "arrayEntry"

    public static class keyValuePair_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "keyValuePair"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:424:1: keyValuePair : ( expression ARRAY_ASSIGN expression ) -> ^( ARRAY_ASSIGN ( expression )+ ) ;
    public final PhpParser.keyValuePair_return keyValuePair() throws RecognitionException {
        PhpParser.keyValuePair_return retval = new PhpParser.keyValuePair_return();
        retval.start = input.LT(1);
        int keyValuePair_StartIndex = input.index();
        CommonTree root_0 = null;

        Token ARRAY_ASSIGN291=null;
        PhpParser.expression_return expression290 = null;

        PhpParser.expression_return expression292 = null;


        CommonTree ARRAY_ASSIGN291_tree=null;
        RewriteRuleTokenStream stream_ARRAY_ASSIGN=new RewriteRuleTokenStream(adaptor,"token ARRAY_ASSIGN");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 55) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:425:5: ( ( expression ARRAY_ASSIGN expression ) -> ^( ARRAY_ASSIGN ( expression )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:425:7: ( expression ARRAY_ASSIGN expression )
            {
            // /home/iberiam/phpparser-1.2/grammar/Php.g:425:7: ( expression ARRAY_ASSIGN expression )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:425:8: expression ARRAY_ASSIGN expression
            {
            pushFollow(FOLLOW_expression_in_keyValuePair3527);
            expression290=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression290.getTree());
            ARRAY_ASSIGN291=(Token)match(input,ARRAY_ASSIGN,FOLLOW_ARRAY_ASSIGN_in_keyValuePair3529); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ARRAY_ASSIGN.add(ARRAY_ASSIGN291);

            pushFollow(FOLLOW_expression_in_keyValuePair3531);
            expression292=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression292.getTree());

            }



            // AST REWRITE
            // elements: ARRAY_ASSIGN, expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 425:44: -> ^( ARRAY_ASSIGN ( expression )+ )
            {
                // /home/iberiam/phpparser-1.2/grammar/Php.g:425:47: ^( ARRAY_ASSIGN ( expression )+ )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(stream_ARRAY_ASSIGN.nextNode(), root_1);

                if ( !(stream_expression.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_expression.hasNext() ) {
                    adaptor.addChild(root_1, stream_expression.nextTree());

                }
                stream_expression.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 55, keyValuePair_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "keyValuePair"

    public static class atom_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:1: atom : ( SingleQuotedString | DoubleQuotedString | HereDoc | Integer | Real | Boolean | arrayDeclaration );
    public final PhpParser.atom_return atom() throws RecognitionException {
        PhpParser.atom_return retval = new PhpParser.atom_return();
        retval.start = input.LT(1);
        int atom_StartIndex = input.index();
        CommonTree root_0 = null;

        Token SingleQuotedString293=null;
        Token DoubleQuotedString294=null;
        Token HereDoc295=null;
        Token Integer296=null;
        Token Real297=null;
        Token Boolean298=null;
        PhpParser.arrayDeclaration_return arrayDeclaration299 = null;


        CommonTree SingleQuotedString293_tree=null;
        CommonTree DoubleQuotedString294_tree=null;
        CommonTree HereDoc295_tree=null;
        CommonTree Integer296_tree=null;
        CommonTree Real297_tree=null;
        CommonTree Boolean298_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 56) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:428:5: ( SingleQuotedString | DoubleQuotedString | HereDoc | Integer | Real | Boolean | arrayDeclaration )
            int alt72=7;
            switch ( input.LA(1) ) {
            case SingleQuotedString:
                {
                alt72=1;
                }
                break;
            case DoubleQuotedString:
                {
                alt72=2;
                }
                break;
            case HereDoc:
                {
                alt72=3;
                }
                break;
            case Integer:
                {
                alt72=4;
                }
                break;
            case Real:
                {
                alt72=5;
                }
                break;
            case Boolean:
                {
                alt72=6;
                }
                break;
            case Array:
                {
                alt72=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }

            switch (alt72) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:7: SingleQuotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    SingleQuotedString293=(Token)match(input,SingleQuotedString,FOLLOW_SingleQuotedString_in_atom3553); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    SingleQuotedString293_tree = (CommonTree)adaptor.create(SingleQuotedString293);
                    adaptor.addChild(root_0, SingleQuotedString293_tree);
                    }

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:28: DoubleQuotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    DoubleQuotedString294=(Token)match(input,DoubleQuotedString,FOLLOW_DoubleQuotedString_in_atom3557); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DoubleQuotedString294_tree = (CommonTree)adaptor.create(DoubleQuotedString294);
                    adaptor.addChild(root_0, DoubleQuotedString294_tree);
                    }

                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:49: HereDoc
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    HereDoc295=(Token)match(input,HereDoc,FOLLOW_HereDoc_in_atom3561); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    HereDoc295_tree = (CommonTree)adaptor.create(HereDoc295);
                    adaptor.addChild(root_0, HereDoc295_tree);
                    }

                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:59: Integer
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    Integer296=(Token)match(input,Integer,FOLLOW_Integer_in_atom3565); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Integer296_tree = (CommonTree)adaptor.create(Integer296);
                    adaptor.addChild(root_0, Integer296_tree);
                    }

                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:69: Real
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    Real297=(Token)match(input,Real,FOLLOW_Real_in_atom3569); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Real297_tree = (CommonTree)adaptor.create(Real297);
                    adaptor.addChild(root_0, Real297_tree);
                    }

                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:76: Boolean
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    Boolean298=(Token)match(input,Boolean,FOLLOW_Boolean_in_atom3573); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Boolean298_tree = (CommonTree)adaptor.create(Boolean298);
                    adaptor.addChild(root_0, Boolean298_tree);
                    }

                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:428:86: arrayDeclaration
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_arrayDeclaration_in_atom3577);
                    arrayDeclaration299=arrayDeclaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, arrayDeclaration299.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 56, atom_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "atom"

    public static class reference_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:432:1: reference : ( AMPERSAND nameOrFunctionCall | nameOrFunctionCall );
    public final PhpParser.reference_return reference() throws RecognitionException {
        PhpParser.reference_return retval = new PhpParser.reference_return();
        retval.start = input.LT(1);
        int reference_StartIndex = input.index();
        CommonTree root_0 = null;

        Token AMPERSAND300=null;
        PhpParser.nameOrFunctionCall_return nameOrFunctionCall301 = null;

        PhpParser.nameOrFunctionCall_return nameOrFunctionCall302 = null;


        CommonTree AMPERSAND300_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 57) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:433:5: ( AMPERSAND nameOrFunctionCall | nameOrFunctionCall )
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==AMPERSAND) ) {
                alt73=1;
            }
            else if ( (LA73_0==DOLLAR||LA73_0==UnquotedString) ) {
                alt73=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 73, 0, input);

                throw nvae;
            }
            switch (alt73) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:433:7: AMPERSAND nameOrFunctionCall
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    AMPERSAND300=(Token)match(input,AMPERSAND,FOLLOW_AMPERSAND_in_reference3595); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    AMPERSAND300_tree = (CommonTree)adaptor.create(AMPERSAND300);
                    root_0 = (CommonTree)adaptor.becomeRoot(AMPERSAND300_tree, root_0);
                    }
                    pushFollow(FOLLOW_nameOrFunctionCall_in_reference3598);
                    nameOrFunctionCall301=nameOrFunctionCall();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, nameOrFunctionCall301.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:434:7: nameOrFunctionCall
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_nameOrFunctionCall_in_reference3606);
                    nameOrFunctionCall302=nameOrFunctionCall();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, nameOrFunctionCall302.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 57, reference_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "reference"

    public static class nameOrFunctionCall_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nameOrFunctionCall"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:437:1: nameOrFunctionCall : ( name OPEN_BRACE ( expression ( COMMA expression )* )? CLOSE_BRACE -> ^( Apply name ( expression )* ) | name );
    public final PhpParser.nameOrFunctionCall_return nameOrFunctionCall() throws RecognitionException {
        PhpParser.nameOrFunctionCall_return retval = new PhpParser.nameOrFunctionCall_return();
        retval.start = input.LT(1);
        int nameOrFunctionCall_StartIndex = input.index();
        CommonTree root_0 = null;

        Token OPEN_BRACE304=null;
        Token COMMA306=null;
        Token CLOSE_BRACE308=null;
        PhpParser.name_return name303 = null;

        PhpParser.expression_return expression305 = null;

        PhpParser.expression_return expression307 = null;

        PhpParser.name_return name309 = null;


        CommonTree OPEN_BRACE304_tree=null;
        CommonTree COMMA306_tree=null;
        CommonTree CLOSE_BRACE308_tree=null;
        RewriteRuleTokenStream stream_CLOSE_BRACE=new RewriteRuleTokenStream(adaptor,"token CLOSE_BRACE");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_OPEN_BRACE=new RewriteRuleTokenStream(adaptor,"token OPEN_BRACE");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 58) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:438:5: ( name OPEN_BRACE ( expression ( COMMA expression )* )? CLOSE_BRACE -> ^( Apply name ( expression )* ) | name )
            int alt76=2;
            alt76 = dfa76.predict(input);
            switch (alt76) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:438:7: name OPEN_BRACE ( expression ( COMMA expression )* )? CLOSE_BRACE
                    {
                    pushFollow(FOLLOW_name_in_nameOrFunctionCall3623);
                    name303=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_name.add(name303.getTree());
                    OPEN_BRACE304=(Token)match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_nameOrFunctionCall3625); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_OPEN_BRACE.add(OPEN_BRACE304);

                    // /home/iberiam/phpparser-1.2/grammar/Php.g:438:23: ( expression ( COMMA expression )* )?
                    int alt75=2;
                    alt75 = dfa75.predict(input);
                    switch (alt75) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:438:24: expression ( COMMA expression )*
                            {
                            pushFollow(FOLLOW_expression_in_nameOrFunctionCall3628);
                            expression305=expression();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expression.add(expression305.getTree());
                            // /home/iberiam/phpparser-1.2/grammar/Php.g:438:35: ( COMMA expression )*
                            loop74:
                            do {
                                int alt74=2;
                                int LA74_0 = input.LA(1);

                                if ( (LA74_0==COMMA) ) {
                                    alt74=1;
                                }


                                switch (alt74) {
                            	case 1 :
                            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:438:36: COMMA expression
                            	    {
                            	    COMMA306=(Token)match(input,COMMA,FOLLOW_COMMA_in_nameOrFunctionCall3631); if (state.failed) return retval; 
                            	    if ( state.backtracking==0 ) stream_COMMA.add(COMMA306);

                            	    pushFollow(FOLLOW_expression_in_nameOrFunctionCall3633);
                            	    expression307=expression();

                            	    state._fsp--;
                            	    if (state.failed) return retval;
                            	    if ( state.backtracking==0 ) stream_expression.add(expression307.getTree());

                            	    }
                            	    break;

                            	default :
                            	    break loop74;
                                }
                            } while (true);


                            }
                            break;

                    }

                    CLOSE_BRACE308=(Token)match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_nameOrFunctionCall3639); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_CLOSE_BRACE.add(CLOSE_BRACE308);



                    // AST REWRITE
                    // elements: name, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 438:69: -> ^( Apply name ( expression )* )
                    {
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:438:72: ^( Apply name ( expression )* )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(Apply, "Apply"), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());
                        // /home/iberiam/phpparser-1.2/grammar/Php.g:438:85: ( expression )*
                        while ( stream_expression.hasNext() ) {
                            adaptor.addChild(root_1, stream_expression.nextTree());

                        }
                        stream_expression.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:439:7: name
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_name_in_nameOrFunctionCall3658);
                    name309=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, name309.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 58, nameOrFunctionCall_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "nameOrFunctionCall"

    public static class name_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "name"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:442:1: name : ( staticMemberAccess | memberAccess | variable );
    public final PhpParser.name_return name() throws RecognitionException {
        PhpParser.name_return retval = new PhpParser.name_return();
        retval.start = input.LT(1);
        int name_StartIndex = input.index();
        CommonTree root_0 = null;

        PhpParser.staticMemberAccess_return staticMemberAccess310 = null;

        PhpParser.memberAccess_return memberAccess311 = null;

        PhpParser.variable_return variable312 = null;



        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 59) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:442:5: ( staticMemberAccess | memberAccess | variable )
            int alt77=3;
            alt77 = dfa77.predict(input);
            switch (alt77) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:442:7: staticMemberAccess
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_staticMemberAccess_in_name3670);
                    staticMemberAccess310=staticMemberAccess();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, staticMemberAccess310.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:443:7: memberAccess
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_memberAccess_in_name3678);
                    memberAccess311=memberAccess();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, memberAccess311.getTree());

                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:444:7: variable
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_name3686);
                    variable312=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable312.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 59, name_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "name"

    public static class staticMemberAccess_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "staticMemberAccess"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:447:1: staticMemberAccess : UnquotedString '::' variable ;
    public final PhpParser.staticMemberAccess_return staticMemberAccess() throws RecognitionException {
        PhpParser.staticMemberAccess_return retval = new PhpParser.staticMemberAccess_return();
        retval.start = input.LT(1);
        int staticMemberAccess_StartIndex = input.index();
        CommonTree root_0 = null;

        Token UnquotedString313=null;
        Token string_literal314=null;
        PhpParser.variable_return variable315 = null;


        CommonTree UnquotedString313_tree=null;
        CommonTree string_literal314_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 60) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:448:5: ( UnquotedString '::' variable )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:448:7: UnquotedString '::' variable
            {
            root_0 = (CommonTree)adaptor.nil();

            UnquotedString313=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_staticMemberAccess3707); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString313_tree = (CommonTree)adaptor.create(UnquotedString313);
            adaptor.addChild(root_0, UnquotedString313_tree);
            }
            string_literal314=(Token)match(input,CLASS_MEMBER,FOLLOW_CLASS_MEMBER_in_staticMemberAccess3709); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            string_literal314_tree = (CommonTree)adaptor.create(string_literal314);
            root_0 = (CommonTree)adaptor.becomeRoot(string_literal314_tree, root_0);
            }
            pushFollow(FOLLOW_variable_in_staticMemberAccess3712);
            variable315=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, variable315.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 60, staticMemberAccess_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "staticMemberAccess"

    public static class memberAccess_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "memberAccess"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:451:1: memberAccess : variable ( OPEN_SQUARE_BRACE expression CLOSE_SQUARE_BRACE | '->' UnquotedString )* ;
    public final PhpParser.memberAccess_return memberAccess() throws RecognitionException {
        PhpParser.memberAccess_return retval = new PhpParser.memberAccess_return();
        retval.start = input.LT(1);
        int memberAccess_StartIndex = input.index();
        CommonTree root_0 = null;

        Token OPEN_SQUARE_BRACE317=null;
        Token CLOSE_SQUARE_BRACE319=null;
        Token string_literal320=null;
        Token UnquotedString321=null;
        PhpParser.variable_return variable316 = null;

        PhpParser.expression_return expression318 = null;


        CommonTree OPEN_SQUARE_BRACE317_tree=null;
        CommonTree CLOSE_SQUARE_BRACE319_tree=null;
        CommonTree string_literal320_tree=null;
        CommonTree UnquotedString321_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 61) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:452:5: ( variable ( OPEN_SQUARE_BRACE expression CLOSE_SQUARE_BRACE | '->' UnquotedString )* )
            // /home/iberiam/phpparser-1.2/grammar/Php.g:452:7: variable ( OPEN_SQUARE_BRACE expression CLOSE_SQUARE_BRACE | '->' UnquotedString )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_variable_in_memberAccess3729);
            variable316=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, variable316.getTree());
            // /home/iberiam/phpparser-1.2/grammar/Php.g:453:9: ( OPEN_SQUARE_BRACE expression CLOSE_SQUARE_BRACE | '->' UnquotedString )*
            loop78:
            do {
                int alt78=3;
                alt78 = dfa78.predict(input);
                switch (alt78) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:453:11: OPEN_SQUARE_BRACE expression CLOSE_SQUARE_BRACE
            	    {
            	    OPEN_SQUARE_BRACE317=(Token)match(input,OPEN_SQUARE_BRACE,FOLLOW_OPEN_SQUARE_BRACE_in_memberAccess3742); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    OPEN_SQUARE_BRACE317_tree = (CommonTree)adaptor.create(OPEN_SQUARE_BRACE317);
            	    root_0 = (CommonTree)adaptor.becomeRoot(OPEN_SQUARE_BRACE317_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_expression_in_memberAccess3745);
            	    expression318=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, expression318.getTree());
            	    CLOSE_SQUARE_BRACE319=(Token)match(input,CLOSE_SQUARE_BRACE,FOLLOW_CLOSE_SQUARE_BRACE_in_memberAccess3747); if (state.failed) return retval;

            	    }
            	    break;
            	case 2 :
            	    // /home/iberiam/phpparser-1.2/grammar/Php.g:454:11: '->' UnquotedString
            	    {
            	    string_literal320=(Token)match(input,INSTANCE_MEMBER,FOLLOW_INSTANCE_MEMBER_in_memberAccess3760); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal320_tree = (CommonTree)adaptor.create(string_literal320);
            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal320_tree, root_0);
            	    }
            	    UnquotedString321=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_memberAccess3763); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    UnquotedString321_tree = (CommonTree)adaptor.create(UnquotedString321);
            	    adaptor.addChild(root_0, UnquotedString321_tree);
            	    }

            	    }
            	    break;

            	default :
            	    break loop78;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 61, memberAccess_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "memberAccess"

    public static class variable_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/iberiam/phpparser-1.2/grammar/Php.g:457:1: variable : ( DOLLAR variable | UnquotedString );
    public final PhpParser.variable_return variable() throws RecognitionException {
        PhpParser.variable_return retval = new PhpParser.variable_return();
        retval.start = input.LT(1);
        int variable_StartIndex = input.index();
        CommonTree root_0 = null;

        Token DOLLAR322=null;
        Token UnquotedString324=null;
        PhpParser.variable_return variable323 = null;


        CommonTree DOLLAR322_tree=null;
        CommonTree UnquotedString324_tree=null;

        try {
            if ( state.backtracking>0 && alreadyParsedRule(input, 62) ) { return retval; }
            // /home/iberiam/phpparser-1.2/grammar/Php.g:458:5: ( DOLLAR variable | UnquotedString )
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==DOLLAR) ) {
                alt79=1;
            }
            else if ( (LA79_0==UnquotedString) ) {
                alt79=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 79, 0, input);

                throw nvae;
            }
            switch (alt79) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:458:7: DOLLAR variable
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    DOLLAR322=(Token)match(input,DOLLAR,FOLLOW_DOLLAR_in_variable3786); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR322_tree = (CommonTree)adaptor.create(DOLLAR322);
                    root_0 = (CommonTree)adaptor.becomeRoot(DOLLAR322_tree, root_0);
                    }
                    pushFollow(FOLLOW_variable_in_variable3789);
                    variable323=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, variable323.getTree());

                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/Php.g:459:7: UnquotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    UnquotedString324=(Token)match(input,UnquotedString,FOLLOW_UnquotedString_in_variable3797); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString324_tree = (CommonTree)adaptor.create(UnquotedString324);
                    adaptor.addChild(root_0, UnquotedString324_tree);
                    }

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
            if ( state.backtracking>0 ) { memoize(input, 62, variable_StartIndex); }
        }
        return retval;
    }
    // $ANTLR end "variable"

    // $ANTLR start synpred3_Php
    public final void synpred3_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:142:7: ( ( simpleStatement )? BodyString )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:142:7: ( simpleStatement )? BodyString
        {
        // /home/iberiam/phpparser-1.2/grammar/Php.g:142:7: ( simpleStatement )?
        int alt80=2;
        alt80 = dfa80.predict(input);
        switch (alt80) {
            case 1 :
                // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: simpleStatement
                {
                pushFollow(FOLLOW_simpleStatement_in_synpred3_Php958);
                simpleStatement();

                state._fsp--;
                if (state.failed) return ;

                }
                break;

        }

        match(input,BodyString,FOLLOW_BodyString_in_synpred3_Php961); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred3_Php

    // $ANTLR start synpred4_Php
    public final void synpred4_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:143:7: ( '{' statement '}' )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:143:7: '{' statement '}'
        {
        match(input,OPEN_CURLY_BRACE,FOLLOW_OPEN_CURLY_BRACE_in_synpred4_Php969); if (state.failed) return ;
        pushFollow(FOLLOW_statement_in_synpred4_Php971);
        statement();

        state._fsp--;
        if (state.failed) return ;
        match(input,CLOSE_CURLY_BRACE,FOLLOW_CLOSE_CURLY_BRACE_in_synpred4_Php973); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred4_Php

    // $ANTLR start synpred5_Php
    public final void synpred5_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:144:7: ( bracketedBlock )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:144:7: bracketedBlock
        {
        pushFollow(FOLLOW_bracketedBlock_in_synpred5_Php985);
        bracketedBlock();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred5_Php

    // $ANTLR start synpred23_Php
    public final void synpred23_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:196:7: ( ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ( bracketedBlock | ';' ) )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:196:7: ( fieldModifier )* FUNCTION UnquotedString parametersDefinition ( bracketedBlock | ';' )
        {
        // /home/iberiam/phpparser-1.2/grammar/Php.g:196:7: ( fieldModifier )*
        loop82:
        do {
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==STATIC||LA82_0==ABSTRACT||LA82_0==AccessModifier||LA82_0==117) ) {
                alt82=1;
            }


            switch (alt82) {
        	case 1 :
        	    // /home/iberiam/phpparser-1.2/grammar/Php.g:0:0: fieldModifier
        	    {
        	    pushFollow(FOLLOW_fieldModifier_in_synpred23_Php1467);
        	    fieldModifier();

        	    state._fsp--;
        	    if (state.failed) return ;

        	    }
        	    break;

        	default :
        	    break loop82;
            }
        } while (true);

        match(input,FUNCTION,FOLLOW_FUNCTION_in_synpred23_Php1470); if (state.failed) return ;
        match(input,UnquotedString,FOLLOW_UnquotedString_in_synpred23_Php1472); if (state.failed) return ;
        pushFollow(FOLLOW_parametersDefinition_in_synpred23_Php1474);
        parametersDefinition();

        state._fsp--;
        if (state.failed) return ;
        // /home/iberiam/phpparser-1.2/grammar/Php.g:197:9: ( bracketedBlock | ';' )
        int alt83=2;
        int LA83_0 = input.LA(1);

        if ( (LA83_0==OPEN_CURLY_BRACE) ) {
            alt83=1;
        }
        else if ( (LA83_0==SEMICOLON) ) {
            alt83=2;
        }
        else {
            if (state.backtracking>0) {state.failed=true; return ;}
            NoViableAltException nvae =
                new NoViableAltException("", 83, 0, input);

            throw nvae;
        }
        switch (alt83) {
            case 1 :
                // /home/iberiam/phpparser-1.2/grammar/Php.g:197:10: bracketedBlock
                {
                pushFollow(FOLLOW_bracketedBlock_in_synpred23_Php1486);
                bracketedBlock();

                state._fsp--;
                if (state.failed) return ;

                }
                break;
            case 2 :
                // /home/iberiam/phpparser-1.2/grammar/Php.g:197:27: ';'
                {
                match(input,SEMICOLON,FOLLOW_SEMICOLON_in_synpred23_Php1490); if (state.failed) return ;

                }
                break;

        }


        }
    }
    // $ANTLR end synpred23_Php

    // $ANTLR start synpred34_Php
    public final void synpred34_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:220:58: ( conditional )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:220:58: conditional
        {
        pushFollow(FOLLOW_conditional_in_synpred34_Php1782);
        conditional();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred34_Php

    // $ANTLR start synpred59_Php
    public final void synpred59_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:249:63: ( conditional )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:249:63: conditional
        {
        pushFollow(FOLLOW_conditional_in_synpred59_Php2220);
        conditional();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred59_Php

    // $ANTLR start synpred67_Php
    public final void synpred67_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:278:46: ( catchStatement )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:278:46: catchStatement
        {
        pushFollow(FOLLOW_catchStatement_in_synpred67_Php2441);
        catchStatement();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred67_Php

    // $ANTLR start synpred75_Php
    public final void synpred75_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:326:23: ( OR weakLogicalXor )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:326:23: OR weakLogicalXor
        {
        match(input,OR,FOLLOW_OR_in_synpred75_Php2792); if (state.failed) return ;
        pushFollow(FOLLOW_weakLogicalXor_in_synpred75_Php2795);
        weakLogicalXor();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred75_Php

    // $ANTLR start synpred76_Php
    public final void synpred76_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:330:23: ( XOR weakLogicalAnd )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:330:23: XOR weakLogicalAnd
        {
        match(input,XOR,FOLLOW_XOR_in_synpred76_Php2817); if (state.failed) return ;
        pushFollow(FOLLOW_weakLogicalAnd_in_synpred76_Php2820);
        weakLogicalAnd();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred76_Php

    // $ANTLR start synpred77_Php
    public final void synpred77_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:334:19: ( AND assignment )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:334:19: AND assignment
        {
        match(input,AND,FOLLOW_AND_in_synpred77_Php2846); if (state.failed) return ;
        pushFollow(FOLLOW_assignment_in_synpred77_Php2849);
        assignment();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred77_Php

    // $ANTLR start synpred79_Php
    public final void synpred79_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:338:7: ( name ( ( EQUALS | AsignmentOperator ) assignment ) )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:338:7: name ( ( EQUALS | AsignmentOperator ) assignment )
        {
        pushFollow(FOLLOW_name_in_synpred79_Php2868);
        name();

        state._fsp--;
        if (state.failed) return ;
        // /home/iberiam/phpparser-1.2/grammar/Php.g:338:12: ( ( EQUALS | AsignmentOperator ) assignment )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:338:13: ( EQUALS | AsignmentOperator ) assignment
        {
        if ( input.LA(1)==EQUALS||input.LA(1)==AsignmentOperator ) {
            input.consume();
            state.errorRecovery=false;state.failed=false;
        }
        else {
            if (state.backtracking>0) {state.failed=true; return ;}
            MismatchedSetException mse = new MismatchedSetException(null,input);
            throw mse;
        }

        pushFollow(FOLLOW_assignment_in_synpred79_Php2880);
        assignment();

        state._fsp--;
        if (state.failed) return ;

        }


        }
    }
    // $ANTLR end synpred79_Php

    // $ANTLR start synpred80_Php
    public final void synpred80_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:343:7: ( logicalOr QUESTION_MARK expression COLON expression )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:343:7: logicalOr QUESTION_MARK expression COLON expression
        {
        pushFollow(FOLLOW_logicalOr_in_synpred80_Php2906);
        logicalOr();

        state._fsp--;
        if (state.failed) return ;
        match(input,QUESTION_MARK,FOLLOW_QUESTION_MARK_in_synpred80_Php2908); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred80_Php2910);
        expression();

        state._fsp--;
        if (state.failed) return ;
        match(input,COLON,FOLLOW_COLON_in_synpred80_Php2912); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred80_Php2914);
        expression();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred80_Php

    // $ANTLR start synpred102_Php
    public final void synpred102_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:401:7: ( name IncrementOperator )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:401:7: name IncrementOperator
        {
        pushFollow(FOLLOW_name_in_synpred102_Php3360);
        name();

        state._fsp--;
        if (state.failed) return ;
        match(input,IncrementOperator,FOLLOW_IncrementOperator_in_synpred102_Php3362); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred102_Php

    // $ANTLR start synpred108_Php
    public final void synpred108_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:421:8: ( keyValuePair )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:421:8: keyValuePair
        {
        pushFollow(FOLLOW_keyValuePair_in_synpred108_Php3504);
        keyValuePair();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred108_Php

    // $ANTLR start synpred118_Php
    public final void synpred118_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:438:7: ( name OPEN_BRACE ( expression ( COMMA expression )* )? CLOSE_BRACE )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:438:7: name OPEN_BRACE ( expression ( COMMA expression )* )? CLOSE_BRACE
        {
        pushFollow(FOLLOW_name_in_synpred118_Php3623);
        name();

        state._fsp--;
        if (state.failed) return ;
        match(input,OPEN_BRACE,FOLLOW_OPEN_BRACE_in_synpred118_Php3625); if (state.failed) return ;
        // /home/iberiam/phpparser-1.2/grammar/Php.g:438:23: ( expression ( COMMA expression )* )?
        int alt98=2;
        alt98 = dfa98.predict(input);
        switch (alt98) {
            case 1 :
                // /home/iberiam/phpparser-1.2/grammar/Php.g:438:24: expression ( COMMA expression )*
                {
                pushFollow(FOLLOW_expression_in_synpred118_Php3628);
                expression();

                state._fsp--;
                if (state.failed) return ;
                // /home/iberiam/phpparser-1.2/grammar/Php.g:438:35: ( COMMA expression )*
                loop97:
                do {
                    int alt97=2;
                    int LA97_0 = input.LA(1);

                    if ( (LA97_0==COMMA) ) {
                        alt97=1;
                    }


                    switch (alt97) {
                	case 1 :
                	    // /home/iberiam/phpparser-1.2/grammar/Php.g:438:36: COMMA expression
                	    {
                	    match(input,COMMA,FOLLOW_COMMA_in_synpred118_Php3631); if (state.failed) return ;
                	    pushFollow(FOLLOW_expression_in_synpred118_Php3633);
                	    expression();

                	    state._fsp--;
                	    if (state.failed) return ;

                	    }
                	    break;

                	default :
                	    break loop97;
                    }
                } while (true);


                }
                break;

        }

        match(input,CLOSE_BRACE,FOLLOW_CLOSE_BRACE_in_synpred118_Php3639); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred118_Php

    // $ANTLR start synpred120_Php
    public final void synpred120_Php_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/Php.g:443:7: ( memberAccess )
        // /home/iberiam/phpparser-1.2/grammar/Php.g:443:7: memberAccess
        {
        pushFollow(FOLLOW_memberAccess_in_synpred120_Php3678);
        memberAccess();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred120_Php

    // Delegated rules

    public final boolean synpred67_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred67_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred79_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred79_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred4_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred4_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred120_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred120_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred59_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred59_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred3_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred3_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred23_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred23_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred5_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred5_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred75_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred75_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred76_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred76_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred34_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred34_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred77_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred77_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred108_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred108_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred118_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred118_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred102_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred102_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred80_Php() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred80_Php_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA1 dfa1 = new DFA1(this);
    protected DFA3 dfa3 = new DFA3(this);
    protected DFA2 dfa2 = new DFA2(this);
    protected DFA4 dfa4 = new DFA4(this);
    protected DFA27 dfa27 = new DFA27(this);
    protected DFA24 dfa24 = new DFA24(this);
    protected DFA25 dfa25 = new DFA25(this);
    protected DFA26 dfa26 = new DFA26(this);
    protected DFA32 dfa32 = new DFA32(this);
    protected DFA31 dfa31 = new DFA31(this);
    protected DFA33 dfa33 = new DFA33(this);
    protected DFA35 dfa35 = new DFA35(this);
    protected DFA36 dfa36 = new DFA36(this);
    protected DFA37 dfa37 = new DFA37(this);
    protected DFA39 dfa39 = new DFA39(this);
    protected DFA40 dfa40 = new DFA40(this);
    protected DFA41 dfa41 = new DFA41(this);
    protected DFA49 dfa49 = new DFA49(this);
    protected DFA50 dfa50 = new DFA50(this);
    protected DFA51 dfa51 = new DFA51(this);
    protected DFA52 dfa52 = new DFA52(this);
    protected DFA53 dfa53 = new DFA53(this);
    protected DFA54 dfa54 = new DFA54(this);
    protected DFA55 dfa55 = new DFA55(this);
    protected DFA56 dfa56 = new DFA56(this);
    protected DFA57 dfa57 = new DFA57(this);
    protected DFA58 dfa58 = new DFA58(this);
    protected DFA59 dfa59 = new DFA59(this);
    protected DFA60 dfa60 = new DFA60(this);
    protected DFA61 dfa61 = new DFA61(this);
    protected DFA62 dfa62 = new DFA62(this);
    protected DFA63 dfa63 = new DFA63(this);
    protected DFA64 dfa64 = new DFA64(this);
    protected DFA65 dfa65 = new DFA65(this);
    protected DFA66 dfa66 = new DFA66(this);
    protected DFA67 dfa67 = new DFA67(this);
    protected DFA68 dfa68 = new DFA68(this);
    protected DFA70 dfa70 = new DFA70(this);
    protected DFA71 dfa71 = new DFA71(this);
    protected DFA76 dfa76 = new DFA76(this);
    protected DFA75 dfa75 = new DFA75(this);
    protected DFA77 dfa77 = new DFA77(this);
    protected DFA78 dfa78 = new DFA78(this);
    protected DFA80 dfa80 = new DFA80(this);
    protected DFA98 dfa98 = new DFA98(this);
    static final String DFA1_eotS =
        "\52\uffff";
    static final String DFA1_eofS =
        "\1\1\51\uffff";
    static final String DFA1_minS =
        "\1\6\51\uffff";
    static final String DFA1_maxS =
        "\1\146\51\uffff";
    static final String DFA1_acceptS =
        "\1\uffff\1\2\1\1\47\uffff";
    static final String DFA1_specialS =
        "\52\uffff}>";
    static final String[] DFA1_transitionS = {
            "\1\2\3\uffff\1\2\6\uffff\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff"+
            "\1\2\1\uffff\1\2\3\uffff\1\2\1\uffff\5\2\2\uffff\5\2\2\uffff"+
            "\6\2\4\uffff\2\2\2\uffff\1\2\2\uffff\1\2\1\uffff\3\2\22\uffff"+
            "\2\2\1\uffff\2\2\5\uffff\7\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA1_eot = DFA.unpackEncodedString(DFA1_eotS);
    static final short[] DFA1_eof = DFA.unpackEncodedString(DFA1_eofS);
    static final char[] DFA1_min = DFA.unpackEncodedStringToUnsignedChars(DFA1_minS);
    static final char[] DFA1_max = DFA.unpackEncodedStringToUnsignedChars(DFA1_maxS);
    static final short[] DFA1_accept = DFA.unpackEncodedString(DFA1_acceptS);
    static final short[] DFA1_special = DFA.unpackEncodedString(DFA1_specialS);
    static final short[][] DFA1_transition;

    static {
        int numStates = DFA1_transitionS.length;
        DFA1_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA1_transition[i] = DFA.unpackEncodedString(DFA1_transitionS[i]);
        }
    }

    class DFA1 extends DFA {

        public DFA1(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 1;
            this.eot = DFA1_eot;
            this.eof = DFA1_eof;
            this.min = DFA1_min;
            this.max = DFA1_max;
            this.accept = DFA1_accept;
            this.special = DFA1_special;
            this.transition = DFA1_transition;
        }
        public String getDescription() {
            return "()* loopback of 139:8: ( statement )*";
        }
    }
    static final String DFA3_eotS =
        "\u014e\uffff";
    static final String DFA3_eofS =
        "\u014e\uffff";
    static final String DFA3_minS =
        "\3\6\2\23\3\4\1\6\1\4\1\23\1\6\1\23\1\6\3\23\6\4\1\6\1\23\1\uffff"+
        "\1\6\16\uffff\45\0\2\uffff\1\0\2\uffff\20\0\2\uffff\44\0\2\uffff"+
        "\103\0\1\uffff\1\0\1\uffff\16\0\2\uffff\16\0\2\uffff\15\0\2\uffff"+
        "\17\0\2\uffff\16\0\2\uffff\53\0\2\uffff";
    static final String DFA3_maxS =
        "\3\146\2\127\2\131\2\146\1\140\1\127\3\146\3\127\6\136\1\6\1\127"+
        "\1\uffff\1\146\16\uffff\45\0\2\uffff\1\0\2\uffff\20\0\2\uffff\44"+
        "\0\2\uffff\103\0\1\uffff\1\0\1\uffff\16\0\2\uffff\16\0\2\uffff\15"+
        "\0\2\uffff\17\0\2\uffff\16\0\2\uffff\53\0\2\uffff";
    static final String DFA3_acceptS =
        "\31\uffff\1\1\1\uffff\1\4\1\uffff\1\5\1\6\60\uffff\1\7\u00fc\uffff"+
        "\1\3\1\2";
    static final String DFA3_specialS =
        "\51\uffff\1\0\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1"+
        "\14\1\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\27\1\30"+
        "\1\31\1\32\1\33\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43\1\44\2\uffff"+
        "\1\45\2\uffff\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56\1\57"+
        "\1\60\1\61\1\62\1\63\1\64\1\65\2\uffff\1\66\1\67\1\70\1\71\1\72"+
        "\1\73\1\74\1\75\1\76\1\77\1\100\1\101\1\102\1\103\1\104\1\105\1"+
        "\106\1\107\1\110\1\111\1\112\1\113\1\114\1\115\1\116\1\117\1\120"+
        "\1\121\1\122\1\123\1\124\1\125\1\126\1\127\1\130\1\131\2\uffff\1"+
        "\132\1\133\1\134\1\135\1\136\1\137\1\140\1\141\1\142\1\143\1\144"+
        "\1\145\1\146\1\147\1\150\1\151\1\152\1\153\1\154\1\155\1\156\1\157"+
        "\1\160\1\161\1\162\1\163\1\164\1\165\1\166\1\167\1\170\1\171\1\172"+
        "\1\173\1\174\1\175\1\176\1\177\1\u0080\1\u0081\1\u0082\1\u0083\1"+
        "\u0084\1\u0085\1\u0086\1\u0087\1\u0088\1\u0089\1\u008a\1\u008b\1"+
        "\u008c\1\u008d\1\u008e\1\u008f\1\u0090\1\u0091\1\u0092\1\u0093\1"+
        "\u0094\1\u0095\1\u0096\1\u0097\1\u0098\1\u0099\1\u009a\1\u009b\1"+
        "\u009c\1\uffff\1\u009d\1\uffff\1\u009e\1\u009f\1\u00a0\1\u00a1\1"+
        "\u00a2\1\u00a3\1\u00a4\1\u00a5\1\u00a6\1\u00a7\1\u00a8\1\u00a9\1"+
        "\u00aa\1\u00ab\2\uffff\1\u00ac\1\u00ad\1\u00ae\1\u00af\1\u00b0\1"+
        "\u00b1\1\u00b2\1\u00b3\1\u00b4\1\u00b5\1\u00b6\1\u00b7\1\u00b8\1"+
        "\u00b9\2\uffff\1\u00ba\1\u00bb\1\u00bc\1\u00bd\1\u00be\1\u00bf\1"+
        "\u00c0\1\u00c1\1\u00c2\1\u00c3\1\u00c4\1\u00c5\1\u00c6\2\uffff\1"+
        "\u00c7\1\u00c8\1\u00c9\1\u00ca\1\u00cb\1\u00cc\1\u00cd\1\u00ce\1"+
        "\u00cf\1\u00d0\1\u00d1\1\u00d2\1\u00d3\1\u00d4\1\u00d5\2\uffff\1"+
        "\u00d6\1\u00d7\1\u00d8\1\u00d9\1\u00da\1\u00db\1\u00dc\1\u00dd\1"+
        "\u00de\1\u00df\1\u00e0\1\u00e1\1\u00e2\1\u00e3\2\uffff\1\u00e4\1"+
        "\u00e5\1\u00e6\1\u00e7\1\u00e8\1\u00e9\1\u00ea\1\u00eb\1\u00ec\1"+
        "\u00ed\1\u00ee\1\u00ef\1\u00f0\1\u00f1\1\u00f2\1\u00f3\1\u00f4\1"+
        "\u00f5\1\u00f6\1\u00f7\1\u00f8\1\u00f9\1\u00fa\1\u00fb\1\u00fc\1"+
        "\u00fd\1\u00fe\1\u00ff\1\u0100\1\u0101\1\u0102\1\u0103\1\u0104\1"+
        "\u0105\1\u0106\1\u0107\1\u0108\1\u0109\1\u010a\1\u010b\1\u010c\1"+
        "\u010d\1\u010e\2\uffff}>";
    static final String[] DFA3_transitionS = {
            "\1\15\3\uffff\1\32\6\uffff\1\14\1\uffff\1\12\2\uffff\1\30\1"+
            "\uffff\1\13\1\uffff\1\14\3\uffff\1\14\1\uffff\1\17\1\20\1\1"+
            "\1\2\1\36\2\uffff\5\36\2\uffff\1\36\1\5\1\6\1\7\1\3\1\4\4\uffff"+
            "\1\33\1\35\2\uffff\1\33\2\uffff\1\36\1\uffff\3\36\22\uffff\1"+
            "\31\1\11\1\uffff\1\24\1\10\5\uffff\1\16\1\27\1\21\1\22\1\23"+
            "\1\25\1\26",
            "\1\55\12\uffff\1\54\1\uffff\1\52\2\uffff\1\70\1\uffff\1\53"+
            "\1\uffff\1\54\3\uffff\1\54\1\uffff\1\57\1\60\65\uffff\1\51\1"+
            "\uffff\1\64\6\uffff\1\56\1\67\1\61\1\62\1\63\1\65\1\66",
            "\1\75\12\uffff\1\74\1\uffff\1\72\2\uffff\1\110\1\uffff\1\73"+
            "\1\uffff\1\74\3\uffff\1\74\1\uffff\1\77\1\100\65\uffff\1\71"+
            "\1\uffff\1\104\6\uffff\1\76\1\107\1\101\1\102\1\103\1\105\1"+
            "\106",
            "\1\112\103\uffff\1\111",
            "\1\113\103\uffff\1\114",
            "\1\117\121\uffff\1\31\2\uffff\1\115",
            "\1\117\121\uffff\1\31\2\uffff\1\120",
            "\1\117\1\uffff\1\127\12\uffff\1\126\1\uffff\1\124\2\uffff\1"+
            "\142\1\uffff\1\125\1\uffff\1\126\3\uffff\1\126\1\uffff\1\131"+
            "\1\132\64\uffff\1\31\1\123\1\uffff\1\136\6\uffff\1\130\1\141"+
            "\1\133\1\134\1\135\1\137\1\140",
            "\1\151\12\uffff\1\150\1\uffff\1\146\2\uffff\1\164\1\uffff\1"+
            "\147\1\uffff\1\150\3\uffff\1\150\1\uffff\1\153\1\154\65\uffff"+
            "\1\145\1\uffff\1\160\6\uffff\1\152\1\163\1\155\1\156\1\157\1"+
            "\161\1\162",
            "\1\117\1\uffff\1\170\1\uffff\1\166\4\uffff\1\u0083\1\u0082"+
            "\1\165\1\167\1\uffff\1\u0084\2\uffff\1\174\1\u0080\1\u0081\1"+
            "\uffff\2\174\3\173\1\uffff\1\u0085\24\uffff\1\u0086\1\u0088"+
            "\1\u0087\1\172\36\uffff\1\31\4\uffff\1\u0085\1\177\1\176\1\175"+
            "\1\uffff\1\171",
            "\1\u008b\103\uffff\1\u008c",
            "\1\u008f\12\uffff\1\u008e\1\uffff\1\u0092\2\uffff\1\u009c\1"+
            "\uffff\1\u008d\1\uffff\1\u008e\3\uffff\1\u008e\1\uffff\1\u0093"+
            "\1\u0094\65\uffff\1\u0091\1\uffff\1\u0098\6\uffff\1\u0090\1"+
            "\u009b\1\u0095\1\u0096\1\u0097\1\u0099\1\u009a",
            "\1\u009f\2\uffff\1\u00a9\11\uffff\1\u00a0\1\u00a1\65\uffff"+
            "\1\u009e\1\uffff\1\u00a5\6\uffff\1\u009d\1\u00a8\1\u00a2\1\u00a3"+
            "\1\u00a4\1\u00a6\1\u00a7",
            "\1\u00af\12\uffff\1\u00ae\1\uffff\1\u00ac\2\uffff\1\u00ba\1"+
            "\uffff\1\u00ad\1\uffff\1\u00ae\3\uffff\1\u00ae\1\uffff\1\u00b1"+
            "\1\u00b2\65\uffff\1\u00ab\1\uffff\1\u00b6\5\uffff\1\u00aa\1"+
            "\u00b0\1\u00b9\1\u00b3\1\u00b4\1\u00b5\1\u00b7\1\u00b8",
            "\1\u00bc\103\uffff\1\u00bb",
            "\1\u00be\103\uffff\1\u00bd",
            "\1\u00c0\103\uffff\1\u00bf",
            "\1\117\10\uffff\1\u00ca\1\u00c9\3\uffff\1\u00cf\2\uffff\1\u00c3"+
            "\1\u00c7\1\u00c8\1\uffff\2\u00c3\3\u00c2\26\uffff\1\u00cb\1"+
            "\u00cd\1\u00cc\1\u00c1\36\uffff\1\31\5\uffff\1\u00c6\1\u00c5"+
            "\1\u00c4",
            "\1\117\10\uffff\1\u00da\1\u00d9\3\uffff\1\u00db\2\uffff\1\u00d3"+
            "\1\u00d7\1\u00d8\1\uffff\2\u00d3\3\u00d2\26\uffff\1\u00dc\1"+
            "\u00de\1\u00dd\1\u00d1\36\uffff\1\31\5\uffff\1\u00d6\1\u00d5"+
            "\1\u00d4",
            "\1\117\10\uffff\1\u00ea\1\u00e9\3\uffff\1\u00eb\2\uffff\1\u00e3"+
            "\1\u00e7\1\u00e8\1\uffff\2\u00e3\3\u00e2\26\uffff\1\u00ec\1"+
            "\u00ee\1\u00ed\1\u00e1\36\uffff\1\31\5\uffff\1\u00e6\1\u00e5"+
            "\1\u00e4",
            "\1\117\10\uffff\1\u00fa\1\u00f9\3\uffff\1\u0100\2\uffff\1\u00f3"+
            "\1\u00f7\1\u00f8\1\uffff\2\u00f3\3\u00f2\26\uffff\1\u00fb\1"+
            "\u00fd\1\u00fc\1\u00f1\36\uffff\1\31\5\uffff\1\u00f6\1\u00f5"+
            "\1\u00f4",
            "\1\117\10\uffff\1\u010a\1\u0109\3\uffff\1\u010b\2\uffff\1\u0103"+
            "\1\u0107\1\u0108\1\uffff\2\u0103\3\u0102\26\uffff\1\u010c\1"+
            "\u010e\1\u010d\1\u0101\36\uffff\1\31\5\uffff\1\u0106\1\u0105"+
            "\1\u0104",
            "\1\117\10\uffff\1\u011a\1\u0119\3\uffff\1\u011b\2\uffff\1\u0113"+
            "\1\u0117\1\u0118\1\uffff\2\u0113\3\u0112\26\uffff\1\u011c\1"+
            "\u011e\1\u011d\1\u0111\36\uffff\1\31\5\uffff\1\u0116\1\u0115"+
            "\1\u0114",
            "\1\u0121",
            "\1\u0123\103\uffff\1\u0122",
            "",
            "\1\u0130\3\uffff\1\u013d\1\u014c\5\uffff\1\u012f\1\uffff\1"+
            "\u012d\2\uffff\1\u013b\1\uffff\1\u012e\1\uffff\1\u012f\3\uffff"+
            "\1\u012f\1\uffff\1\u0132\1\u0133\1\u0124\1\u0125\1\u0141\2\uffff"+
            "\1\u0142\1\u0143\1\u0144\1\u0145\1\u0146\2\uffff\1\u014b\1\u0128"+
            "\1\u0129\1\u012a\1\u0126\1\u0127\4\uffff\1\u013f\1\u0140\2\uffff"+
            "\1\u013e\2\uffff\1\u0147\1\uffff\1\u0148\1\u0149\1\u014a\22"+
            "\uffff\1\u013c\1\u012c\1\uffff\1\u0137\1\u012b\5\uffff\1\u0131"+
            "\1\u013a\1\u0134\1\u0135\1\u0136\1\u0138\1\u0139",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "\1\uffff",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            ""
    };

    static final short[] DFA3_eot = DFA.unpackEncodedString(DFA3_eotS);
    static final short[] DFA3_eof = DFA.unpackEncodedString(DFA3_eofS);
    static final char[] DFA3_min = DFA.unpackEncodedStringToUnsignedChars(DFA3_minS);
    static final char[] DFA3_max = DFA.unpackEncodedStringToUnsignedChars(DFA3_maxS);
    static final short[] DFA3_accept = DFA.unpackEncodedString(DFA3_acceptS);
    static final short[] DFA3_special = DFA.unpackEncodedString(DFA3_specialS);
    static final short[][] DFA3_transition;

    static {
        int numStates = DFA3_transitionS.length;
        DFA3_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA3_transition[i] = DFA.unpackEncodedString(DFA3_transitionS[i]);
        }
    }

    class DFA3 extends DFA {

        public DFA3(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 3;
            this.eot = DFA3_eot;
            this.eof = DFA3_eof;
            this.min = DFA3_min;
            this.max = DFA3_max;
            this.accept = DFA3_accept;
            this.special = DFA3_special;
            this.transition = DFA3_transition;
        }
        public String getDescription() {
            return "141:1: statement : ( ( simpleStatement )? BodyString | '{' statement '}' -> statement | bracketedBlock | classDefinition | interfaceDefinition | complexStatement | simpleStatement ';' );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA3_41 = input.LA(1);

                         
                        int index3_41 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_41);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA3_42 = input.LA(1);

                         
                        int index3_42 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_42);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA3_43 = input.LA(1);

                         
                        int index3_43 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_43);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA3_44 = input.LA(1);

                         
                        int index3_44 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_44);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA3_45 = input.LA(1);

                         
                        int index3_45 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_45);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA3_46 = input.LA(1);

                         
                        int index3_46 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_46);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA3_47 = input.LA(1);

                         
                        int index3_47 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_47);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA3_48 = input.LA(1);

                         
                        int index3_48 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_48);
                        if ( s>=0 ) return s;
                        break;
                    case 8 : 
                        int LA3_49 = input.LA(1);

                         
                        int index3_49 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_49);
                        if ( s>=0 ) return s;
                        break;
                    case 9 : 
                        int LA3_50 = input.LA(1);

                         
                        int index3_50 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_50);
                        if ( s>=0 ) return s;
                        break;
                    case 10 : 
                        int LA3_51 = input.LA(1);

                         
                        int index3_51 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_51);
                        if ( s>=0 ) return s;
                        break;
                    case 11 : 
                        int LA3_52 = input.LA(1);

                         
                        int index3_52 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_52);
                        if ( s>=0 ) return s;
                        break;
                    case 12 : 
                        int LA3_53 = input.LA(1);

                         
                        int index3_53 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_53);
                        if ( s>=0 ) return s;
                        break;
                    case 13 : 
                        int LA3_54 = input.LA(1);

                         
                        int index3_54 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_54);
                        if ( s>=0 ) return s;
                        break;
                    case 14 : 
                        int LA3_55 = input.LA(1);

                         
                        int index3_55 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_55);
                        if ( s>=0 ) return s;
                        break;
                    case 15 : 
                        int LA3_56 = input.LA(1);

                         
                        int index3_56 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_56);
                        if ( s>=0 ) return s;
                        break;
                    case 16 : 
                        int LA3_57 = input.LA(1);

                         
                        int index3_57 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_57);
                        if ( s>=0 ) return s;
                        break;
                    case 17 : 
                        int LA3_58 = input.LA(1);

                         
                        int index3_58 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_58);
                        if ( s>=0 ) return s;
                        break;
                    case 18 : 
                        int LA3_59 = input.LA(1);

                         
                        int index3_59 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_59);
                        if ( s>=0 ) return s;
                        break;
                    case 19 : 
                        int LA3_60 = input.LA(1);

                         
                        int index3_60 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_60);
                        if ( s>=0 ) return s;
                        break;
                    case 20 : 
                        int LA3_61 = input.LA(1);

                         
                        int index3_61 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_61);
                        if ( s>=0 ) return s;
                        break;
                    case 21 : 
                        int LA3_62 = input.LA(1);

                         
                        int index3_62 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_62);
                        if ( s>=0 ) return s;
                        break;
                    case 22 : 
                        int LA3_63 = input.LA(1);

                         
                        int index3_63 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_63);
                        if ( s>=0 ) return s;
                        break;
                    case 23 : 
                        int LA3_64 = input.LA(1);

                         
                        int index3_64 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_64);
                        if ( s>=0 ) return s;
                        break;
                    case 24 : 
                        int LA3_65 = input.LA(1);

                         
                        int index3_65 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_65);
                        if ( s>=0 ) return s;
                        break;
                    case 25 : 
                        int LA3_66 = input.LA(1);

                         
                        int index3_66 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_66);
                        if ( s>=0 ) return s;
                        break;
                    case 26 : 
                        int LA3_67 = input.LA(1);

                         
                        int index3_67 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_67);
                        if ( s>=0 ) return s;
                        break;
                    case 27 : 
                        int LA3_68 = input.LA(1);

                         
                        int index3_68 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_68);
                        if ( s>=0 ) return s;
                        break;
                    case 28 : 
                        int LA3_69 = input.LA(1);

                         
                        int index3_69 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_69);
                        if ( s>=0 ) return s;
                        break;
                    case 29 : 
                        int LA3_70 = input.LA(1);

                         
                        int index3_70 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_70);
                        if ( s>=0 ) return s;
                        break;
                    case 30 : 
                        int LA3_71 = input.LA(1);

                         
                        int index3_71 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_71);
                        if ( s>=0 ) return s;
                        break;
                    case 31 : 
                        int LA3_72 = input.LA(1);

                         
                        int index3_72 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_72);
                        if ( s>=0 ) return s;
                        break;
                    case 32 : 
                        int LA3_73 = input.LA(1);

                         
                        int index3_73 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_73);
                        if ( s>=0 ) return s;
                        break;
                    case 33 : 
                        int LA3_74 = input.LA(1);

                         
                        int index3_74 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_74);
                        if ( s>=0 ) return s;
                        break;
                    case 34 : 
                        int LA3_75 = input.LA(1);

                         
                        int index3_75 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_75);
                        if ( s>=0 ) return s;
                        break;
                    case 35 : 
                        int LA3_76 = input.LA(1);

                         
                        int index3_76 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_76);
                        if ( s>=0 ) return s;
                        break;
                    case 36 : 
                        int LA3_77 = input.LA(1);

                         
                        int index3_77 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_77);
                        if ( s>=0 ) return s;
                        break;
                    case 37 : 
                        int LA3_80 = input.LA(1);

                         
                        int index3_80 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_80);
                        if ( s>=0 ) return s;
                        break;
                    case 38 : 
                        int LA3_83 = input.LA(1);

                         
                        int index3_83 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_83);
                        if ( s>=0 ) return s;
                        break;
                    case 39 : 
                        int LA3_84 = input.LA(1);

                         
                        int index3_84 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_84);
                        if ( s>=0 ) return s;
                        break;
                    case 40 : 
                        int LA3_85 = input.LA(1);

                         
                        int index3_85 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_85);
                        if ( s>=0 ) return s;
                        break;
                    case 41 : 
                        int LA3_86 = input.LA(1);

                         
                        int index3_86 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_86);
                        if ( s>=0 ) return s;
                        break;
                    case 42 : 
                        int LA3_87 = input.LA(1);

                         
                        int index3_87 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_87);
                        if ( s>=0 ) return s;
                        break;
                    case 43 : 
                        int LA3_88 = input.LA(1);

                         
                        int index3_88 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_88);
                        if ( s>=0 ) return s;
                        break;
                    case 44 : 
                        int LA3_89 = input.LA(1);

                         
                        int index3_89 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_89);
                        if ( s>=0 ) return s;
                        break;
                    case 45 : 
                        int LA3_90 = input.LA(1);

                         
                        int index3_90 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_90);
                        if ( s>=0 ) return s;
                        break;
                    case 46 : 
                        int LA3_91 = input.LA(1);

                         
                        int index3_91 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_91);
                        if ( s>=0 ) return s;
                        break;
                    case 47 : 
                        int LA3_92 = input.LA(1);

                         
                        int index3_92 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_92);
                        if ( s>=0 ) return s;
                        break;
                    case 48 : 
                        int LA3_93 = input.LA(1);

                         
                        int index3_93 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_93);
                        if ( s>=0 ) return s;
                        break;
                    case 49 : 
                        int LA3_94 = input.LA(1);

                         
                        int index3_94 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_94);
                        if ( s>=0 ) return s;
                        break;
                    case 50 : 
                        int LA3_95 = input.LA(1);

                         
                        int index3_95 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_95);
                        if ( s>=0 ) return s;
                        break;
                    case 51 : 
                        int LA3_96 = input.LA(1);

                         
                        int index3_96 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_96);
                        if ( s>=0 ) return s;
                        break;
                    case 52 : 
                        int LA3_97 = input.LA(1);

                         
                        int index3_97 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_97);
                        if ( s>=0 ) return s;
                        break;
                    case 53 : 
                        int LA3_98 = input.LA(1);

                         
                        int index3_98 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_98);
                        if ( s>=0 ) return s;
                        break;
                    case 54 : 
                        int LA3_101 = input.LA(1);

                         
                        int index3_101 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_101);
                        if ( s>=0 ) return s;
                        break;
                    case 55 : 
                        int LA3_102 = input.LA(1);

                         
                        int index3_102 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_102);
                        if ( s>=0 ) return s;
                        break;
                    case 56 : 
                        int LA3_103 = input.LA(1);

                         
                        int index3_103 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_103);
                        if ( s>=0 ) return s;
                        break;
                    case 57 : 
                        int LA3_104 = input.LA(1);

                         
                        int index3_104 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_104);
                        if ( s>=0 ) return s;
                        break;
                    case 58 : 
                        int LA3_105 = input.LA(1);

                         
                        int index3_105 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_105);
                        if ( s>=0 ) return s;
                        break;
                    case 59 : 
                        int LA3_106 = input.LA(1);

                         
                        int index3_106 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_106);
                        if ( s>=0 ) return s;
                        break;
                    case 60 : 
                        int LA3_107 = input.LA(1);

                         
                        int index3_107 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_107);
                        if ( s>=0 ) return s;
                        break;
                    case 61 : 
                        int LA3_108 = input.LA(1);

                         
                        int index3_108 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_108);
                        if ( s>=0 ) return s;
                        break;
                    case 62 : 
                        int LA3_109 = input.LA(1);

                         
                        int index3_109 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_109);
                        if ( s>=0 ) return s;
                        break;
                    case 63 : 
                        int LA3_110 = input.LA(1);

                         
                        int index3_110 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_110);
                        if ( s>=0 ) return s;
                        break;
                    case 64 : 
                        int LA3_111 = input.LA(1);

                         
                        int index3_111 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_111);
                        if ( s>=0 ) return s;
                        break;
                    case 65 : 
                        int LA3_112 = input.LA(1);

                         
                        int index3_112 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_112);
                        if ( s>=0 ) return s;
                        break;
                    case 66 : 
                        int LA3_113 = input.LA(1);

                         
                        int index3_113 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_113);
                        if ( s>=0 ) return s;
                        break;
                    case 67 : 
                        int LA3_114 = input.LA(1);

                         
                        int index3_114 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_114);
                        if ( s>=0 ) return s;
                        break;
                    case 68 : 
                        int LA3_115 = input.LA(1);

                         
                        int index3_115 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_115);
                        if ( s>=0 ) return s;
                        break;
                    case 69 : 
                        int LA3_116 = input.LA(1);

                         
                        int index3_116 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_116);
                        if ( s>=0 ) return s;
                        break;
                    case 70 : 
                        int LA3_117 = input.LA(1);

                         
                        int index3_117 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_117);
                        if ( s>=0 ) return s;
                        break;
                    case 71 : 
                        int LA3_118 = input.LA(1);

                         
                        int index3_118 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_118);
                        if ( s>=0 ) return s;
                        break;
                    case 72 : 
                        int LA3_119 = input.LA(1);

                         
                        int index3_119 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_119);
                        if ( s>=0 ) return s;
                        break;
                    case 73 : 
                        int LA3_120 = input.LA(1);

                         
                        int index3_120 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_120);
                        if ( s>=0 ) return s;
                        break;
                    case 74 : 
                        int LA3_121 = input.LA(1);

                         
                        int index3_121 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_121);
                        if ( s>=0 ) return s;
                        break;
                    case 75 : 
                        int LA3_122 = input.LA(1);

                         
                        int index3_122 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_122);
                        if ( s>=0 ) return s;
                        break;
                    case 76 : 
                        int LA3_123 = input.LA(1);

                         
                        int index3_123 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_123);
                        if ( s>=0 ) return s;
                        break;
                    case 77 : 
                        int LA3_124 = input.LA(1);

                         
                        int index3_124 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_124);
                        if ( s>=0 ) return s;
                        break;
                    case 78 : 
                        int LA3_125 = input.LA(1);

                         
                        int index3_125 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_125);
                        if ( s>=0 ) return s;
                        break;
                    case 79 : 
                        int LA3_126 = input.LA(1);

                         
                        int index3_126 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_126);
                        if ( s>=0 ) return s;
                        break;
                    case 80 : 
                        int LA3_127 = input.LA(1);

                         
                        int index3_127 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_127);
                        if ( s>=0 ) return s;
                        break;
                    case 81 : 
                        int LA3_128 = input.LA(1);

                         
                        int index3_128 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_128);
                        if ( s>=0 ) return s;
                        break;
                    case 82 : 
                        int LA3_129 = input.LA(1);

                         
                        int index3_129 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_129);
                        if ( s>=0 ) return s;
                        break;
                    case 83 : 
                        int LA3_130 = input.LA(1);

                         
                        int index3_130 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_130);
                        if ( s>=0 ) return s;
                        break;
                    case 84 : 
                        int LA3_131 = input.LA(1);

                         
                        int index3_131 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_131);
                        if ( s>=0 ) return s;
                        break;
                    case 85 : 
                        int LA3_132 = input.LA(1);

                         
                        int index3_132 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_132);
                        if ( s>=0 ) return s;
                        break;
                    case 86 : 
                        int LA3_133 = input.LA(1);

                         
                        int index3_133 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_133);
                        if ( s>=0 ) return s;
                        break;
                    case 87 : 
                        int LA3_134 = input.LA(1);

                         
                        int index3_134 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_134);
                        if ( s>=0 ) return s;
                        break;
                    case 88 : 
                        int LA3_135 = input.LA(1);

                         
                        int index3_135 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_135);
                        if ( s>=0 ) return s;
                        break;
                    case 89 : 
                        int LA3_136 = input.LA(1);

                         
                        int index3_136 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_136);
                        if ( s>=0 ) return s;
                        break;
                    case 90 : 
                        int LA3_139 = input.LA(1);

                         
                        int index3_139 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_139);
                        if ( s>=0 ) return s;
                        break;
                    case 91 : 
                        int LA3_140 = input.LA(1);

                         
                        int index3_140 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_140);
                        if ( s>=0 ) return s;
                        break;
                    case 92 : 
                        int LA3_141 = input.LA(1);

                         
                        int index3_141 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_141);
                        if ( s>=0 ) return s;
                        break;
                    case 93 : 
                        int LA3_142 = input.LA(1);

                         
                        int index3_142 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_142);
                        if ( s>=0 ) return s;
                        break;
                    case 94 : 
                        int LA3_143 = input.LA(1);

                         
                        int index3_143 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_143);
                        if ( s>=0 ) return s;
                        break;
                    case 95 : 
                        int LA3_144 = input.LA(1);

                         
                        int index3_144 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_144);
                        if ( s>=0 ) return s;
                        break;
                    case 96 : 
                        int LA3_145 = input.LA(1);

                         
                        int index3_145 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_145);
                        if ( s>=0 ) return s;
                        break;
                    case 97 : 
                        int LA3_146 = input.LA(1);

                         
                        int index3_146 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_146);
                        if ( s>=0 ) return s;
                        break;
                    case 98 : 
                        int LA3_147 = input.LA(1);

                         
                        int index3_147 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_147);
                        if ( s>=0 ) return s;
                        break;
                    case 99 : 
                        int LA3_148 = input.LA(1);

                         
                        int index3_148 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_148);
                        if ( s>=0 ) return s;
                        break;
                    case 100 : 
                        int LA3_149 = input.LA(1);

                         
                        int index3_149 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_149);
                        if ( s>=0 ) return s;
                        break;
                    case 101 : 
                        int LA3_150 = input.LA(1);

                         
                        int index3_150 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_150);
                        if ( s>=0 ) return s;
                        break;
                    case 102 : 
                        int LA3_151 = input.LA(1);

                         
                        int index3_151 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_151);
                        if ( s>=0 ) return s;
                        break;
                    case 103 : 
                        int LA3_152 = input.LA(1);

                         
                        int index3_152 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_152);
                        if ( s>=0 ) return s;
                        break;
                    case 104 : 
                        int LA3_153 = input.LA(1);

                         
                        int index3_153 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_153);
                        if ( s>=0 ) return s;
                        break;
                    case 105 : 
                        int LA3_154 = input.LA(1);

                         
                        int index3_154 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_154);
                        if ( s>=0 ) return s;
                        break;
                    case 106 : 
                        int LA3_155 = input.LA(1);

                         
                        int index3_155 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_155);
                        if ( s>=0 ) return s;
                        break;
                    case 107 : 
                        int LA3_156 = input.LA(1);

                         
                        int index3_156 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_156);
                        if ( s>=0 ) return s;
                        break;
                    case 108 : 
                        int LA3_157 = input.LA(1);

                         
                        int index3_157 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_157);
                        if ( s>=0 ) return s;
                        break;
                    case 109 : 
                        int LA3_158 = input.LA(1);

                         
                        int index3_158 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_158);
                        if ( s>=0 ) return s;
                        break;
                    case 110 : 
                        int LA3_159 = input.LA(1);

                         
                        int index3_159 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_159);
                        if ( s>=0 ) return s;
                        break;
                    case 111 : 
                        int LA3_160 = input.LA(1);

                         
                        int index3_160 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_160);
                        if ( s>=0 ) return s;
                        break;
                    case 112 : 
                        int LA3_161 = input.LA(1);

                         
                        int index3_161 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_161);
                        if ( s>=0 ) return s;
                        break;
                    case 113 : 
                        int LA3_162 = input.LA(1);

                         
                        int index3_162 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_162);
                        if ( s>=0 ) return s;
                        break;
                    case 114 : 
                        int LA3_163 = input.LA(1);

                         
                        int index3_163 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_163);
                        if ( s>=0 ) return s;
                        break;
                    case 115 : 
                        int LA3_164 = input.LA(1);

                         
                        int index3_164 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_164);
                        if ( s>=0 ) return s;
                        break;
                    case 116 : 
                        int LA3_165 = input.LA(1);

                         
                        int index3_165 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_165);
                        if ( s>=0 ) return s;
                        break;
                    case 117 : 
                        int LA3_166 = input.LA(1);

                         
                        int index3_166 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_166);
                        if ( s>=0 ) return s;
                        break;
                    case 118 : 
                        int LA3_167 = input.LA(1);

                         
                        int index3_167 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_167);
                        if ( s>=0 ) return s;
                        break;
                    case 119 : 
                        int LA3_168 = input.LA(1);

                         
                        int index3_168 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_168);
                        if ( s>=0 ) return s;
                        break;
                    case 120 : 
                        int LA3_169 = input.LA(1);

                         
                        int index3_169 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_169);
                        if ( s>=0 ) return s;
                        break;
                    case 121 : 
                        int LA3_170 = input.LA(1);

                         
                        int index3_170 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_170);
                        if ( s>=0 ) return s;
                        break;
                    case 122 : 
                        int LA3_171 = input.LA(1);

                         
                        int index3_171 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_171);
                        if ( s>=0 ) return s;
                        break;
                    case 123 : 
                        int LA3_172 = input.LA(1);

                         
                        int index3_172 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_172);
                        if ( s>=0 ) return s;
                        break;
                    case 124 : 
                        int LA3_173 = input.LA(1);

                         
                        int index3_173 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_173);
                        if ( s>=0 ) return s;
                        break;
                    case 125 : 
                        int LA3_174 = input.LA(1);

                         
                        int index3_174 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_174);
                        if ( s>=0 ) return s;
                        break;
                    case 126 : 
                        int LA3_175 = input.LA(1);

                         
                        int index3_175 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_175);
                        if ( s>=0 ) return s;
                        break;
                    case 127 : 
                        int LA3_176 = input.LA(1);

                         
                        int index3_176 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_176);
                        if ( s>=0 ) return s;
                        break;
                    case 128 : 
                        int LA3_177 = input.LA(1);

                         
                        int index3_177 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_177);
                        if ( s>=0 ) return s;
                        break;
                    case 129 : 
                        int LA3_178 = input.LA(1);

                         
                        int index3_178 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_178);
                        if ( s>=0 ) return s;
                        break;
                    case 130 : 
                        int LA3_179 = input.LA(1);

                         
                        int index3_179 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_179);
                        if ( s>=0 ) return s;
                        break;
                    case 131 : 
                        int LA3_180 = input.LA(1);

                         
                        int index3_180 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_180);
                        if ( s>=0 ) return s;
                        break;
                    case 132 : 
                        int LA3_181 = input.LA(1);

                         
                        int index3_181 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_181);
                        if ( s>=0 ) return s;
                        break;
                    case 133 : 
                        int LA3_182 = input.LA(1);

                         
                        int index3_182 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_182);
                        if ( s>=0 ) return s;
                        break;
                    case 134 : 
                        int LA3_183 = input.LA(1);

                         
                        int index3_183 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_183);
                        if ( s>=0 ) return s;
                        break;
                    case 135 : 
                        int LA3_184 = input.LA(1);

                         
                        int index3_184 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_184);
                        if ( s>=0 ) return s;
                        break;
                    case 136 : 
                        int LA3_185 = input.LA(1);

                         
                        int index3_185 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_185);
                        if ( s>=0 ) return s;
                        break;
                    case 137 : 
                        int LA3_186 = input.LA(1);

                         
                        int index3_186 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_186);
                        if ( s>=0 ) return s;
                        break;
                    case 138 : 
                        int LA3_187 = input.LA(1);

                         
                        int index3_187 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_187);
                        if ( s>=0 ) return s;
                        break;
                    case 139 : 
                        int LA3_188 = input.LA(1);

                         
                        int index3_188 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_188);
                        if ( s>=0 ) return s;
                        break;
                    case 140 : 
                        int LA3_189 = input.LA(1);

                         
                        int index3_189 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_189);
                        if ( s>=0 ) return s;
                        break;
                    case 141 : 
                        int LA3_190 = input.LA(1);

                         
                        int index3_190 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_190);
                        if ( s>=0 ) return s;
                        break;
                    case 142 : 
                        int LA3_191 = input.LA(1);

                         
                        int index3_191 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_191);
                        if ( s>=0 ) return s;
                        break;
                    case 143 : 
                        int LA3_192 = input.LA(1);

                         
                        int index3_192 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_192);
                        if ( s>=0 ) return s;
                        break;
                    case 144 : 
                        int LA3_193 = input.LA(1);

                         
                        int index3_193 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_193);
                        if ( s>=0 ) return s;
                        break;
                    case 145 : 
                        int LA3_194 = input.LA(1);

                         
                        int index3_194 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_194);
                        if ( s>=0 ) return s;
                        break;
                    case 146 : 
                        int LA3_195 = input.LA(1);

                         
                        int index3_195 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_195);
                        if ( s>=0 ) return s;
                        break;
                    case 147 : 
                        int LA3_196 = input.LA(1);

                         
                        int index3_196 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_196);
                        if ( s>=0 ) return s;
                        break;
                    case 148 : 
                        int LA3_197 = input.LA(1);

                         
                        int index3_197 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_197);
                        if ( s>=0 ) return s;
                        break;
                    case 149 : 
                        int LA3_198 = input.LA(1);

                         
                        int index3_198 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_198);
                        if ( s>=0 ) return s;
                        break;
                    case 150 : 
                        int LA3_199 = input.LA(1);

                         
                        int index3_199 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_199);
                        if ( s>=0 ) return s;
                        break;
                    case 151 : 
                        int LA3_200 = input.LA(1);

                         
                        int index3_200 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_200);
                        if ( s>=0 ) return s;
                        break;
                    case 152 : 
                        int LA3_201 = input.LA(1);

                         
                        int index3_201 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_201);
                        if ( s>=0 ) return s;
                        break;
                    case 153 : 
                        int LA3_202 = input.LA(1);

                         
                        int index3_202 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_202);
                        if ( s>=0 ) return s;
                        break;
                    case 154 : 
                        int LA3_203 = input.LA(1);

                         
                        int index3_203 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_203);
                        if ( s>=0 ) return s;
                        break;
                    case 155 : 
                        int LA3_204 = input.LA(1);

                         
                        int index3_204 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_204);
                        if ( s>=0 ) return s;
                        break;
                    case 156 : 
                        int LA3_205 = input.LA(1);

                         
                        int index3_205 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_205);
                        if ( s>=0 ) return s;
                        break;
                    case 157 : 
                        int LA3_207 = input.LA(1);

                         
                        int index3_207 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_207);
                        if ( s>=0 ) return s;
                        break;
                    case 158 : 
                        int LA3_209 = input.LA(1);

                         
                        int index3_209 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_209);
                        if ( s>=0 ) return s;
                        break;
                    case 159 : 
                        int LA3_210 = input.LA(1);

                         
                        int index3_210 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_210);
                        if ( s>=0 ) return s;
                        break;
                    case 160 : 
                        int LA3_211 = input.LA(1);

                         
                        int index3_211 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_211);
                        if ( s>=0 ) return s;
                        break;
                    case 161 : 
                        int LA3_212 = input.LA(1);

                         
                        int index3_212 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_212);
                        if ( s>=0 ) return s;
                        break;
                    case 162 : 
                        int LA3_213 = input.LA(1);

                         
                        int index3_213 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_213);
                        if ( s>=0 ) return s;
                        break;
                    case 163 : 
                        int LA3_214 = input.LA(1);

                         
                        int index3_214 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_214);
                        if ( s>=0 ) return s;
                        break;
                    case 164 : 
                        int LA3_215 = input.LA(1);

                         
                        int index3_215 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_215);
                        if ( s>=0 ) return s;
                        break;
                    case 165 : 
                        int LA3_216 = input.LA(1);

                         
                        int index3_216 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_216);
                        if ( s>=0 ) return s;
                        break;
                    case 166 : 
                        int LA3_217 = input.LA(1);

                         
                        int index3_217 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_217);
                        if ( s>=0 ) return s;
                        break;
                    case 167 : 
                        int LA3_218 = input.LA(1);

                         
                        int index3_218 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_218);
                        if ( s>=0 ) return s;
                        break;
                    case 168 : 
                        int LA3_219 = input.LA(1);

                         
                        int index3_219 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_219);
                        if ( s>=0 ) return s;
                        break;
                    case 169 : 
                        int LA3_220 = input.LA(1);

                         
                        int index3_220 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_220);
                        if ( s>=0 ) return s;
                        break;
                    case 170 : 
                        int LA3_221 = input.LA(1);

                         
                        int index3_221 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_221);
                        if ( s>=0 ) return s;
                        break;
                    case 171 : 
                        int LA3_222 = input.LA(1);

                         
                        int index3_222 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_222);
                        if ( s>=0 ) return s;
                        break;
                    case 172 : 
                        int LA3_225 = input.LA(1);

                         
                        int index3_225 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_225);
                        if ( s>=0 ) return s;
                        break;
                    case 173 : 
                        int LA3_226 = input.LA(1);

                         
                        int index3_226 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_226);
                        if ( s>=0 ) return s;
                        break;
                    case 174 : 
                        int LA3_227 = input.LA(1);

                         
                        int index3_227 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_227);
                        if ( s>=0 ) return s;
                        break;
                    case 175 : 
                        int LA3_228 = input.LA(1);

                         
                        int index3_228 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_228);
                        if ( s>=0 ) return s;
                        break;
                    case 176 : 
                        int LA3_229 = input.LA(1);

                         
                        int index3_229 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_229);
                        if ( s>=0 ) return s;
                        break;
                    case 177 : 
                        int LA3_230 = input.LA(1);

                         
                        int index3_230 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_230);
                        if ( s>=0 ) return s;
                        break;
                    case 178 : 
                        int LA3_231 = input.LA(1);

                         
                        int index3_231 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_231);
                        if ( s>=0 ) return s;
                        break;
                    case 179 : 
                        int LA3_232 = input.LA(1);

                         
                        int index3_232 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_232);
                        if ( s>=0 ) return s;
                        break;
                    case 180 : 
                        int LA3_233 = input.LA(1);

                         
                        int index3_233 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_233);
                        if ( s>=0 ) return s;
                        break;
                    case 181 : 
                        int LA3_234 = input.LA(1);

                         
                        int index3_234 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_234);
                        if ( s>=0 ) return s;
                        break;
                    case 182 : 
                        int LA3_235 = input.LA(1);

                         
                        int index3_235 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_235);
                        if ( s>=0 ) return s;
                        break;
                    case 183 : 
                        int LA3_236 = input.LA(1);

                         
                        int index3_236 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_236);
                        if ( s>=0 ) return s;
                        break;
                    case 184 : 
                        int LA3_237 = input.LA(1);

                         
                        int index3_237 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_237);
                        if ( s>=0 ) return s;
                        break;
                    case 185 : 
                        int LA3_238 = input.LA(1);

                         
                        int index3_238 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_238);
                        if ( s>=0 ) return s;
                        break;
                    case 186 : 
                        int LA3_241 = input.LA(1);

                         
                        int index3_241 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_241);
                        if ( s>=0 ) return s;
                        break;
                    case 187 : 
                        int LA3_242 = input.LA(1);

                         
                        int index3_242 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_242);
                        if ( s>=0 ) return s;
                        break;
                    case 188 : 
                        int LA3_243 = input.LA(1);

                         
                        int index3_243 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_243);
                        if ( s>=0 ) return s;
                        break;
                    case 189 : 
                        int LA3_244 = input.LA(1);

                         
                        int index3_244 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_244);
                        if ( s>=0 ) return s;
                        break;
                    case 190 : 
                        int LA3_245 = input.LA(1);

                         
                        int index3_245 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_245);
                        if ( s>=0 ) return s;
                        break;
                    case 191 : 
                        int LA3_246 = input.LA(1);

                         
                        int index3_246 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_246);
                        if ( s>=0 ) return s;
                        break;
                    case 192 : 
                        int LA3_247 = input.LA(1);

                         
                        int index3_247 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_247);
                        if ( s>=0 ) return s;
                        break;
                    case 193 : 
                        int LA3_248 = input.LA(1);

                         
                        int index3_248 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_248);
                        if ( s>=0 ) return s;
                        break;
                    case 194 : 
                        int LA3_249 = input.LA(1);

                         
                        int index3_249 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_249);
                        if ( s>=0 ) return s;
                        break;
                    case 195 : 
                        int LA3_250 = input.LA(1);

                         
                        int index3_250 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_250);
                        if ( s>=0 ) return s;
                        break;
                    case 196 : 
                        int LA3_251 = input.LA(1);

                         
                        int index3_251 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_251);
                        if ( s>=0 ) return s;
                        break;
                    case 197 : 
                        int LA3_252 = input.LA(1);

                         
                        int index3_252 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_252);
                        if ( s>=0 ) return s;
                        break;
                    case 198 : 
                        int LA3_253 = input.LA(1);

                         
                        int index3_253 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_253);
                        if ( s>=0 ) return s;
                        break;
                    case 199 : 
                        int LA3_256 = input.LA(1);

                         
                        int index3_256 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_256);
                        if ( s>=0 ) return s;
                        break;
                    case 200 : 
                        int LA3_257 = input.LA(1);

                         
                        int index3_257 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_257);
                        if ( s>=0 ) return s;
                        break;
                    case 201 : 
                        int LA3_258 = input.LA(1);

                         
                        int index3_258 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_258);
                        if ( s>=0 ) return s;
                        break;
                    case 202 : 
                        int LA3_259 = input.LA(1);

                         
                        int index3_259 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_259);
                        if ( s>=0 ) return s;
                        break;
                    case 203 : 
                        int LA3_260 = input.LA(1);

                         
                        int index3_260 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_260);
                        if ( s>=0 ) return s;
                        break;
                    case 204 : 
                        int LA3_261 = input.LA(1);

                         
                        int index3_261 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_261);
                        if ( s>=0 ) return s;
                        break;
                    case 205 : 
                        int LA3_262 = input.LA(1);

                         
                        int index3_262 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_262);
                        if ( s>=0 ) return s;
                        break;
                    case 206 : 
                        int LA3_263 = input.LA(1);

                         
                        int index3_263 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_263);
                        if ( s>=0 ) return s;
                        break;
                    case 207 : 
                        int LA3_264 = input.LA(1);

                         
                        int index3_264 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_264);
                        if ( s>=0 ) return s;
                        break;
                    case 208 : 
                        int LA3_265 = input.LA(1);

                         
                        int index3_265 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_265);
                        if ( s>=0 ) return s;
                        break;
                    case 209 : 
                        int LA3_266 = input.LA(1);

                         
                        int index3_266 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_266);
                        if ( s>=0 ) return s;
                        break;
                    case 210 : 
                        int LA3_267 = input.LA(1);

                         
                        int index3_267 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_267);
                        if ( s>=0 ) return s;
                        break;
                    case 211 : 
                        int LA3_268 = input.LA(1);

                         
                        int index3_268 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_268);
                        if ( s>=0 ) return s;
                        break;
                    case 212 : 
                        int LA3_269 = input.LA(1);

                         
                        int index3_269 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_269);
                        if ( s>=0 ) return s;
                        break;
                    case 213 : 
                        int LA3_270 = input.LA(1);

                         
                        int index3_270 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_270);
                        if ( s>=0 ) return s;
                        break;
                    case 214 : 
                        int LA3_273 = input.LA(1);

                         
                        int index3_273 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_273);
                        if ( s>=0 ) return s;
                        break;
                    case 215 : 
                        int LA3_274 = input.LA(1);

                         
                        int index3_274 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_274);
                        if ( s>=0 ) return s;
                        break;
                    case 216 : 
                        int LA3_275 = input.LA(1);

                         
                        int index3_275 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_275);
                        if ( s>=0 ) return s;
                        break;
                    case 217 : 
                        int LA3_276 = input.LA(1);

                         
                        int index3_276 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_276);
                        if ( s>=0 ) return s;
                        break;
                    case 218 : 
                        int LA3_277 = input.LA(1);

                         
                        int index3_277 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_277);
                        if ( s>=0 ) return s;
                        break;
                    case 219 : 
                        int LA3_278 = input.LA(1);

                         
                        int index3_278 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_278);
                        if ( s>=0 ) return s;
                        break;
                    case 220 : 
                        int LA3_279 = input.LA(1);

                         
                        int index3_279 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_279);
                        if ( s>=0 ) return s;
                        break;
                    case 221 : 
                        int LA3_280 = input.LA(1);

                         
                        int index3_280 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_280);
                        if ( s>=0 ) return s;
                        break;
                    case 222 : 
                        int LA3_281 = input.LA(1);

                         
                        int index3_281 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_281);
                        if ( s>=0 ) return s;
                        break;
                    case 223 : 
                        int LA3_282 = input.LA(1);

                         
                        int index3_282 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_282);
                        if ( s>=0 ) return s;
                        break;
                    case 224 : 
                        int LA3_283 = input.LA(1);

                         
                        int index3_283 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_283);
                        if ( s>=0 ) return s;
                        break;
                    case 225 : 
                        int LA3_284 = input.LA(1);

                         
                        int index3_284 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_284);
                        if ( s>=0 ) return s;
                        break;
                    case 226 : 
                        int LA3_285 = input.LA(1);

                         
                        int index3_285 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_285);
                        if ( s>=0 ) return s;
                        break;
                    case 227 : 
                        int LA3_286 = input.LA(1);

                         
                        int index3_286 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_286);
                        if ( s>=0 ) return s;
                        break;
                    case 228 : 
                        int LA3_289 = input.LA(1);

                         
                        int index3_289 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_289);
                        if ( s>=0 ) return s;
                        break;
                    case 229 : 
                        int LA3_290 = input.LA(1);

                         
                        int index3_290 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_290);
                        if ( s>=0 ) return s;
                        break;
                    case 230 : 
                        int LA3_291 = input.LA(1);

                         
                        int index3_291 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred3_Php()) ) {s = 25;}

                        else if ( (true) ) {s = 79;}

                         
                        input.seek(index3_291);
                        if ( s>=0 ) return s;
                        break;
                    case 231 : 
                        int LA3_292 = input.LA(1);

                         
                        int index3_292 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_292);
                        if ( s>=0 ) return s;
                        break;
                    case 232 : 
                        int LA3_293 = input.LA(1);

                         
                        int index3_293 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_293);
                        if ( s>=0 ) return s;
                        break;
                    case 233 : 
                        int LA3_294 = input.LA(1);

                         
                        int index3_294 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_294);
                        if ( s>=0 ) return s;
                        break;
                    case 234 : 
                        int LA3_295 = input.LA(1);

                         
                        int index3_295 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_295);
                        if ( s>=0 ) return s;
                        break;
                    case 235 : 
                        int LA3_296 = input.LA(1);

                         
                        int index3_296 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_296);
                        if ( s>=0 ) return s;
                        break;
                    case 236 : 
                        int LA3_297 = input.LA(1);

                         
                        int index3_297 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_297);
                        if ( s>=0 ) return s;
                        break;
                    case 237 : 
                        int LA3_298 = input.LA(1);

                         
                        int index3_298 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_298);
                        if ( s>=0 ) return s;
                        break;
                    case 238 : 
                        int LA3_299 = input.LA(1);

                         
                        int index3_299 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_299);
                        if ( s>=0 ) return s;
                        break;
                    case 239 : 
                        int LA3_300 = input.LA(1);

                         
                        int index3_300 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_300);
                        if ( s>=0 ) return s;
                        break;
                    case 240 : 
                        int LA3_301 = input.LA(1);

                         
                        int index3_301 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_301);
                        if ( s>=0 ) return s;
                        break;
                    case 241 : 
                        int LA3_302 = input.LA(1);

                         
                        int index3_302 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_302);
                        if ( s>=0 ) return s;
                        break;
                    case 242 : 
                        int LA3_303 = input.LA(1);

                         
                        int index3_303 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_303);
                        if ( s>=0 ) return s;
                        break;
                    case 243 : 
                        int LA3_304 = input.LA(1);

                         
                        int index3_304 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_304);
                        if ( s>=0 ) return s;
                        break;
                    case 244 : 
                        int LA3_305 = input.LA(1);

                         
                        int index3_305 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_305);
                        if ( s>=0 ) return s;
                        break;
                    case 245 : 
                        int LA3_306 = input.LA(1);

                         
                        int index3_306 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_306);
                        if ( s>=0 ) return s;
                        break;
                    case 246 : 
                        int LA3_307 = input.LA(1);

                         
                        int index3_307 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_307);
                        if ( s>=0 ) return s;
                        break;
                    case 247 : 
                        int LA3_308 = input.LA(1);

                         
                        int index3_308 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_308);
                        if ( s>=0 ) return s;
                        break;
                    case 248 : 
                        int LA3_309 = input.LA(1);

                         
                        int index3_309 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_309);
                        if ( s>=0 ) return s;
                        break;
                    case 249 : 
                        int LA3_310 = input.LA(1);

                         
                        int index3_310 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_310);
                        if ( s>=0 ) return s;
                        break;
                    case 250 : 
                        int LA3_311 = input.LA(1);

                         
                        int index3_311 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_311);
                        if ( s>=0 ) return s;
                        break;
                    case 251 : 
                        int LA3_312 = input.LA(1);

                         
                        int index3_312 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_312);
                        if ( s>=0 ) return s;
                        break;
                    case 252 : 
                        int LA3_313 = input.LA(1);

                         
                        int index3_313 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_313);
                        if ( s>=0 ) return s;
                        break;
                    case 253 : 
                        int LA3_314 = input.LA(1);

                         
                        int index3_314 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_314);
                        if ( s>=0 ) return s;
                        break;
                    case 254 : 
                        int LA3_315 = input.LA(1);

                         
                        int index3_315 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_315);
                        if ( s>=0 ) return s;
                        break;
                    case 255 : 
                        int LA3_316 = input.LA(1);

                         
                        int index3_316 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_316);
                        if ( s>=0 ) return s;
                        break;
                    case 256 : 
                        int LA3_317 = input.LA(1);

                         
                        int index3_317 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_317);
                        if ( s>=0 ) return s;
                        break;
                    case 257 : 
                        int LA3_318 = input.LA(1);

                         
                        int index3_318 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_318);
                        if ( s>=0 ) return s;
                        break;
                    case 258 : 
                        int LA3_319 = input.LA(1);

                         
                        int index3_319 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_319);
                        if ( s>=0 ) return s;
                        break;
                    case 259 : 
                        int LA3_320 = input.LA(1);

                         
                        int index3_320 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_320);
                        if ( s>=0 ) return s;
                        break;
                    case 260 : 
                        int LA3_321 = input.LA(1);

                         
                        int index3_321 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_321);
                        if ( s>=0 ) return s;
                        break;
                    case 261 : 
                        int LA3_322 = input.LA(1);

                         
                        int index3_322 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_322);
                        if ( s>=0 ) return s;
                        break;
                    case 262 : 
                        int LA3_323 = input.LA(1);

                         
                        int index3_323 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_323);
                        if ( s>=0 ) return s;
                        break;
                    case 263 : 
                        int LA3_324 = input.LA(1);

                         
                        int index3_324 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_324);
                        if ( s>=0 ) return s;
                        break;
                    case 264 : 
                        int LA3_325 = input.LA(1);

                         
                        int index3_325 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_325);
                        if ( s>=0 ) return s;
                        break;
                    case 265 : 
                        int LA3_326 = input.LA(1);

                         
                        int index3_326 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_326);
                        if ( s>=0 ) return s;
                        break;
                    case 266 : 
                        int LA3_327 = input.LA(1);

                         
                        int index3_327 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_327);
                        if ( s>=0 ) return s;
                        break;
                    case 267 : 
                        int LA3_328 = input.LA(1);

                         
                        int index3_328 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_328);
                        if ( s>=0 ) return s;
                        break;
                    case 268 : 
                        int LA3_329 = input.LA(1);

                         
                        int index3_329 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_329);
                        if ( s>=0 ) return s;
                        break;
                    case 269 : 
                        int LA3_330 = input.LA(1);

                         
                        int index3_330 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_330);
                        if ( s>=0 ) return s;
                        break;
                    case 270 : 
                        int LA3_331 = input.LA(1);

                         
                        int index3_331 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred4_Php()) ) {s = 333;}

                        else if ( (synpred5_Php()) ) {s = 332;}

                         
                        input.seek(index3_331);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 3, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA2_eotS =
        "\32\uffff";
    static final String DFA2_eofS =
        "\32\uffff";
    static final String DFA2_minS =
        "\1\6\31\uffff";
    static final String DFA2_maxS =
        "\1\146\31\uffff";
    static final String DFA2_acceptS =
        "\1\uffff\1\1\27\uffff\1\2";
    static final String DFA2_specialS =
        "\32\uffff}>";
    static final String[] DFA2_transitionS = {
            "\1\1\12\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1\uffff"+
            "\1\1\3\uffff\1\1\1\uffff\4\1\13\uffff\5\1\42\uffff\1\31\1\1"+
            "\1\uffff\2\1\5\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA2_eot = DFA.unpackEncodedString(DFA2_eotS);
    static final short[] DFA2_eof = DFA.unpackEncodedString(DFA2_eofS);
    static final char[] DFA2_min = DFA.unpackEncodedStringToUnsignedChars(DFA2_minS);
    static final char[] DFA2_max = DFA.unpackEncodedStringToUnsignedChars(DFA2_maxS);
    static final short[] DFA2_accept = DFA.unpackEncodedString(DFA2_acceptS);
    static final short[] DFA2_special = DFA.unpackEncodedString(DFA2_specialS);
    static final short[][] DFA2_transition;

    static {
        int numStates = DFA2_transitionS.length;
        DFA2_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA2_transition[i] = DFA.unpackEncodedString(DFA2_transitionS[i]);
        }
    }

    class DFA2 extends DFA {

        public DFA2(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 2;
            this.eot = DFA2_eot;
            this.eof = DFA2_eof;
            this.min = DFA2_min;
            this.max = DFA2_max;
            this.accept = DFA2_accept;
            this.special = DFA2_special;
            this.transition = DFA2_transition;
        }
        public String getDescription() {
            return "142:7: ( simpleStatement )?";
        }
    }
    static final String DFA4_eotS =
        "\52\uffff";
    static final String DFA4_eofS =
        "\52\uffff";
    static final String DFA4_minS =
        "\1\6\51\uffff";
    static final String DFA4_maxS =
        "\1\146\51\uffff";
    static final String DFA4_acceptS =
        "\1\uffff\1\2\1\1\47\uffff";
    static final String DFA4_specialS =
        "\52\uffff}>";
    static final String[] DFA4_transitionS = {
            "\1\2\3\uffff\1\2\1\1\5\uffff\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff"+
            "\1\2\1\uffff\1\2\3\uffff\1\2\1\uffff\5\2\2\uffff\5\2\2\uffff"+
            "\6\2\4\uffff\2\2\2\uffff\1\2\2\uffff\1\2\1\uffff\3\2\22\uffff"+
            "\2\2\1\uffff\2\2\5\uffff\7\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA4_eot = DFA.unpackEncodedString(DFA4_eotS);
    static final short[] DFA4_eof = DFA.unpackEncodedString(DFA4_eofS);
    static final char[] DFA4_min = DFA.unpackEncodedStringToUnsignedChars(DFA4_minS);
    static final char[] DFA4_max = DFA.unpackEncodedStringToUnsignedChars(DFA4_maxS);
    static final short[] DFA4_accept = DFA.unpackEncodedString(DFA4_acceptS);
    static final short[] DFA4_special = DFA.unpackEncodedString(DFA4_specialS);
    static final short[][] DFA4_transition;

    static {
        int numStates = DFA4_transitionS.length;
        DFA4_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA4_transition[i] = DFA.unpackEncodedString(DFA4_transitionS[i]);
        }
    }

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = DFA4_eot;
            this.eof = DFA4_eof;
            this.min = DFA4_min;
            this.max = DFA4_max;
            this.accept = DFA4_accept;
            this.special = DFA4_special;
            this.transition = DFA4_transition;
        }
        public String getDescription() {
            return "()* loopback of 157:11: ( statement )*";
        }
    }
    static final String DFA27_eotS =
        "\14\uffff";
    static final String DFA27_eofS =
        "\14\uffff";
    static final String DFA27_minS =
        "\1\44\13\uffff";
    static final String DFA27_maxS =
        "\1\103\13\uffff";
    static final String DFA27_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13";
    static final String DFA27_specialS =
        "\14\uffff}>";
    static final String[] DFA27_transitionS = {
            "\1\1\2\uffff\1\2\1\3\1\4\1\5\1\6\2\uffff\1\13\20\uffff\1\7\1"+
            "\uffff\1\10\1\11\1\12",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA27_eot = DFA.unpackEncodedString(DFA27_eotS);
    static final short[] DFA27_eof = DFA.unpackEncodedString(DFA27_eofS);
    static final char[] DFA27_min = DFA.unpackEncodedStringToUnsignedChars(DFA27_minS);
    static final char[] DFA27_max = DFA.unpackEncodedStringToUnsignedChars(DFA27_maxS);
    static final short[] DFA27_accept = DFA.unpackEncodedString(DFA27_acceptS);
    static final short[] DFA27_special = DFA.unpackEncodedString(DFA27_specialS);
    static final short[][] DFA27_transition;

    static {
        int numStates = DFA27_transitionS.length;
        DFA27_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA27_transition[i] = DFA.unpackEncodedString(DFA27_transitionS[i]);
        }
    }

    class DFA27 extends DFA {

        public DFA27(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 27;
            this.eot = DFA27_eot;
            this.eof = DFA27_eof;
            this.min = DFA27_min;
            this.max = DFA27_max;
            this.accept = DFA27_accept;
            this.special = DFA27_special;
            this.transition = DFA27_transition;
        }
        public String getDescription() {
            return "219:1: complexStatement : ( IF '(' ifCondition= expression ')' ifTrue= statement ( conditional )? -> ^( IF expression $ifTrue ( conditional )? ) | FOR '(' forInit forCondition forUpdate ')' statement -> ^( FOR forInit forCondition forUpdate statement ) | FOR_EACH '(' variable 'as' arrayEntry ')' statement -> ^( FOR_EACH variable arrayEntry statement ) | WHILE '(' (whileCondition= expression )? ')' statement -> ^( WHILE $whileCondition statement ) | DO statement WHILE '(' doCondition= expression ')' ';' -> ^( DO statement $doCondition) | SWITCH '(' expression ')' '{' cases '}' -> ^( SWITCH expression cases ) | TRY statement catchStatement -> ^( TRY statement catchStatement ) | THROW throwException ';' -> ^( THROW throwException ) | DECLARE '(' declareList ')' ( ';' | statement ) -> ^( DECLARE declareList ( statement )? ) | USE useFilename ';' -> ^( USE useFilename ) | functionDefinition );";
        }
    }
    static final String DFA24_eotS =
        "\132\uffff";
    static final String DFA24_eofS =
        "\1\3\131\uffff";
    static final String DFA24_minS =
        "\1\6\2\0\127\uffff";
    static final String DFA24_maxS =
        "\1\146\2\0\127\uffff";
    static final String DFA24_acceptS =
        "\3\uffff\1\2\55\uffff\1\1\50\uffff";
    static final String DFA24_specialS =
        "\1\uffff\1\0\1\1\127\uffff}>";
    static final String[] DFA24_transitionS = {
            "\1\3\3\uffff\2\3\5\uffff\1\3\1\uffff\1\3\2\uffff\1\3\1\uffff"+
            "\1\3\1\uffff\1\3\3\uffff\1\3\1\uffff\5\3\1\2\1\1\15\3\4\uffff"+
            "\2\3\2\uffff\1\3\2\uffff\5\3\22\uffff\2\3\1\uffff\2\3\5\uffff"+
            "\7\3",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA24_eot = DFA.unpackEncodedString(DFA24_eotS);
    static final short[] DFA24_eof = DFA.unpackEncodedString(DFA24_eofS);
    static final char[] DFA24_min = DFA.unpackEncodedStringToUnsignedChars(DFA24_minS);
    static final char[] DFA24_max = DFA.unpackEncodedStringToUnsignedChars(DFA24_maxS);
    static final short[] DFA24_accept = DFA.unpackEncodedString(DFA24_acceptS);
    static final short[] DFA24_special = DFA.unpackEncodedString(DFA24_specialS);
    static final short[][] DFA24_transition;

    static {
        int numStates = DFA24_transitionS.length;
        DFA24_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA24_transition[i] = DFA.unpackEncodedString(DFA24_transitionS[i]);
        }
    }

    class DFA24 extends DFA {

        public DFA24(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 24;
            this.eot = DFA24_eot;
            this.eof = DFA24_eof;
            this.min = DFA24_min;
            this.max = DFA24_max;
            this.accept = DFA24_accept;
            this.special = DFA24_special;
            this.transition = DFA24_transition;
        }
        public String getDescription() {
            return "220:58: ( conditional )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA24_1 = input.LA(1);

                         
                        int index24_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred34_Php()) ) {s = 49;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index24_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA24_2 = input.LA(1);

                         
                        int index24_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred34_Php()) ) {s = 49;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index24_2);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 24, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA25_eotS =
        "\22\uffff";
    static final String DFA25_eofS =
        "\22\uffff";
    static final String DFA25_minS =
        "\1\6\21\uffff";
    static final String DFA25_maxS =
        "\1\146\21\uffff";
    static final String DFA25_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA25_specialS =
        "\22\uffff}>";
    static final String[] DFA25_transitionS = {
            "\1\1\1\21\11\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1"+
            "\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff\1\1"+
            "\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA25_eot = DFA.unpackEncodedString(DFA25_eotS);
    static final short[] DFA25_eof = DFA.unpackEncodedString(DFA25_eofS);
    static final char[] DFA25_min = DFA.unpackEncodedStringToUnsignedChars(DFA25_minS);
    static final char[] DFA25_max = DFA.unpackEncodedStringToUnsignedChars(DFA25_maxS);
    static final short[] DFA25_accept = DFA.unpackEncodedString(DFA25_acceptS);
    static final short[] DFA25_special = DFA.unpackEncodedString(DFA25_specialS);
    static final short[][] DFA25_transition;

    static {
        int numStates = DFA25_transitionS.length;
        DFA25_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA25_transition[i] = DFA.unpackEncodedString(DFA25_transitionS[i]);
        }
    }

    class DFA25 extends DFA {

        public DFA25(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 25;
            this.eot = DFA25_eot;
            this.eof = DFA25_eof;
            this.min = DFA25_min;
            this.max = DFA25_max;
            this.accept = DFA25_accept;
            this.special = DFA25_special;
            this.transition = DFA25_transition;
        }
        public String getDescription() {
            return "223:31: (whileCondition= expression )?";
        }
    }
    static final String DFA26_eotS =
        "\52\uffff";
    static final String DFA26_eofS =
        "\52\uffff";
    static final String DFA26_minS =
        "\1\4\51\uffff";
    static final String DFA26_maxS =
        "\1\146\51\uffff";
    static final String DFA26_acceptS =
        "\1\uffff\1\1\1\2\47\uffff";
    static final String DFA26_specialS =
        "\52\uffff}>";
    static final String[] DFA26_transitionS = {
            "\1\1\1\uffff\1\2\3\uffff\1\2\6\uffff\1\2\1\uffff\1\2\2\uffff"+
            "\1\2\1\uffff\1\2\1\uffff\1\2\3\uffff\1\2\1\uffff\5\2\2\uffff"+
            "\5\2\2\uffff\6\2\4\uffff\2\2\2\uffff\1\2\2\uffff\1\2\1\uffff"+
            "\3\2\22\uffff\2\2\1\uffff\2\2\5\uffff\7\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA26_eot = DFA.unpackEncodedString(DFA26_eotS);
    static final short[] DFA26_eof = DFA.unpackEncodedString(DFA26_eofS);
    static final char[] DFA26_min = DFA.unpackEncodedStringToUnsignedChars(DFA26_minS);
    static final char[] DFA26_max = DFA.unpackEncodedStringToUnsignedChars(DFA26_maxS);
    static final short[] DFA26_accept = DFA.unpackEncodedString(DFA26_acceptS);
    static final short[] DFA26_special = DFA.unpackEncodedString(DFA26_specialS);
    static final short[][] DFA26_transition;

    static {
        int numStates = DFA26_transitionS.length;
        DFA26_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA26_transition[i] = DFA.unpackEncodedString(DFA26_transitionS[i]);
        }
    }

    class DFA26 extends DFA {

        public DFA26(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 26;
            this.eot = DFA26_eot;
            this.eof = DFA26_eof;
            this.min = DFA26_min;
            this.max = DFA26_max;
            this.accept = DFA26_accept;
            this.special = DFA26_special;
            this.transition = DFA26_transition;
        }
        public String getDescription() {
            return "228:35: ( ';' | statement )";
        }
    }
    static final String DFA32_eotS =
        "\31\uffff";
    static final String DFA32_eofS =
        "\31\uffff";
    static final String DFA32_minS =
        "\1\6\30\uffff";
    static final String DFA32_maxS =
        "\1\146\30\uffff";
    static final String DFA32_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\17\uffff";
    static final String DFA32_specialS =
        "\31\uffff}>";
    static final String[] DFA32_transitionS = {
            "\1\11\12\uffff\1\11\1\uffff\1\11\2\uffff\1\11\1\uffff\1\11\1"+
            "\uffff\1\11\3\uffff\1\11\1\uffff\2\11\1\1\1\2\13\uffff\1\5\1"+
            "\6\1\7\1\3\1\4\43\uffff\1\11\1\uffff\1\11\1\10\5\uffff\7\11",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA32_eot = DFA.unpackEncodedString(DFA32_eotS);
    static final short[] DFA32_eof = DFA.unpackEncodedString(DFA32_eofS);
    static final char[] DFA32_min = DFA.unpackEncodedStringToUnsignedChars(DFA32_minS);
    static final char[] DFA32_max = DFA.unpackEncodedStringToUnsignedChars(DFA32_maxS);
    static final short[] DFA32_accept = DFA.unpackEncodedString(DFA32_acceptS);
    static final short[] DFA32_special = DFA.unpackEncodedString(DFA32_specialS);
    static final short[][] DFA32_transition;

    static {
        int numStates = DFA32_transitionS.length;
        DFA32_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA32_transition[i] = DFA.unpackEncodedString(DFA32_transitionS[i]);
        }
    }

    class DFA32 extends DFA {

        public DFA32(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 32;
            this.eot = DFA32_eot;
            this.eof = DFA32_eof;
            this.min = DFA32_min;
            this.max = DFA32_max;
            this.accept = DFA32_accept;
            this.special = DFA32_special;
            this.transition = DFA32_transition;
        }
        public String getDescription() {
            return "233:1: simpleStatement : ( ECHO commaList | PRINT commaList | GLOBAL name ( ',' name )* | STATIC variable EQUALS atom | BREAK ( Integer )? | CONTINUE ( Integer )? | RETURN ( expression )? | RequireOperator expression | expression );";
        }
    }
    static final String DFA31_eotS =
        "\24\uffff";
    static final String DFA31_eofS =
        "\1\21\23\uffff";
    static final String DFA31_minS =
        "\1\4\23\uffff";
    static final String DFA31_maxS =
        "\1\146\23\uffff";
    static final String DFA31_acceptS =
        "\1\uffff\1\1\17\uffff\1\2\2\uffff";
    static final String DFA31_specialS =
        "\24\uffff}>";
    static final String[] DFA31_transitionS = {
            "\1\21\1\uffff\1\1\12\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\1\1\3\uffff\1\1\1\uffff\2\1\64\uffff\1\21\1\1\1"+
            "\uffff\1\1\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA31_eot = DFA.unpackEncodedString(DFA31_eotS);
    static final short[] DFA31_eof = DFA.unpackEncodedString(DFA31_eofS);
    static final char[] DFA31_min = DFA.unpackEncodedStringToUnsignedChars(DFA31_minS);
    static final char[] DFA31_max = DFA.unpackEncodedStringToUnsignedChars(DFA31_maxS);
    static final short[] DFA31_accept = DFA.unpackEncodedString(DFA31_acceptS);
    static final short[] DFA31_special = DFA.unpackEncodedString(DFA31_specialS);
    static final short[][] DFA31_transition;

    static {
        int numStates = DFA31_transitionS.length;
        DFA31_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA31_transition[i] = DFA.unpackEncodedString(DFA31_transitionS[i]);
        }
    }

    class DFA31 extends DFA {

        public DFA31(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 31;
            this.eot = DFA31_eot;
            this.eof = DFA31_eof;
            this.min = DFA31_min;
            this.max = DFA31_max;
            this.accept = DFA31_accept;
            this.special = DFA31_special;
            this.transition = DFA31_transition;
        }
        public String getDescription() {
            return "242:15: ( expression )?";
        }
    }
    static final String DFA33_eotS =
        "\132\uffff";
    static final String DFA33_eofS =
        "\1\3\131\uffff";
    static final String DFA33_minS =
        "\1\6\2\0\127\uffff";
    static final String DFA33_maxS =
        "\1\146\2\0\127\uffff";
    static final String DFA33_acceptS =
        "\3\uffff\1\2\55\uffff\1\1\50\uffff";
    static final String DFA33_specialS =
        "\1\uffff\1\0\1\1\127\uffff}>";
    static final String[] DFA33_transitionS = {
            "\1\3\3\uffff\2\3\5\uffff\1\3\1\uffff\1\3\2\uffff\1\3\1\uffff"+
            "\1\3\1\uffff\1\3\3\uffff\1\3\1\uffff\5\3\1\2\1\1\15\3\4\uffff"+
            "\2\3\2\uffff\1\3\2\uffff\5\3\22\uffff\2\3\1\uffff\2\3\5\uffff"+
            "\7\3",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA33_eot = DFA.unpackEncodedString(DFA33_eotS);
    static final short[] DFA33_eof = DFA.unpackEncodedString(DFA33_eofS);
    static final char[] DFA33_min = DFA.unpackEncodedStringToUnsignedChars(DFA33_minS);
    static final char[] DFA33_max = DFA.unpackEncodedStringToUnsignedChars(DFA33_maxS);
    static final short[] DFA33_accept = DFA.unpackEncodedString(DFA33_acceptS);
    static final short[] DFA33_special = DFA.unpackEncodedString(DFA33_specialS);
    static final short[][] DFA33_transition;

    static {
        int numStates = DFA33_transitionS.length;
        DFA33_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA33_transition[i] = DFA.unpackEncodedString(DFA33_transitionS[i]);
        }
    }

    class DFA33 extends DFA {

        public DFA33(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 33;
            this.eot = DFA33_eot;
            this.eof = DFA33_eof;
            this.min = DFA33_min;
            this.max = DFA33_max;
            this.accept = DFA33_accept;
            this.special = DFA33_special;
            this.transition = DFA33_transition;
        }
        public String getDescription() {
            return "249:63: ( conditional )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA33_1 = input.LA(1);

                         
                        int index33_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred59_Php()) ) {s = 49;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index33_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA33_2 = input.LA(1);

                         
                        int index33_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred59_Php()) ) {s = 49;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index33_2);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 33, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA35_eotS =
        "\22\uffff";
    static final String DFA35_eofS =
        "\22\uffff";
    static final String DFA35_minS =
        "\1\4\21\uffff";
    static final String DFA35_maxS =
        "\1\146\21\uffff";
    static final String DFA35_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA35_specialS =
        "\22\uffff}>";
    static final String[] DFA35_transitionS = {
            "\1\21\1\uffff\1\1\12\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff"+
            "\1\1\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA35_eot = DFA.unpackEncodedString(DFA35_eotS);
    static final short[] DFA35_eof = DFA.unpackEncodedString(DFA35_eofS);
    static final char[] DFA35_min = DFA.unpackEncodedStringToUnsignedChars(DFA35_minS);
    static final char[] DFA35_max = DFA.unpackEncodedStringToUnsignedChars(DFA35_maxS);
    static final short[] DFA35_accept = DFA.unpackEncodedString(DFA35_acceptS);
    static final short[] DFA35_special = DFA.unpackEncodedString(DFA35_specialS);
    static final short[][] DFA35_transition;

    static {
        int numStates = DFA35_transitionS.length;
        DFA35_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA35_transition[i] = DFA.unpackEncodedString(DFA35_transitionS[i]);
        }
    }

    class DFA35 extends DFA {

        public DFA35(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 35;
            this.eot = DFA35_eot;
            this.eof = DFA35_eof;
            this.min = DFA35_min;
            this.max = DFA35_max;
            this.accept = DFA35_accept;
            this.special = DFA35_special;
            this.transition = DFA35_transition;
        }
        public String getDescription() {
            return "254:7: ( commaList )?";
        }
    }
    static final String DFA36_eotS =
        "\22\uffff";
    static final String DFA36_eofS =
        "\22\uffff";
    static final String DFA36_minS =
        "\1\4\21\uffff";
    static final String DFA36_maxS =
        "\1\146\21\uffff";
    static final String DFA36_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA36_specialS =
        "\22\uffff}>";
    static final String[] DFA36_transitionS = {
            "\1\21\1\uffff\1\1\12\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff"+
            "\1\1\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA36_eot = DFA.unpackEncodedString(DFA36_eotS);
    static final short[] DFA36_eof = DFA.unpackEncodedString(DFA36_eofS);
    static final char[] DFA36_min = DFA.unpackEncodedStringToUnsignedChars(DFA36_minS);
    static final char[] DFA36_max = DFA.unpackEncodedStringToUnsignedChars(DFA36_maxS);
    static final short[] DFA36_accept = DFA.unpackEncodedString(DFA36_acceptS);
    static final short[] DFA36_special = DFA.unpackEncodedString(DFA36_specialS);
    static final short[][] DFA36_transition;

    static {
        int numStates = DFA36_transitionS.length;
        DFA36_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA36_transition[i] = DFA.unpackEncodedString(DFA36_transitionS[i]);
        }
    }

    class DFA36 extends DFA {

        public DFA36(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 36;
            this.eot = DFA36_eot;
            this.eof = DFA36_eof;
            this.min = DFA36_min;
            this.max = DFA36_max;
            this.accept = DFA36_accept;
            this.special = DFA36_special;
            this.transition = DFA36_transition;
        }
        public String getDescription() {
            return "258:7: ( commaList )?";
        }
    }
    static final String DFA37_eotS =
        "\22\uffff";
    static final String DFA37_eofS =
        "\22\uffff";
    static final String DFA37_minS =
        "\1\6\21\uffff";
    static final String DFA37_maxS =
        "\1\146\21\uffff";
    static final String DFA37_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA37_specialS =
        "\22\uffff}>";
    static final String[] DFA37_transitionS = {
            "\1\1\1\21\11\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1"+
            "\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff\1\1"+
            "\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA37_eot = DFA.unpackEncodedString(DFA37_eotS);
    static final short[] DFA37_eof = DFA.unpackEncodedString(DFA37_eofS);
    static final char[] DFA37_min = DFA.unpackEncodedStringToUnsignedChars(DFA37_minS);
    static final char[] DFA37_max = DFA.unpackEncodedStringToUnsignedChars(DFA37_maxS);
    static final short[] DFA37_accept = DFA.unpackEncodedString(DFA37_acceptS);
    static final short[] DFA37_special = DFA.unpackEncodedString(DFA37_specialS);
    static final short[][] DFA37_transition;

    static {
        int numStates = DFA37_transitionS.length;
        DFA37_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA37_transition[i] = DFA.unpackEncodedString(DFA37_transitionS[i]);
        }
    }

    class DFA37 extends DFA {

        public DFA37(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 37;
            this.eot = DFA37_eot;
            this.eof = DFA37_eof;
            this.min = DFA37_min;
            this.max = DFA37_max;
            this.accept = DFA37_accept;
            this.special = DFA37_special;
            this.transition = DFA37_transition;
        }
        public String getDescription() {
            return "262:7: ( commaList )?";
        }
    }
    static final String DFA39_eotS =
        "\54\uffff";
    static final String DFA39_eofS =
        "\1\1\53\uffff";
    static final String DFA39_minS =
        "\1\6\53\uffff";
    static final String DFA39_maxS =
        "\1\146\53\uffff";
    static final String DFA39_acceptS =
        "\1\uffff\1\2\2\uffff\1\1\47\uffff";
    static final String DFA39_specialS =
        "\54\uffff}>";
    static final String[] DFA39_transitionS = {
            "\1\4\3\uffff\1\4\6\uffff\1\4\1\uffff\1\4\2\uffff\1\4\1\uffff"+
            "\1\4\1\uffff\1\4\3\uffff\1\4\1\uffff\5\4\2\uffff\5\4\2\1\6\4"+
            "\4\uffff\2\4\2\uffff\1\4\2\uffff\1\4\1\uffff\3\4\22\uffff\2"+
            "\4\1\uffff\2\4\5\uffff\7\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA39_eot = DFA.unpackEncodedString(DFA39_eotS);
    static final short[] DFA39_eof = DFA.unpackEncodedString(DFA39_eofS);
    static final char[] DFA39_min = DFA.unpackEncodedStringToUnsignedChars(DFA39_minS);
    static final char[] DFA39_max = DFA.unpackEncodedStringToUnsignedChars(DFA39_maxS);
    static final short[] DFA39_accept = DFA.unpackEncodedString(DFA39_acceptS);
    static final short[] DFA39_special = DFA.unpackEncodedString(DFA39_specialS);
    static final short[][] DFA39_transition;

    static {
        int numStates = DFA39_transitionS.length;
        DFA39_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA39_transition[i] = DFA.unpackEncodedString(DFA39_transitionS[i]);
        }
    }

    class DFA39 extends DFA {

        public DFA39(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 39;
            this.eot = DFA39_eot;
            this.eof = DFA39_eof;
            this.min = DFA39_min;
            this.max = DFA39_max;
            this.accept = DFA39_accept;
            this.special = DFA39_special;
            this.transition = DFA39_transition;
        }
        public String getDescription() {
            return "()* loopback of 270:29: ( statement )*";
        }
    }
    static final String DFA40_eotS =
        "\52\uffff";
    static final String DFA40_eofS =
        "\52\uffff";
    static final String DFA40_minS =
        "\1\6\51\uffff";
    static final String DFA40_maxS =
        "\1\146\51\uffff";
    static final String DFA40_acceptS =
        "\1\uffff\1\2\1\1\47\uffff";
    static final String DFA40_specialS =
        "\52\uffff}>";
    static final String[] DFA40_transitionS = {
            "\1\2\3\uffff\1\2\1\1\5\uffff\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff"+
            "\1\2\1\uffff\1\2\3\uffff\1\2\1\uffff\5\2\2\uffff\5\2\2\uffff"+
            "\6\2\4\uffff\2\2\2\uffff\1\2\2\uffff\1\2\1\uffff\3\2\22\uffff"+
            "\2\2\1\uffff\2\2\5\uffff\7\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA40_eot = DFA.unpackEncodedString(DFA40_eotS);
    static final short[] DFA40_eof = DFA.unpackEncodedString(DFA40_eofS);
    static final char[] DFA40_min = DFA.unpackEncodedStringToUnsignedChars(DFA40_minS);
    static final char[] DFA40_max = DFA.unpackEncodedStringToUnsignedChars(DFA40_maxS);
    static final short[] DFA40_accept = DFA.unpackEncodedString(DFA40_acceptS);
    static final short[] DFA40_special = DFA.unpackEncodedString(DFA40_specialS);
    static final short[][] DFA40_transition;

    static {
        int numStates = DFA40_transitionS.length;
        DFA40_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA40_transition[i] = DFA.unpackEncodedString(DFA40_transitionS[i]);
        }
    }

    class DFA40 extends DFA {

        public DFA40(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 40;
            this.eot = DFA40_eot;
            this.eof = DFA40_eof;
            this.min = DFA40_min;
            this.max = DFA40_max;
            this.accept = DFA40_accept;
            this.special = DFA40_special;
            this.transition = DFA40_transition;
        }
        public String getDescription() {
            return "()* loopback of 274:22: ( statement )*";
        }
    }
    static final String DFA41_eotS =
        "\62\uffff";
    static final String DFA41_eofS =
        "\1\2\61\uffff";
    static final String DFA41_minS =
        "\1\6\1\0\60\uffff";
    static final String DFA41_maxS =
        "\1\146\1\0\60\uffff";
    static final String DFA41_acceptS =
        "\2\uffff\1\2\56\uffff\1\1";
    static final String DFA41_specialS =
        "\1\uffff\1\0\60\uffff}>";
    static final String[] DFA41_transitionS = {
            "\1\2\3\uffff\2\2\5\uffff\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff"+
            "\1\2\1\uffff\1\2\3\uffff\1\2\1\uffff\24\2\4\uffff\2\2\2\uffff"+
            "\1\2\2\uffff\1\2\1\1\3\2\22\uffff\2\2\1\uffff\2\2\5\uffff\7"+
            "\2",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA41_eot = DFA.unpackEncodedString(DFA41_eotS);
    static final short[] DFA41_eof = DFA.unpackEncodedString(DFA41_eofS);
    static final char[] DFA41_min = DFA.unpackEncodedStringToUnsignedChars(DFA41_minS);
    static final char[] DFA41_max = DFA.unpackEncodedStringToUnsignedChars(DFA41_maxS);
    static final short[] DFA41_accept = DFA.unpackEncodedString(DFA41_acceptS);
    static final short[] DFA41_special = DFA.unpackEncodedString(DFA41_specialS);
    static final short[][] DFA41_transition;

    static {
        int numStates = DFA41_transitionS.length;
        DFA41_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA41_transition[i] = DFA.unpackEncodedString(DFA41_transitionS[i]);
        }
    }

    class DFA41 extends DFA {

        public DFA41(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 41;
            this.eot = DFA41_eot;
            this.eof = DFA41_eof;
            this.min = DFA41_min;
            this.max = DFA41_max;
            this.accept = DFA41_accept;
            this.special = DFA41_special;
            this.transition = DFA41_transition;
        }
        public String getDescription() {
            return "278:46: ( catchStatement )?";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA41_1 = input.LA(1);

                         
                        int index41_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred67_Php()) ) {s = 49;}

                        else if ( (true) ) {s = 2;}

                         
                        input.seek(index41_1);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 41, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA49_eotS =
        "\35\uffff";
    static final String DFA49_eofS =
        "\1\1\34\uffff";
    static final String DFA49_minS =
        "\1\4\10\uffff\1\0\23\uffff";
    static final String DFA49_maxS =
        "\1\126\10\uffff\1\0\23\uffff";
    static final String DFA49_acceptS =
        "\1\uffff\1\2\32\uffff\1\1";
    static final String DFA49_specialS =
        "\11\uffff\1\0\23\uffff}>";
    static final String[] DFA49_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\1\1\7\uffff\1\1\37\uffff"+
            "\1\1\1\11\1\1\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA49_eot = DFA.unpackEncodedString(DFA49_eotS);
    static final short[] DFA49_eof = DFA.unpackEncodedString(DFA49_eofS);
    static final char[] DFA49_min = DFA.unpackEncodedStringToUnsignedChars(DFA49_minS);
    static final char[] DFA49_max = DFA.unpackEncodedStringToUnsignedChars(DFA49_maxS);
    static final short[] DFA49_accept = DFA.unpackEncodedString(DFA49_acceptS);
    static final short[] DFA49_special = DFA.unpackEncodedString(DFA49_specialS);
    static final short[][] DFA49_transition;

    static {
        int numStates = DFA49_transitionS.length;
        DFA49_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA49_transition[i] = DFA.unpackEncodedString(DFA49_transitionS[i]);
        }
    }

    class DFA49 extends DFA {

        public DFA49(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 49;
            this.eot = DFA49_eot;
            this.eof = DFA49_eof;
            this.min = DFA49_min;
            this.max = DFA49_max;
            this.accept = DFA49_accept;
            this.special = DFA49_special;
            this.transition = DFA49_transition;
        }
        public String getDescription() {
            return "()* loopback of 326:22: ( OR weakLogicalXor )*";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA49_9 = input.LA(1);

                         
                        int index49_9 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred75_Php()) ) {s = 28;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index49_9);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 49, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA50_eotS =
        "\35\uffff";
    static final String DFA50_eofS =
        "\1\1\34\uffff";
    static final String DFA50_minS =
        "\1\4\10\uffff\1\0\23\uffff";
    static final String DFA50_maxS =
        "\1\126\10\uffff\1\0\23\uffff";
    static final String DFA50_acceptS =
        "\1\uffff\1\2\32\uffff\1\1";
    static final String DFA50_specialS =
        "\11\uffff\1\0\23\uffff}>";
    static final String[] DFA50_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\1\1\7\uffff\1\1\37\uffff"+
            "\2\1\1\11\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA50_eot = DFA.unpackEncodedString(DFA50_eotS);
    static final short[] DFA50_eof = DFA.unpackEncodedString(DFA50_eofS);
    static final char[] DFA50_min = DFA.unpackEncodedStringToUnsignedChars(DFA50_minS);
    static final char[] DFA50_max = DFA.unpackEncodedStringToUnsignedChars(DFA50_maxS);
    static final short[] DFA50_accept = DFA.unpackEncodedString(DFA50_acceptS);
    static final short[] DFA50_special = DFA.unpackEncodedString(DFA50_specialS);
    static final short[][] DFA50_transition;

    static {
        int numStates = DFA50_transitionS.length;
        DFA50_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA50_transition[i] = DFA.unpackEncodedString(DFA50_transitionS[i]);
        }
    }

    class DFA50 extends DFA {

        public DFA50(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 50;
            this.eot = DFA50_eot;
            this.eof = DFA50_eof;
            this.min = DFA50_min;
            this.max = DFA50_max;
            this.accept = DFA50_accept;
            this.special = DFA50_special;
            this.transition = DFA50_transition;
        }
        public String getDescription() {
            return "()* loopback of 330:22: ( XOR weakLogicalAnd )*";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA50_9 = input.LA(1);

                         
                        int index50_9 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred76_Php()) ) {s = 28;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index50_9);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 50, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA51_eotS =
        "\35\uffff";
    static final String DFA51_eofS =
        "\1\1\34\uffff";
    static final String DFA51_minS =
        "\1\4\10\uffff\1\0\23\uffff";
    static final String DFA51_maxS =
        "\1\126\10\uffff\1\0\23\uffff";
    static final String DFA51_acceptS =
        "\1\uffff\1\2\32\uffff\1\1";
    static final String DFA51_specialS =
        "\11\uffff\1\0\23\uffff}>";
    static final String[] DFA51_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\1\1\7\uffff\1\1\37\uffff"+
            "\1\11\2\1\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA51_eot = DFA.unpackEncodedString(DFA51_eotS);
    static final short[] DFA51_eof = DFA.unpackEncodedString(DFA51_eofS);
    static final char[] DFA51_min = DFA.unpackEncodedStringToUnsignedChars(DFA51_minS);
    static final char[] DFA51_max = DFA.unpackEncodedStringToUnsignedChars(DFA51_maxS);
    static final short[] DFA51_accept = DFA.unpackEncodedString(DFA51_acceptS);
    static final short[] DFA51_special = DFA.unpackEncodedString(DFA51_specialS);
    static final short[][] DFA51_transition;

    static {
        int numStates = DFA51_transitionS.length;
        DFA51_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA51_transition[i] = DFA.unpackEncodedString(DFA51_transitionS[i]);
        }
    }

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = DFA51_eot;
            this.eof = DFA51_eof;
            this.min = DFA51_min;
            this.max = DFA51_max;
            this.accept = DFA51_accept;
            this.special = DFA51_special;
            this.transition = DFA51_transition;
        }
        public String getDescription() {
            return "()* loopback of 334:18: ( AND assignment )*";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA51_9 = input.LA(1);

                         
                        int index51_9 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred77_Php()) ) {s = 28;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index51_9);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 51, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA52_eotS =
        "\57\uffff";
    static final String DFA52_eofS =
        "\1\uffff\1\3\55\uffff";
    static final String DFA52_minS =
        "\1\6\1\4\1\23\16\uffff\1\0\1\uffff\2\0\30\uffff\2\0";
    static final String DFA52_maxS =
        "\1\146\1\140\1\127\16\uffff\1\0\1\uffff\2\0\30\uffff\2\0";
    static final String DFA52_acceptS =
        "\3\uffff\1\2\21\uffff\1\1\31\uffff";
    static final String DFA52_specialS =
        "\21\uffff\1\0\1\uffff\1\1\1\2\30\uffff\1\3\1\4}>";
    static final String[] DFA52_transitionS = {
            "\1\3\12\uffff\1\3\1\uffff\1\2\2\uffff\1\3\1\uffff\1\3\1\uffff"+
            "\1\3\3\uffff\1\3\1\uffff\2\3\65\uffff\1\1\1\uffff\1\3\6\uffff"+
            "\7\3",
            "\4\3\1\23\1\3\2\uffff\3\3\1\21\1\24\1\uffff\1\3\1\uffff\4\3"+
            "\1\uffff\5\3\1\uffff\1\25\24\uffff\4\3\36\uffff\1\3\4\uffff"+
            "\1\25\3\3\1\uffff\1\3",
            "\1\55\103\uffff\1\56",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff"
    };

    static final short[] DFA52_eot = DFA.unpackEncodedString(DFA52_eotS);
    static final short[] DFA52_eof = DFA.unpackEncodedString(DFA52_eofS);
    static final char[] DFA52_min = DFA.unpackEncodedStringToUnsignedChars(DFA52_minS);
    static final char[] DFA52_max = DFA.unpackEncodedStringToUnsignedChars(DFA52_maxS);
    static final short[] DFA52_accept = DFA.unpackEncodedString(DFA52_acceptS);
    static final short[] DFA52_special = DFA.unpackEncodedString(DFA52_specialS);
    static final short[][] DFA52_transition;

    static {
        int numStates = DFA52_transitionS.length;
        DFA52_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA52_transition[i] = DFA.unpackEncodedString(DFA52_transitionS[i]);
        }
    }

    class DFA52 extends DFA {

        public DFA52(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 52;
            this.eot = DFA52_eot;
            this.eof = DFA52_eof;
            this.min = DFA52_min;
            this.max = DFA52_max;
            this.accept = DFA52_accept;
            this.special = DFA52_special;
            this.transition = DFA52_transition;
        }
        public String getDescription() {
            return "337:1: assignment : ( name ( ( EQUALS | AsignmentOperator ) assignment ) | ternary );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA52_17 = input.LA(1);

                         
                        int index52_17 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred79_Php()) ) {s = 21;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index52_17);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA52_19 = input.LA(1);

                         
                        int index52_19 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred79_Php()) ) {s = 21;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index52_19);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA52_20 = input.LA(1);

                         
                        int index52_20 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred79_Php()) ) {s = 21;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index52_20);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA52_45 = input.LA(1);

                         
                        int index52_45 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred79_Php()) ) {s = 21;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index52_45);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA52_46 = input.LA(1);

                         
                        int index52_46 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred79_Php()) ) {s = 21;}

                        else if ( (true) ) {s = 3;}

                         
                        input.seek(index52_46);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 52, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA53_eotS =
        "\u00e9\uffff";
    static final String DFA53_eofS =
        "\5\uffff\1\116\3\uffff\6\116\u00da\uffff";
    static final String DFA53_minS =
        "\2\6\1\23\1\6\1\23\1\4\3\23\6\4\1\6\1\23\75\0\13\uffff\2\0\1\uffff"+
        "\20\0\14\uffff\12\0\14\uffff\12\0\14\uffff\12\0\14\uffff\12\0\14"+
        "\uffff\12\0\14\uffff\3\0";
    static final String DFA53_maxS =
        "\4\146\1\127\1\140\3\127\6\136\1\6\1\127\75\0\13\uffff\2\0\1\uffff"+
        "\20\0\14\uffff\12\0\14\uffff\12\0\14\uffff\12\0\14\uffff\12\0\14"+
        "\uffff\12\0\14\uffff\3\0";
    static final String DFA53_acceptS =
        "\116\uffff\1\2\14\uffff\1\1\u008d\uffff";
    static final String DFA53_specialS =
        "\21\uffff\1\0\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1"+
        "\14\1\15\1\16\1\17\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\27\1\30"+
        "\1\31\1\32\1\33\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43\1\44\1\45"+
        "\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56\1\57\1\60\1\61\1\62"+
        "\1\63\1\64\1\65\1\66\1\67\1\70\1\71\1\72\1\73\1\74\13\uffff\1\75"+
        "\1\76\1\uffff\1\77\1\100\1\101\1\102\1\103\1\104\1\105\1\106\1\107"+
        "\1\110\1\111\1\112\1\113\1\114\1\115\1\116\14\uffff\1\117\1\120"+
        "\1\121\1\122\1\123\1\124\1\125\1\126\1\127\1\130\14\uffff\1\131"+
        "\1\132\1\133\1\134\1\135\1\136\1\137\1\140\1\141\1\142\14\uffff"+
        "\1\143\1\144\1\145\1\146\1\147\1\150\1\151\1\152\1\153\1\154\14"+
        "\uffff\1\155\1\156\1\157\1\160\1\161\1\162\1\163\1\164\1\165\1\166"+
        "\14\uffff\1\167\1\170\1\171\1\172\1\173\1\174\1\175\1\176\1\177"+
        "\1\u0080\14\uffff\1\u0081\1\u0082\1\u0083}>";
    static final String[] DFA53_transitionS = {
            "\1\3\12\uffff\1\2\1\uffff\1\6\2\uffff\1\20\1\uffff\1\1\1\uffff"+
            "\1\2\3\uffff\1\2\1\uffff\1\7\1\10\65\uffff\1\5\1\uffff\1\14"+
            "\6\uffff\1\4\1\17\1\11\1\12\1\13\1\15\1\16",
            "\1\23\12\uffff\1\22\1\uffff\1\26\2\uffff\1\40\1\uffff\1\21"+
            "\1\uffff\1\22\3\uffff\1\22\1\uffff\1\27\1\30\65\uffff\1\25\1"+
            "\uffff\1\34\6\uffff\1\24\1\37\1\31\1\32\1\33\1\35\1\36",
            "\1\43\2\uffff\1\55\11\uffff\1\44\1\45\65\uffff\1\42\1\uffff"+
            "\1\51\6\uffff\1\41\1\54\1\46\1\47\1\50\1\52\1\53",
            "\1\63\12\uffff\1\62\1\uffff\1\60\2\uffff\1\76\1\uffff\1\61"+
            "\1\uffff\1\62\3\uffff\1\62\1\uffff\1\65\1\66\65\uffff\1\57\1"+
            "\uffff\1\72\5\uffff\1\56\1\64\1\75\1\67\1\70\1\71\1\73\1\74",
            "\1\100\103\uffff\1\77",
            "\2\116\1\102\1\116\1\131\1\116\2\uffff\1\116\1\115\1\114\1"+
            "\101\1\132\1\uffff\1\133\1\uffff\1\116\1\106\1\112\1\113\1\uffff"+
            "\2\106\3\105\26\uffff\3\116\1\104\36\uffff\1\116\5\uffff\1\111"+
            "\1\110\1\107\1\uffff\1\103",
            "\1\134\103\uffff\1\135",
            "\1\137\103\uffff\1\136",
            "\1\141\103\uffff\1\140",
            "\2\116\1\uffff\1\116\1\uffff\1\116\2\uffff\1\116\1\153\1\152"+
            "\3\uffff\1\133\1\uffff\1\116\1\144\1\150\1\151\1\uffff\2\144"+
            "\3\143\26\uffff\3\116\1\142\36\uffff\1\116\5\uffff\1\147\1\146"+
            "\1\145",
            "\2\116\1\uffff\1\116\1\uffff\1\116\2\uffff\1\116\1\u0081\1"+
            "\u0080\3\uffff\1\133\1\uffff\1\116\1\172\1\176\1\177\1\uffff"+
            "\2\172\3\171\26\uffff\3\116\1\170\36\uffff\1\116\5\uffff\1\175"+
            "\1\174\1\173",
            "\2\116\1\uffff\1\116\1\uffff\1\116\2\uffff\1\116\1\u0097\1"+
            "\u0096\3\uffff\1\133\1\uffff\1\116\1\u0090\1\u0094\1\u0095\1"+
            "\uffff\2\u0090\3\u008f\26\uffff\3\116\1\u008e\36\uffff\1\116"+
            "\5\uffff\1\u0093\1\u0092\1\u0091",
            "\2\116\1\uffff\1\116\1\uffff\1\116\2\uffff\1\116\1\u00ad\1"+
            "\u00ac\3\uffff\1\133\1\uffff\1\116\1\u00a6\1\u00aa\1\u00ab\1"+
            "\uffff\2\u00a6\3\u00a5\26\uffff\3\116\1\u00a4\36\uffff\1\116"+
            "\5\uffff\1\u00a9\1\u00a8\1\u00a7",
            "\2\116\1\uffff\1\116\1\uffff\1\116\2\uffff\1\116\1\u00c3\1"+
            "\u00c2\3\uffff\1\133\1\uffff\1\116\1\u00bc\1\u00c0\1\u00c1\1"+
            "\uffff\2\u00bc\3\u00bb\26\uffff\3\116\1\u00ba\36\uffff\1\116"+
            "\5\uffff\1\u00bf\1\u00be\1\u00bd",
            "\2\116\1\uffff\1\116\1\uffff\1\116\2\uffff\1\116\1\u00d9\1"+
            "\u00d8\3\uffff\1\133\1\uffff\1\116\1\u00d2\1\u00d6\1\u00d7\1"+
            "\uffff\2\u00d2\3\u00d1\26\uffff\3\116\1\u00d0\36\uffff\1\116"+
            "\5\uffff\1\u00d5\1\u00d4\1\u00d3",
            "\1\u00e6",
            "\1\u00e8\103\uffff\1\u00e7",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff"
    };

    static final short[] DFA53_eot = DFA.unpackEncodedString(DFA53_eotS);
    static final short[] DFA53_eof = DFA.unpackEncodedString(DFA53_eofS);
    static final char[] DFA53_min = DFA.unpackEncodedStringToUnsignedChars(DFA53_minS);
    static final char[] DFA53_max = DFA.unpackEncodedStringToUnsignedChars(DFA53_maxS);
    static final short[] DFA53_accept = DFA.unpackEncodedString(DFA53_acceptS);
    static final short[] DFA53_special = DFA.unpackEncodedString(DFA53_specialS);
    static final short[][] DFA53_transition;

    static {
        int numStates = DFA53_transitionS.length;
        DFA53_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA53_transition[i] = DFA.unpackEncodedString(DFA53_transitionS[i]);
        }
    }

    class DFA53 extends DFA {

        public DFA53(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 53;
            this.eot = DFA53_eot;
            this.eof = DFA53_eof;
            this.min = DFA53_min;
            this.max = DFA53_max;
            this.accept = DFA53_accept;
            this.special = DFA53_special;
            this.transition = DFA53_transition;
        }
        public String getDescription() {
            return "342:1: ternary : ( logicalOr QUESTION_MARK expression COLON expression -> ^( IfExpression logicalOr ( expression )* ) | logicalOr );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA53_17 = input.LA(1);

                         
                        int index53_17 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_17);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA53_18 = input.LA(1);

                         
                        int index53_18 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_18);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA53_19 = input.LA(1);

                         
                        int index53_19 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_19);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA53_20 = input.LA(1);

                         
                        int index53_20 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_20);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA53_21 = input.LA(1);

                         
                        int index53_21 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_21);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA53_22 = input.LA(1);

                         
                        int index53_22 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_22);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA53_23 = input.LA(1);

                         
                        int index53_23 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_23);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA53_24 = input.LA(1);

                         
                        int index53_24 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_24);
                        if ( s>=0 ) return s;
                        break;
                    case 8 : 
                        int LA53_25 = input.LA(1);

                         
                        int index53_25 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_25);
                        if ( s>=0 ) return s;
                        break;
                    case 9 : 
                        int LA53_26 = input.LA(1);

                         
                        int index53_26 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_26);
                        if ( s>=0 ) return s;
                        break;
                    case 10 : 
                        int LA53_27 = input.LA(1);

                         
                        int index53_27 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_27);
                        if ( s>=0 ) return s;
                        break;
                    case 11 : 
                        int LA53_28 = input.LA(1);

                         
                        int index53_28 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_28);
                        if ( s>=0 ) return s;
                        break;
                    case 12 : 
                        int LA53_29 = input.LA(1);

                         
                        int index53_29 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_29);
                        if ( s>=0 ) return s;
                        break;
                    case 13 : 
                        int LA53_30 = input.LA(1);

                         
                        int index53_30 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_30);
                        if ( s>=0 ) return s;
                        break;
                    case 14 : 
                        int LA53_31 = input.LA(1);

                         
                        int index53_31 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_31);
                        if ( s>=0 ) return s;
                        break;
                    case 15 : 
                        int LA53_32 = input.LA(1);

                         
                        int index53_32 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_32);
                        if ( s>=0 ) return s;
                        break;
                    case 16 : 
                        int LA53_33 = input.LA(1);

                         
                        int index53_33 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_33);
                        if ( s>=0 ) return s;
                        break;
                    case 17 : 
                        int LA53_34 = input.LA(1);

                         
                        int index53_34 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_34);
                        if ( s>=0 ) return s;
                        break;
                    case 18 : 
                        int LA53_35 = input.LA(1);

                         
                        int index53_35 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_35);
                        if ( s>=0 ) return s;
                        break;
                    case 19 : 
                        int LA53_36 = input.LA(1);

                         
                        int index53_36 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_36);
                        if ( s>=0 ) return s;
                        break;
                    case 20 : 
                        int LA53_37 = input.LA(1);

                         
                        int index53_37 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_37);
                        if ( s>=0 ) return s;
                        break;
                    case 21 : 
                        int LA53_38 = input.LA(1);

                         
                        int index53_38 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_38);
                        if ( s>=0 ) return s;
                        break;
                    case 22 : 
                        int LA53_39 = input.LA(1);

                         
                        int index53_39 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_39);
                        if ( s>=0 ) return s;
                        break;
                    case 23 : 
                        int LA53_40 = input.LA(1);

                         
                        int index53_40 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_40);
                        if ( s>=0 ) return s;
                        break;
                    case 24 : 
                        int LA53_41 = input.LA(1);

                         
                        int index53_41 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_41);
                        if ( s>=0 ) return s;
                        break;
                    case 25 : 
                        int LA53_42 = input.LA(1);

                         
                        int index53_42 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_42);
                        if ( s>=0 ) return s;
                        break;
                    case 26 : 
                        int LA53_43 = input.LA(1);

                         
                        int index53_43 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_43);
                        if ( s>=0 ) return s;
                        break;
                    case 27 : 
                        int LA53_44 = input.LA(1);

                         
                        int index53_44 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_44);
                        if ( s>=0 ) return s;
                        break;
                    case 28 : 
                        int LA53_45 = input.LA(1);

                         
                        int index53_45 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_45);
                        if ( s>=0 ) return s;
                        break;
                    case 29 : 
                        int LA53_46 = input.LA(1);

                         
                        int index53_46 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_46);
                        if ( s>=0 ) return s;
                        break;
                    case 30 : 
                        int LA53_47 = input.LA(1);

                         
                        int index53_47 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_47);
                        if ( s>=0 ) return s;
                        break;
                    case 31 : 
                        int LA53_48 = input.LA(1);

                         
                        int index53_48 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_48);
                        if ( s>=0 ) return s;
                        break;
                    case 32 : 
                        int LA53_49 = input.LA(1);

                         
                        int index53_49 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_49);
                        if ( s>=0 ) return s;
                        break;
                    case 33 : 
                        int LA53_50 = input.LA(1);

                         
                        int index53_50 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_50);
                        if ( s>=0 ) return s;
                        break;
                    case 34 : 
                        int LA53_51 = input.LA(1);

                         
                        int index53_51 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_51);
                        if ( s>=0 ) return s;
                        break;
                    case 35 : 
                        int LA53_52 = input.LA(1);

                         
                        int index53_52 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_52);
                        if ( s>=0 ) return s;
                        break;
                    case 36 : 
                        int LA53_53 = input.LA(1);

                         
                        int index53_53 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_53);
                        if ( s>=0 ) return s;
                        break;
                    case 37 : 
                        int LA53_54 = input.LA(1);

                         
                        int index53_54 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_54);
                        if ( s>=0 ) return s;
                        break;
                    case 38 : 
                        int LA53_55 = input.LA(1);

                         
                        int index53_55 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_55);
                        if ( s>=0 ) return s;
                        break;
                    case 39 : 
                        int LA53_56 = input.LA(1);

                         
                        int index53_56 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_56);
                        if ( s>=0 ) return s;
                        break;
                    case 40 : 
                        int LA53_57 = input.LA(1);

                         
                        int index53_57 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_57);
                        if ( s>=0 ) return s;
                        break;
                    case 41 : 
                        int LA53_58 = input.LA(1);

                         
                        int index53_58 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_58);
                        if ( s>=0 ) return s;
                        break;
                    case 42 : 
                        int LA53_59 = input.LA(1);

                         
                        int index53_59 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_59);
                        if ( s>=0 ) return s;
                        break;
                    case 43 : 
                        int LA53_60 = input.LA(1);

                         
                        int index53_60 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_60);
                        if ( s>=0 ) return s;
                        break;
                    case 44 : 
                        int LA53_61 = input.LA(1);

                         
                        int index53_61 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_61);
                        if ( s>=0 ) return s;
                        break;
                    case 45 : 
                        int LA53_62 = input.LA(1);

                         
                        int index53_62 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_62);
                        if ( s>=0 ) return s;
                        break;
                    case 46 : 
                        int LA53_63 = input.LA(1);

                         
                        int index53_63 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_63);
                        if ( s>=0 ) return s;
                        break;
                    case 47 : 
                        int LA53_64 = input.LA(1);

                         
                        int index53_64 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_64);
                        if ( s>=0 ) return s;
                        break;
                    case 48 : 
                        int LA53_65 = input.LA(1);

                         
                        int index53_65 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_65);
                        if ( s>=0 ) return s;
                        break;
                    case 49 : 
                        int LA53_66 = input.LA(1);

                         
                        int index53_66 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_66);
                        if ( s>=0 ) return s;
                        break;
                    case 50 : 
                        int LA53_67 = input.LA(1);

                         
                        int index53_67 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_67);
                        if ( s>=0 ) return s;
                        break;
                    case 51 : 
                        int LA53_68 = input.LA(1);

                         
                        int index53_68 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_68);
                        if ( s>=0 ) return s;
                        break;
                    case 52 : 
                        int LA53_69 = input.LA(1);

                         
                        int index53_69 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_69);
                        if ( s>=0 ) return s;
                        break;
                    case 53 : 
                        int LA53_70 = input.LA(1);

                         
                        int index53_70 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_70);
                        if ( s>=0 ) return s;
                        break;
                    case 54 : 
                        int LA53_71 = input.LA(1);

                         
                        int index53_71 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_71);
                        if ( s>=0 ) return s;
                        break;
                    case 55 : 
                        int LA53_72 = input.LA(1);

                         
                        int index53_72 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_72);
                        if ( s>=0 ) return s;
                        break;
                    case 56 : 
                        int LA53_73 = input.LA(1);

                         
                        int index53_73 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_73);
                        if ( s>=0 ) return s;
                        break;
                    case 57 : 
                        int LA53_74 = input.LA(1);

                         
                        int index53_74 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_74);
                        if ( s>=0 ) return s;
                        break;
                    case 58 : 
                        int LA53_75 = input.LA(1);

                         
                        int index53_75 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_75);
                        if ( s>=0 ) return s;
                        break;
                    case 59 : 
                        int LA53_76 = input.LA(1);

                         
                        int index53_76 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_76);
                        if ( s>=0 ) return s;
                        break;
                    case 60 : 
                        int LA53_77 = input.LA(1);

                         
                        int index53_77 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_77);
                        if ( s>=0 ) return s;
                        break;
                    case 61 : 
                        int LA53_89 = input.LA(1);

                         
                        int index53_89 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_89);
                        if ( s>=0 ) return s;
                        break;
                    case 62 : 
                        int LA53_90 = input.LA(1);

                         
                        int index53_90 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_90);
                        if ( s>=0 ) return s;
                        break;
                    case 63 : 
                        int LA53_92 = input.LA(1);

                         
                        int index53_92 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_92);
                        if ( s>=0 ) return s;
                        break;
                    case 64 : 
                        int LA53_93 = input.LA(1);

                         
                        int index53_93 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_93);
                        if ( s>=0 ) return s;
                        break;
                    case 65 : 
                        int LA53_94 = input.LA(1);

                         
                        int index53_94 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_94);
                        if ( s>=0 ) return s;
                        break;
                    case 66 : 
                        int LA53_95 = input.LA(1);

                         
                        int index53_95 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_95);
                        if ( s>=0 ) return s;
                        break;
                    case 67 : 
                        int LA53_96 = input.LA(1);

                         
                        int index53_96 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_96);
                        if ( s>=0 ) return s;
                        break;
                    case 68 : 
                        int LA53_97 = input.LA(1);

                         
                        int index53_97 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_97);
                        if ( s>=0 ) return s;
                        break;
                    case 69 : 
                        int LA53_98 = input.LA(1);

                         
                        int index53_98 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_98);
                        if ( s>=0 ) return s;
                        break;
                    case 70 : 
                        int LA53_99 = input.LA(1);

                         
                        int index53_99 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_99);
                        if ( s>=0 ) return s;
                        break;
                    case 71 : 
                        int LA53_100 = input.LA(1);

                         
                        int index53_100 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_100);
                        if ( s>=0 ) return s;
                        break;
                    case 72 : 
                        int LA53_101 = input.LA(1);

                         
                        int index53_101 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_101);
                        if ( s>=0 ) return s;
                        break;
                    case 73 : 
                        int LA53_102 = input.LA(1);

                         
                        int index53_102 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_102);
                        if ( s>=0 ) return s;
                        break;
                    case 74 : 
                        int LA53_103 = input.LA(1);

                         
                        int index53_103 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_103);
                        if ( s>=0 ) return s;
                        break;
                    case 75 : 
                        int LA53_104 = input.LA(1);

                         
                        int index53_104 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_104);
                        if ( s>=0 ) return s;
                        break;
                    case 76 : 
                        int LA53_105 = input.LA(1);

                         
                        int index53_105 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_105);
                        if ( s>=0 ) return s;
                        break;
                    case 77 : 
                        int LA53_106 = input.LA(1);

                         
                        int index53_106 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_106);
                        if ( s>=0 ) return s;
                        break;
                    case 78 : 
                        int LA53_107 = input.LA(1);

                         
                        int index53_107 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_107);
                        if ( s>=0 ) return s;
                        break;
                    case 79 : 
                        int LA53_120 = input.LA(1);

                         
                        int index53_120 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_120);
                        if ( s>=0 ) return s;
                        break;
                    case 80 : 
                        int LA53_121 = input.LA(1);

                         
                        int index53_121 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_121);
                        if ( s>=0 ) return s;
                        break;
                    case 81 : 
                        int LA53_122 = input.LA(1);

                         
                        int index53_122 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_122);
                        if ( s>=0 ) return s;
                        break;
                    case 82 : 
                        int LA53_123 = input.LA(1);

                         
                        int index53_123 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_123);
                        if ( s>=0 ) return s;
                        break;
                    case 83 : 
                        int LA53_124 = input.LA(1);

                         
                        int index53_124 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_124);
                        if ( s>=0 ) return s;
                        break;
                    case 84 : 
                        int LA53_125 = input.LA(1);

                         
                        int index53_125 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_125);
                        if ( s>=0 ) return s;
                        break;
                    case 85 : 
                        int LA53_126 = input.LA(1);

                         
                        int index53_126 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_126);
                        if ( s>=0 ) return s;
                        break;
                    case 86 : 
                        int LA53_127 = input.LA(1);

                         
                        int index53_127 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_127);
                        if ( s>=0 ) return s;
                        break;
                    case 87 : 
                        int LA53_128 = input.LA(1);

                         
                        int index53_128 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_128);
                        if ( s>=0 ) return s;
                        break;
                    case 88 : 
                        int LA53_129 = input.LA(1);

                         
                        int index53_129 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_129);
                        if ( s>=0 ) return s;
                        break;
                    case 89 : 
                        int LA53_142 = input.LA(1);

                         
                        int index53_142 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_142);
                        if ( s>=0 ) return s;
                        break;
                    case 90 : 
                        int LA53_143 = input.LA(1);

                         
                        int index53_143 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_143);
                        if ( s>=0 ) return s;
                        break;
                    case 91 : 
                        int LA53_144 = input.LA(1);

                         
                        int index53_144 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_144);
                        if ( s>=0 ) return s;
                        break;
                    case 92 : 
                        int LA53_145 = input.LA(1);

                         
                        int index53_145 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_145);
                        if ( s>=0 ) return s;
                        break;
                    case 93 : 
                        int LA53_146 = input.LA(1);

                         
                        int index53_146 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_146);
                        if ( s>=0 ) return s;
                        break;
                    case 94 : 
                        int LA53_147 = input.LA(1);

                         
                        int index53_147 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_147);
                        if ( s>=0 ) return s;
                        break;
                    case 95 : 
                        int LA53_148 = input.LA(1);

                         
                        int index53_148 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_148);
                        if ( s>=0 ) return s;
                        break;
                    case 96 : 
                        int LA53_149 = input.LA(1);

                         
                        int index53_149 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_149);
                        if ( s>=0 ) return s;
                        break;
                    case 97 : 
                        int LA53_150 = input.LA(1);

                         
                        int index53_150 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_150);
                        if ( s>=0 ) return s;
                        break;
                    case 98 : 
                        int LA53_151 = input.LA(1);

                         
                        int index53_151 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_151);
                        if ( s>=0 ) return s;
                        break;
                    case 99 : 
                        int LA53_164 = input.LA(1);

                         
                        int index53_164 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_164);
                        if ( s>=0 ) return s;
                        break;
                    case 100 : 
                        int LA53_165 = input.LA(1);

                         
                        int index53_165 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_165);
                        if ( s>=0 ) return s;
                        break;
                    case 101 : 
                        int LA53_166 = input.LA(1);

                         
                        int index53_166 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_166);
                        if ( s>=0 ) return s;
                        break;
                    case 102 : 
                        int LA53_167 = input.LA(1);

                         
                        int index53_167 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_167);
                        if ( s>=0 ) return s;
                        break;
                    case 103 : 
                        int LA53_168 = input.LA(1);

                         
                        int index53_168 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_168);
                        if ( s>=0 ) return s;
                        break;
                    case 104 : 
                        int LA53_169 = input.LA(1);

                         
                        int index53_169 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_169);
                        if ( s>=0 ) return s;
                        break;
                    case 105 : 
                        int LA53_170 = input.LA(1);

                         
                        int index53_170 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_170);
                        if ( s>=0 ) return s;
                        break;
                    case 106 : 
                        int LA53_171 = input.LA(1);

                         
                        int index53_171 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_171);
                        if ( s>=0 ) return s;
                        break;
                    case 107 : 
                        int LA53_172 = input.LA(1);

                         
                        int index53_172 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_172);
                        if ( s>=0 ) return s;
                        break;
                    case 108 : 
                        int LA53_173 = input.LA(1);

                         
                        int index53_173 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_173);
                        if ( s>=0 ) return s;
                        break;
                    case 109 : 
                        int LA53_186 = input.LA(1);

                         
                        int index53_186 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_186);
                        if ( s>=0 ) return s;
                        break;
                    case 110 : 
                        int LA53_187 = input.LA(1);

                         
                        int index53_187 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_187);
                        if ( s>=0 ) return s;
                        break;
                    case 111 : 
                        int LA53_188 = input.LA(1);

                         
                        int index53_188 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_188);
                        if ( s>=0 ) return s;
                        break;
                    case 112 : 
                        int LA53_189 = input.LA(1);

                         
                        int index53_189 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_189);
                        if ( s>=0 ) return s;
                        break;
                    case 113 : 
                        int LA53_190 = input.LA(1);

                         
                        int index53_190 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_190);
                        if ( s>=0 ) return s;
                        break;
                    case 114 : 
                        int LA53_191 = input.LA(1);

                         
                        int index53_191 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_191);
                        if ( s>=0 ) return s;
                        break;
                    case 115 : 
                        int LA53_192 = input.LA(1);

                         
                        int index53_192 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_192);
                        if ( s>=0 ) return s;
                        break;
                    case 116 : 
                        int LA53_193 = input.LA(1);

                         
                        int index53_193 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_193);
                        if ( s>=0 ) return s;
                        break;
                    case 117 : 
                        int LA53_194 = input.LA(1);

                         
                        int index53_194 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_194);
                        if ( s>=0 ) return s;
                        break;
                    case 118 : 
                        int LA53_195 = input.LA(1);

                         
                        int index53_195 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_195);
                        if ( s>=0 ) return s;
                        break;
                    case 119 : 
                        int LA53_208 = input.LA(1);

                         
                        int index53_208 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_208);
                        if ( s>=0 ) return s;
                        break;
                    case 120 : 
                        int LA53_209 = input.LA(1);

                         
                        int index53_209 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_209);
                        if ( s>=0 ) return s;
                        break;
                    case 121 : 
                        int LA53_210 = input.LA(1);

                         
                        int index53_210 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_210);
                        if ( s>=0 ) return s;
                        break;
                    case 122 : 
                        int LA53_211 = input.LA(1);

                         
                        int index53_211 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_211);
                        if ( s>=0 ) return s;
                        break;
                    case 123 : 
                        int LA53_212 = input.LA(1);

                         
                        int index53_212 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_212);
                        if ( s>=0 ) return s;
                        break;
                    case 124 : 
                        int LA53_213 = input.LA(1);

                         
                        int index53_213 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_213);
                        if ( s>=0 ) return s;
                        break;
                    case 125 : 
                        int LA53_214 = input.LA(1);

                         
                        int index53_214 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_214);
                        if ( s>=0 ) return s;
                        break;
                    case 126 : 
                        int LA53_215 = input.LA(1);

                         
                        int index53_215 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_215);
                        if ( s>=0 ) return s;
                        break;
                    case 127 : 
                        int LA53_216 = input.LA(1);

                         
                        int index53_216 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_216);
                        if ( s>=0 ) return s;
                        break;
                    case 128 : 
                        int LA53_217 = input.LA(1);

                         
                        int index53_217 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_217);
                        if ( s>=0 ) return s;
                        break;
                    case 129 : 
                        int LA53_230 = input.LA(1);

                         
                        int index53_230 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_230);
                        if ( s>=0 ) return s;
                        break;
                    case 130 : 
                        int LA53_231 = input.LA(1);

                         
                        int index53_231 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_231);
                        if ( s>=0 ) return s;
                        break;
                    case 131 : 
                        int LA53_232 = input.LA(1);

                         
                        int index53_232 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred80_Php()) ) {s = 91;}

                        else if ( (true) ) {s = 78;}

                         
                        input.seek(index53_232);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 53, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA54_eotS =
        "\16\uffff";
    static final String DFA54_eofS =
        "\1\1\15\uffff";
    static final String DFA54_minS =
        "\1\4\15\uffff";
    static final String DFA54_maxS =
        "\1\126\15\uffff";
    static final String DFA54_acceptS =
        "\1\uffff\1\2\13\uffff\1\1";
    static final String DFA54_specialS =
        "\16\uffff}>";
    static final String[] DFA54_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\15\4\uffff\1\1\1"+
            "\uffff\1\1\37\uffff\3\1\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA54_eot = DFA.unpackEncodedString(DFA54_eotS);
    static final short[] DFA54_eof = DFA.unpackEncodedString(DFA54_eofS);
    static final char[] DFA54_min = DFA.unpackEncodedStringToUnsignedChars(DFA54_minS);
    static final char[] DFA54_max = DFA.unpackEncodedStringToUnsignedChars(DFA54_maxS);
    static final short[] DFA54_accept = DFA.unpackEncodedString(DFA54_acceptS);
    static final short[] DFA54_special = DFA.unpackEncodedString(DFA54_specialS);
    static final short[][] DFA54_transition;

    static {
        int numStates = DFA54_transitionS.length;
        DFA54_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA54_transition[i] = DFA.unpackEncodedString(DFA54_transitionS[i]);
        }
    }

    class DFA54 extends DFA {

        public DFA54(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 54;
            this.eot = DFA54_eot;
            this.eof = DFA54_eof;
            this.min = DFA54_min;
            this.max = DFA54_max;
            this.accept = DFA54_accept;
            this.special = DFA54_special;
            this.transition = DFA54_transition;
        }
        public String getDescription() {
            return "()* loopback of 348:18: ( LOGICAL_OR logicalAnd )*";
        }
    }
    static final String DFA55_eotS =
        "\17\uffff";
    static final String DFA55_eofS =
        "\1\1\16\uffff";
    static final String DFA55_minS =
        "\1\4\16\uffff";
    static final String DFA55_maxS =
        "\1\126\16\uffff";
    static final String DFA55_acceptS =
        "\1\uffff\1\2\14\uffff\1\1";
    static final String DFA55_specialS =
        "\17\uffff}>";
    static final String[] DFA55_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\2\1\1\16\3\uffff\1\1\1"+
            "\uffff\1\1\37\uffff\3\1\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA55_eot = DFA.unpackEncodedString(DFA55_eotS);
    static final short[] DFA55_eof = DFA.unpackEncodedString(DFA55_eofS);
    static final char[] DFA55_min = DFA.unpackEncodedStringToUnsignedChars(DFA55_minS);
    static final char[] DFA55_max = DFA.unpackEncodedStringToUnsignedChars(DFA55_maxS);
    static final short[] DFA55_accept = DFA.unpackEncodedString(DFA55_acceptS);
    static final short[] DFA55_special = DFA.unpackEncodedString(DFA55_specialS);
    static final short[][] DFA55_transition;

    static {
        int numStates = DFA55_transitionS.length;
        DFA55_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA55_transition[i] = DFA.unpackEncodedString(DFA55_transitionS[i]);
        }
    }

    class DFA55 extends DFA {

        public DFA55(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 55;
            this.eot = DFA55_eot;
            this.eof = DFA55_eof;
            this.min = DFA55_min;
            this.max = DFA55_max;
            this.accept = DFA55_accept;
            this.special = DFA55_special;
            this.transition = DFA55_transition;
        }
        public String getDescription() {
            return "()* loopback of 352:17: ( LOGICAL_AND bitwiseOr )*";
        }
    }
    static final String DFA56_eotS =
        "\20\uffff";
    static final String DFA56_eofS =
        "\1\1\17\uffff";
    static final String DFA56_minS =
        "\1\4\17\uffff";
    static final String DFA56_maxS =
        "\1\126\17\uffff";
    static final String DFA56_acceptS =
        "\1\uffff\1\2\15\uffff\1\1";
    static final String DFA56_specialS =
        "\20\uffff}>";
    static final String[] DFA56_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\3\1\3\uffff\1\1\1\uffff"+
            "\1\1\2\uffff\1\17\34\uffff\3\1\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA56_eot = DFA.unpackEncodedString(DFA56_eotS);
    static final short[] DFA56_eof = DFA.unpackEncodedString(DFA56_eofS);
    static final char[] DFA56_min = DFA.unpackEncodedStringToUnsignedChars(DFA56_minS);
    static final char[] DFA56_max = DFA.unpackEncodedStringToUnsignedChars(DFA56_maxS);
    static final short[] DFA56_accept = DFA.unpackEncodedString(DFA56_acceptS);
    static final short[] DFA56_special = DFA.unpackEncodedString(DFA56_specialS);
    static final short[][] DFA56_transition;

    static {
        int numStates = DFA56_transitionS.length;
        DFA56_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA56_transition[i] = DFA.unpackEncodedString(DFA56_transitionS[i]);
        }
    }

    class DFA56 extends DFA {

        public DFA56(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 56;
            this.eot = DFA56_eot;
            this.eof = DFA56_eof;
            this.min = DFA56_min;
            this.max = DFA56_max;
            this.accept = DFA56_accept;
            this.special = DFA56_special;
            this.transition = DFA56_transition;
        }
        public String getDescription() {
            return "()* loopback of 356:18: ( PIPE bitWiseAnd )*";
        }
    }
    static final String DFA57_eotS =
        "\21\uffff";
    static final String DFA57_eofS =
        "\1\1\20\uffff";
    static final String DFA57_minS =
        "\1\4\20\uffff";
    static final String DFA57_maxS =
        "\1\126\20\uffff";
    static final String DFA57_acceptS =
        "\1\uffff\1\2\16\uffff\1\1";
    static final String DFA57_specialS =
        "\21\uffff}>";
    static final String[] DFA57_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\3\1\3\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\1\20\1\1\34\uffff\3\1\37\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA57_eot = DFA.unpackEncodedString(DFA57_eotS);
    static final short[] DFA57_eof = DFA.unpackEncodedString(DFA57_eofS);
    static final char[] DFA57_min = DFA.unpackEncodedStringToUnsignedChars(DFA57_minS);
    static final char[] DFA57_max = DFA.unpackEncodedStringToUnsignedChars(DFA57_maxS);
    static final short[] DFA57_accept = DFA.unpackEncodedString(DFA57_acceptS);
    static final short[] DFA57_special = DFA.unpackEncodedString(DFA57_specialS);
    static final short[][] DFA57_transition;

    static {
        int numStates = DFA57_transitionS.length;
        DFA57_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA57_transition[i] = DFA.unpackEncodedString(DFA57_transitionS[i]);
        }
    }

    class DFA57 extends DFA {

        public DFA57(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 57;
            this.eot = DFA57_eot;
            this.eof = DFA57_eof;
            this.min = DFA57_min;
            this.max = DFA57_max;
            this.accept = DFA57_accept;
            this.special = DFA57_special;
            this.transition = DFA57_transition;
        }
        public String getDescription() {
            return "()* loopback of 360:21: ( AMPERSAND equalityCheck )*";
        }
    }
    static final String DFA58_eotS =
        "\22\uffff";
    static final String DFA58_eofS =
        "\1\2\21\uffff";
    static final String DFA58_minS =
        "\1\4\21\uffff";
    static final String DFA58_maxS =
        "\1\134\21\uffff";
    static final String DFA58_acceptS =
        "\1\uffff\1\1\1\2\17\uffff";
    static final String DFA58_specialS =
        "\22\uffff}>";
    static final String[] DFA58_transitionS = {
            "\2\2\1\uffff\1\2\1\uffff\1\2\2\uffff\3\2\3\uffff\1\2\1\uffff"+
            "\1\2\1\uffff\2\2\34\uffff\3\2\37\uffff\1\2\5\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA58_eot = DFA.unpackEncodedString(DFA58_eotS);
    static final short[] DFA58_eof = DFA.unpackEncodedString(DFA58_eofS);
    static final char[] DFA58_min = DFA.unpackEncodedStringToUnsignedChars(DFA58_minS);
    static final char[] DFA58_max = DFA.unpackEncodedStringToUnsignedChars(DFA58_maxS);
    static final short[] DFA58_accept = DFA.unpackEncodedString(DFA58_acceptS);
    static final short[] DFA58_special = DFA.unpackEncodedString(DFA58_specialS);
    static final short[][] DFA58_transition;

    static {
        int numStates = DFA58_transitionS.length;
        DFA58_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA58_transition[i] = DFA.unpackEncodedString(DFA58_transitionS[i]);
        }
    }

    class DFA58 extends DFA {

        public DFA58(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 58;
            this.eot = DFA58_eot;
            this.eof = DFA58_eof;
            this.min = DFA58_min;
            this.max = DFA58_max;
            this.accept = DFA58_accept;
            this.special = DFA58_special;
            this.transition = DFA58_transition;
        }
        public String getDescription() {
            return "364:24: ( EqualityOperator comparisionCheck )?";
        }
    }
    static final String DFA59_eotS =
        "\23\uffff";
    static final String DFA59_eofS =
        "\1\2\22\uffff";
    static final String DFA59_minS =
        "\1\4\22\uffff";
    static final String DFA59_maxS =
        "\1\135\22\uffff";
    static final String DFA59_acceptS =
        "\1\uffff\1\1\1\2\20\uffff";
    static final String DFA59_specialS =
        "\23\uffff}>";
    static final String[] DFA59_transitionS = {
            "\2\2\1\uffff\1\2\1\uffff\1\2\2\uffff\3\2\3\uffff\1\2\1\uffff"+
            "\1\2\1\uffff\2\2\34\uffff\3\2\37\uffff\1\2\5\uffff\1\2\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA59_eot = DFA.unpackEncodedString(DFA59_eotS);
    static final short[] DFA59_eof = DFA.unpackEncodedString(DFA59_eofS);
    static final char[] DFA59_min = DFA.unpackEncodedStringToUnsignedChars(DFA59_minS);
    static final char[] DFA59_max = DFA.unpackEncodedStringToUnsignedChars(DFA59_maxS);
    static final short[] DFA59_accept = DFA.unpackEncodedString(DFA59_acceptS);
    static final short[] DFA59_special = DFA.unpackEncodedString(DFA59_specialS);
    static final short[][] DFA59_transition;

    static {
        int numStates = DFA59_transitionS.length;
        DFA59_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA59_transition[i] = DFA.unpackEncodedString(DFA59_transitionS[i]);
        }
    }

    class DFA59 extends DFA {

        public DFA59(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 59;
            this.eot = DFA59_eot;
            this.eof = DFA59_eof;
            this.min = DFA59_min;
            this.max = DFA59_max;
            this.accept = DFA59_accept;
            this.special = DFA59_special;
            this.transition = DFA59_transition;
        }
        public String getDescription() {
            return "368:20: ( ComparisionOperator bitWiseShift )?";
        }
    }
    static final String DFA60_eotS =
        "\24\uffff";
    static final String DFA60_eofS =
        "\1\1\23\uffff";
    static final String DFA60_minS =
        "\1\4\23\uffff";
    static final String DFA60_maxS =
        "\1\136\23\uffff";
    static final String DFA60_acceptS =
        "\1\uffff\1\2\21\uffff\1\1";
    static final String DFA60_specialS =
        "\24\uffff}>";
    static final String[] DFA60_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\3\1\3\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\2\1\34\uffff\3\1\37\uffff\1\1\5\uffff\2\1\1\23",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA60_eot = DFA.unpackEncodedString(DFA60_eotS);
    static final short[] DFA60_eof = DFA.unpackEncodedString(DFA60_eofS);
    static final char[] DFA60_min = DFA.unpackEncodedStringToUnsignedChars(DFA60_minS);
    static final char[] DFA60_max = DFA.unpackEncodedStringToUnsignedChars(DFA60_maxS);
    static final short[] DFA60_accept = DFA.unpackEncodedString(DFA60_acceptS);
    static final short[] DFA60_special = DFA.unpackEncodedString(DFA60_specialS);
    static final short[][] DFA60_transition;

    static {
        int numStates = DFA60_transitionS.length;
        DFA60_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA60_transition[i] = DFA.unpackEncodedString(DFA60_transitionS[i]);
        }
    }

    class DFA60 extends DFA {

        public DFA60(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 60;
            this.eot = DFA60_eot;
            this.eof = DFA60_eof;
            this.min = DFA60_min;
            this.max = DFA60_max;
            this.accept = DFA60_accept;
            this.special = DFA60_special;
            this.transition = DFA60_transition;
        }
        public String getDescription() {
            return "()* loopback of 372:16: ( ShiftOperator addition )*";
        }
    }
    static final String DFA61_eotS =
        "\25\uffff";
    static final String DFA61_eofS =
        "\1\1\24\uffff";
    static final String DFA61_minS =
        "\1\4\24\uffff";
    static final String DFA61_maxS =
        "\1\136\24\uffff";
    static final String DFA61_acceptS =
        "\1\uffff\1\2\22\uffff\1\1";
    static final String DFA61_specialS =
        "\25\uffff}>";
    static final String[] DFA61_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\3\1\3\uffff\1\1\1\uffff"+
            "\1\1\1\24\2\1\1\uffff\2\24\31\uffff\3\1\37\uffff\1\1\5\uffff"+
            "\3\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA61_eot = DFA.unpackEncodedString(DFA61_eotS);
    static final short[] DFA61_eof = DFA.unpackEncodedString(DFA61_eofS);
    static final char[] DFA61_min = DFA.unpackEncodedStringToUnsignedChars(DFA61_minS);
    static final char[] DFA61_max = DFA.unpackEncodedStringToUnsignedChars(DFA61_maxS);
    static final short[] DFA61_accept = DFA.unpackEncodedString(DFA61_acceptS);
    static final short[] DFA61_special = DFA.unpackEncodedString(DFA61_specialS);
    static final short[][] DFA61_transition;

    static {
        int numStates = DFA61_transitionS.length;
        DFA61_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA61_transition[i] = DFA.unpackEncodedString(DFA61_transitionS[i]);
        }
    }

    class DFA61 extends DFA {

        public DFA61(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 61;
            this.eot = DFA61_eot;
            this.eof = DFA61_eof;
            this.min = DFA61_min;
            this.max = DFA61_max;
            this.accept = DFA61_accept;
            this.special = DFA61_special;
            this.transition = DFA61_transition;
        }
        public String getDescription() {
            return "()* loopback of 376:22: ( ( PLUS | MINUS | DOT ) multiplication )*";
        }
    }
    static final String DFA62_eotS =
        "\26\uffff";
    static final String DFA62_eofS =
        "\1\1\25\uffff";
    static final String DFA62_minS =
        "\1\4\25\uffff";
    static final String DFA62_maxS =
        "\1\136\25\uffff";
    static final String DFA62_acceptS =
        "\1\uffff\1\2\23\uffff\1\1";
    static final String DFA62_specialS =
        "\26\uffff}>";
    static final String[] DFA62_transitionS = {
            "\2\1\1\uffff\1\1\1\uffff\1\1\2\uffff\3\1\3\uffff\1\1\1\uffff"+
            "\4\1\1\uffff\2\1\3\25\26\uffff\3\1\37\uffff\1\1\5\uffff\3\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA62_eot = DFA.unpackEncodedString(DFA62_eotS);
    static final short[] DFA62_eof = DFA.unpackEncodedString(DFA62_eofS);
    static final char[] DFA62_min = DFA.unpackEncodedStringToUnsignedChars(DFA62_minS);
    static final char[] DFA62_max = DFA.unpackEncodedStringToUnsignedChars(DFA62_maxS);
    static final short[] DFA62_accept = DFA.unpackEncodedString(DFA62_acceptS);
    static final short[] DFA62_special = DFA.unpackEncodedString(DFA62_specialS);
    static final short[][] DFA62_transition;

    static {
        int numStates = DFA62_transitionS.length;
        DFA62_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA62_transition[i] = DFA.unpackEncodedString(DFA62_transitionS[i]);
        }
    }

    class DFA62 extends DFA {

        public DFA62(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 62;
            this.eot = DFA62_eot;
            this.eof = DFA62_eof;
            this.min = DFA62_min;
            this.max = DFA62_max;
            this.accept = DFA62_accept;
            this.special = DFA62_special;
            this.transition = DFA62_transition;
        }
        public String getDescription() {
            return "()* loopback of 380:18: ( ( ASTERISK | FORWARD_SLASH | PERCENT ) logicalNot )*";
        }
    }
    static final String DFA63_eotS =
        "\21\uffff";
    static final String DFA63_eofS =
        "\21\uffff";
    static final String DFA63_minS =
        "\1\6\20\uffff";
    static final String DFA63_maxS =
        "\1\146\20\uffff";
    static final String DFA63_acceptS =
        "\1\uffff\1\1\1\2\16\uffff";
    static final String DFA63_specialS =
        "\21\uffff}>";
    static final String[] DFA63_transitionS = {
            "\1\2\12\uffff\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff\1\1\1\uffff"+
            "\1\2\3\uffff\1\2\1\uffff\2\2\65\uffff\1\2\1\uffff\1\2\6\uffff"+
            "\7\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA63_eot = DFA.unpackEncodedString(DFA63_eotS);
    static final short[] DFA63_eof = DFA.unpackEncodedString(DFA63_eofS);
    static final char[] DFA63_min = DFA.unpackEncodedStringToUnsignedChars(DFA63_minS);
    static final char[] DFA63_max = DFA.unpackEncodedStringToUnsignedChars(DFA63_maxS);
    static final short[] DFA63_accept = DFA.unpackEncodedString(DFA63_acceptS);
    static final short[] DFA63_special = DFA.unpackEncodedString(DFA63_specialS);
    static final short[][] DFA63_transition;

    static {
        int numStates = DFA63_transitionS.length;
        DFA63_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA63_transition[i] = DFA.unpackEncodedString(DFA63_transitionS[i]);
        }
    }

    class DFA63 extends DFA {

        public DFA63(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 63;
            this.eot = DFA63_eot;
            this.eof = DFA63_eof;
            this.min = DFA63_min;
            this.max = DFA63_max;
            this.accept = DFA63_accept;
            this.special = DFA63_special;
            this.transition = DFA63_transition;
        }
        public String getDescription() {
            return "383:1: logicalNot : ( BANG logicalNot | instanceOf );";
        }
    }
    static final String DFA64_eotS =
        "\27\uffff";
    static final String DFA64_eofS =
        "\1\2\26\uffff";
    static final String DFA64_minS =
        "\1\4\26\uffff";
    static final String DFA64_maxS =
        "\1\136\26\uffff";
    static final String DFA64_acceptS =
        "\1\uffff\1\1\1\2\24\uffff";
    static final String DFA64_specialS =
        "\27\uffff}>";
    static final String[] DFA64_transitionS = {
            "\2\2\1\uffff\1\2\1\uffff\1\2\2\uffff\3\2\3\uffff\1\2\1\uffff"+
            "\4\2\1\uffff\5\2\26\uffff\3\2\1\1\36\uffff\1\2\5\uffff\3\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA64_eot = DFA.unpackEncodedString(DFA64_eotS);
    static final short[] DFA64_eof = DFA.unpackEncodedString(DFA64_eofS);
    static final char[] DFA64_min = DFA.unpackEncodedStringToUnsignedChars(DFA64_minS);
    static final char[] DFA64_max = DFA.unpackEncodedStringToUnsignedChars(DFA64_maxS);
    static final short[] DFA64_accept = DFA.unpackEncodedString(DFA64_acceptS);
    static final short[] DFA64_special = DFA.unpackEncodedString(DFA64_specialS);
    static final short[][] DFA64_transition;

    static {
        int numStates = DFA64_transitionS.length;
        DFA64_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA64_transition[i] = DFA.unpackEncodedString(DFA64_transitionS[i]);
        }
    }

    class DFA64 extends DFA {

        public DFA64(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 64;
            this.eot = DFA64_eot;
            this.eof = DFA64_eof;
            this.min = DFA64_min;
            this.max = DFA64_max;
            this.accept = DFA64_accept;
            this.special = DFA64_special;
            this.transition = DFA64_transition;
        }
        public String getDescription() {
            return "389:20: ( INSTANCE_OF negateOrCast )?";
        }
    }
    static final String DFA65_eotS =
        "\41\uffff";
    static final String DFA65_eofS =
        "\41\uffff";
    static final String DFA65_minS =
        "\1\6\1\uffff\1\6\36\uffff";
    static final String DFA65_maxS =
        "\1\146\1\uffff\1\146\36\uffff";
    static final String DFA65_acceptS =
        "\1\uffff\1\1\1\uffff\1\4\14\uffff\1\2\1\3\17\uffff";
    static final String DFA65_specialS =
        "\41\uffff}>";
    static final String[] DFA65_transitionS = {
            "\1\2\12\uffff\1\1\1\uffff\1\3\2\uffff\1\3\3\uffff\1\1\3\uffff"+
            "\1\1\1\uffff\2\3\65\uffff\1\3\1\uffff\1\3\6\uffff\7\3",
            "",
            "\1\21\12\uffff\1\21\1\uffff\1\21\2\uffff\1\21\1\uffff\1\21"+
            "\1\uffff\1\21\3\uffff\1\21\1\uffff\2\21\65\uffff\1\21\1\uffff"+
            "\1\21\5\uffff\1\20\7\21",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA65_eot = DFA.unpackEncodedString(DFA65_eotS);
    static final short[] DFA65_eof = DFA.unpackEncodedString(DFA65_eofS);
    static final char[] DFA65_min = DFA.unpackEncodedStringToUnsignedChars(DFA65_minS);
    static final char[] DFA65_max = DFA.unpackEncodedStringToUnsignedChars(DFA65_maxS);
    static final short[] DFA65_accept = DFA.unpackEncodedString(DFA65_acceptS);
    static final short[] DFA65_special = DFA.unpackEncodedString(DFA65_specialS);
    static final short[][] DFA65_transition;

    static {
        int numStates = DFA65_transitionS.length;
        DFA65_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA65_transition[i] = DFA.unpackEncodedString(DFA65_transitionS[i]);
        }
    }

    class DFA65 extends DFA {

        public DFA65(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 65;
            this.eot = DFA65_eot;
            this.eof = DFA65_eof;
            this.min = DFA65_min;
            this.max = DFA65_max;
            this.accept = DFA65_accept;
            this.special = DFA65_special;
            this.transition = DFA65_transition;
        }
        public String getDescription() {
            return "392:1: negateOrCast : ( ( TILDE | MINUS | SUPPRESS_WARNINGS ) increment | OPEN_BRACE PrimitiveType CLOSE_BRACE increment -> ^( Cast PrimitiveType increment ) | OPEN_BRACE weakLogicalAnd CLOSE_BRACE | increment );";
        }
    }
    static final String DFA66_eotS =
        "\53\uffff";
    static final String DFA66_eofS =
        "\2\uffff\1\4\50\uffff";
    static final String DFA66_minS =
        "\1\23\1\uffff\1\4\1\23\12\uffff\1\0\26\uffff\2\0\2\uffff\2\0";
    static final String DFA66_maxS =
        "\1\146\1\uffff\1\140\1\127\12\uffff\1\0\26\uffff\2\0\2\uffff\2\0";
    static final String DFA66_acceptS =
        "\1\uffff\1\1\2\uffff\1\3\42\uffff\1\2\3\uffff";
    static final String DFA66_specialS =
        "\16\uffff\1\0\26\uffff\1\1\1\2\2\uffff\1\3\1\4}>";
    static final String[] DFA66_transitionS = {
            "\1\3\2\uffff\1\4\11\uffff\2\4\65\uffff\1\2\1\uffff\1\4\6\uffff"+
            "\1\1\6\4",
            "",
            "\4\4\1\45\1\4\2\uffff\3\4\1\16\1\46\1\uffff\1\4\1\uffff\4\4"+
            "\1\uffff\5\4\26\uffff\4\4\36\uffff\1\4\5\uffff\3\4\1\uffff\1"+
            "\47",
            "\1\51\103\uffff\1\52",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "\1\uffff",
            "\1\uffff"
    };

    static final short[] DFA66_eot = DFA.unpackEncodedString(DFA66_eotS);
    static final short[] DFA66_eof = DFA.unpackEncodedString(DFA66_eofS);
    static final char[] DFA66_min = DFA.unpackEncodedStringToUnsignedChars(DFA66_minS);
    static final char[] DFA66_max = DFA.unpackEncodedStringToUnsignedChars(DFA66_maxS);
    static final short[] DFA66_accept = DFA.unpackEncodedString(DFA66_acceptS);
    static final short[] DFA66_special = DFA.unpackEncodedString(DFA66_specialS);
    static final short[][] DFA66_transition;

    static {
        int numStates = DFA66_transitionS.length;
        DFA66_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA66_transition[i] = DFA.unpackEncodedString(DFA66_transitionS[i]);
        }
    }

    class DFA66 extends DFA {

        public DFA66(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 66;
            this.eot = DFA66_eot;
            this.eof = DFA66_eof;
            this.min = DFA66_min;
            this.max = DFA66_max;
            this.accept = DFA66_accept;
            this.special = DFA66_special;
            this.transition = DFA66_transition;
        }
        public String getDescription() {
            return "399:1: increment : ( IncrementOperator name -> ^( Prefix IncrementOperator name ) | name IncrementOperator -> ^( Postfix IncrementOperator name ) | newOrClone );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA66_14 = input.LA(1);

                         
                        int index66_14 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred102_Php()) ) {s = 39;}

                        else if ( (true) ) {s = 4;}

                         
                        input.seek(index66_14);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA66_37 = input.LA(1);

                         
                        int index66_37 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred102_Php()) ) {s = 39;}

                        else if ( (true) ) {s = 4;}

                         
                        input.seek(index66_37);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA66_38 = input.LA(1);

                         
                        int index66_38 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred102_Php()) ) {s = 39;}

                        else if ( (true) ) {s = 4;}

                         
                        input.seek(index66_38);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA66_41 = input.LA(1);

                         
                        int index66_41 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred102_Php()) ) {s = 39;}

                        else if ( (true) ) {s = 4;}

                         
                        input.seek(index66_41);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA66_42 = input.LA(1);

                         
                        int index66_42 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred102_Php()) ) {s = 39;}

                        else if ( (true) ) {s = 4;}

                         
                        input.seek(index66_42);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 66, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA67_eotS =
        "\15\uffff";
    static final String DFA67_eofS =
        "\15\uffff";
    static final String DFA67_minS =
        "\1\23\14\uffff";
    static final String DFA67_maxS =
        "\1\146\14\uffff";
    static final String DFA67_acceptS =
        "\1\uffff\1\1\1\2\1\3\11\uffff";
    static final String DFA67_specialS =
        "\15\uffff}>";
    static final String[] DFA67_transitionS = {
            "\1\3\2\uffff\1\3\11\uffff\1\1\1\2\65\uffff\1\3\1\uffff\1\3\7"+
            "\uffff\6\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA67_eot = DFA.unpackEncodedString(DFA67_eotS);
    static final short[] DFA67_eof = DFA.unpackEncodedString(DFA67_eofS);
    static final char[] DFA67_min = DFA.unpackEncodedStringToUnsignedChars(DFA67_minS);
    static final char[] DFA67_max = DFA.unpackEncodedStringToUnsignedChars(DFA67_maxS);
    static final short[] DFA67_accept = DFA.unpackEncodedString(DFA67_acceptS);
    static final short[] DFA67_special = DFA.unpackEncodedString(DFA67_specialS);
    static final short[][] DFA67_transition;

    static {
        int numStates = DFA67_transitionS.length;
        DFA67_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA67_transition[i] = DFA.unpackEncodedString(DFA67_transitionS[i]);
        }
    }

    class DFA67 extends DFA {

        public DFA67(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 67;
            this.eot = DFA67_eot;
            this.eof = DFA67_eof;
            this.min = DFA67_min;
            this.max = DFA67_max;
            this.accept = DFA67_accept;
            this.special = DFA67_special;
            this.transition = DFA67_transition;
        }
        public String getDescription() {
            return "405:1: newOrClone : ( NEW nameOrFunctionCall | CLONE name | atomOrReference );";
        }
    }
    static final String DFA68_eotS =
        "\13\uffff";
    static final String DFA68_eofS =
        "\13\uffff";
    static final String DFA68_minS =
        "\1\23\12\uffff";
    static final String DFA68_maxS =
        "\1\146\12\uffff";
    static final String DFA68_acceptS =
        "\1\uffff\1\1\6\uffff\1\2\2\uffff";
    static final String DFA68_specialS =
        "\13\uffff}>";
    static final String[] DFA68_transitionS = {
            "\1\10\2\uffff\1\10\100\uffff\1\10\1\uffff\1\1\7\uffff\6\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA68_eot = DFA.unpackEncodedString(DFA68_eotS);
    static final short[] DFA68_eof = DFA.unpackEncodedString(DFA68_eofS);
    static final char[] DFA68_min = DFA.unpackEncodedStringToUnsignedChars(DFA68_minS);
    static final char[] DFA68_max = DFA.unpackEncodedStringToUnsignedChars(DFA68_maxS);
    static final short[] DFA68_accept = DFA.unpackEncodedString(DFA68_acceptS);
    static final short[] DFA68_special = DFA.unpackEncodedString(DFA68_specialS);
    static final short[][] DFA68_transition;

    static {
        int numStates = DFA68_transitionS.length;
        DFA68_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA68_transition[i] = DFA.unpackEncodedString(DFA68_transitionS[i]);
        }
    }

    class DFA68 extends DFA {

        public DFA68(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 68;
            this.eot = DFA68_eot;
            this.eof = DFA68_eof;
            this.min = DFA68_min;
            this.max = DFA68_max;
            this.accept = DFA68_accept;
            this.special = DFA68_special;
            this.transition = DFA68_transition;
        }
        public String getDescription() {
            return "411:1: atomOrReference : ( atom | reference );";
        }
    }
    static final String DFA70_eotS =
        "\22\uffff";
    static final String DFA70_eofS =
        "\22\uffff";
    static final String DFA70_minS =
        "\1\6\21\uffff";
    static final String DFA70_maxS =
        "\1\146\21\uffff";
    static final String DFA70_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA70_specialS =
        "\22\uffff}>";
    static final String[] DFA70_transitionS = {
            "\1\1\1\21\11\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1"+
            "\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff\1\1"+
            "\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA70_eot = DFA.unpackEncodedString(DFA70_eotS);
    static final short[] DFA70_eof = DFA.unpackEncodedString(DFA70_eofS);
    static final char[] DFA70_min = DFA.unpackEncodedStringToUnsignedChars(DFA70_minS);
    static final char[] DFA70_max = DFA.unpackEncodedStringToUnsignedChars(DFA70_maxS);
    static final short[] DFA70_accept = DFA.unpackEncodedString(DFA70_acceptS);
    static final short[] DFA70_special = DFA.unpackEncodedString(DFA70_specialS);
    static final short[][] DFA70_transition;

    static {
        int numStates = DFA70_transitionS.length;
        DFA70_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA70_transition[i] = DFA.unpackEncodedString(DFA70_transitionS[i]);
        }
    }

    class DFA70 extends DFA {

        public DFA70(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 70;
            this.eot = DFA70_eot;
            this.eof = DFA70_eof;
            this.min = DFA70_min;
            this.max = DFA70_max;
            this.accept = DFA70_accept;
            this.special = DFA70_special;
            this.transition = DFA70_transition;
        }
        public String getDescription() {
            return "417:24: ( arrayEntry ( COMMA arrayEntry )* )?";
        }
    }
    static final String DFA71_eotS =
        "\u00ce\uffff";
    static final String DFA71_eofS =
        "\1\uffff\1\41\7\uffff\6\41\u00bf\uffff";
    static final String DFA71_minS =
        "\1\6\1\5\1\23\1\6\1\23\1\6\3\23\6\5\1\6\1\23\20\0\3\uffff\4\0\1"+
        "\uffff\103\0\3\uffff\1\0\1\uffff\15\0\4\uffff\17\0\4\uffff\16\0"+
        "\4\uffff\16\0\4\uffff\15\0\1\uffff\1\0\3\uffff\3\0";
    static final String DFA71_maxS =
        "\1\146\1\140\1\127\3\146\3\127\6\136\1\6\1\127\20\0\3\uffff\4\0"+
        "\1\uffff\103\0\3\uffff\1\0\1\uffff\15\0\4\uffff\17\0\4\uffff\16"+
        "\0\4\uffff\16\0\4\uffff\15\0\1\uffff\1\0\3\uffff\3\0";
    static final String DFA71_acceptS =
        "\41\uffff\1\2\6\uffff\1\1\u00a5\uffff";
    static final String DFA71_specialS =
        "\21\uffff\1\0\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1"+
        "\14\1\15\1\16\1\17\3\uffff\1\20\1\21\1\22\1\23\1\uffff\1\24\1\25"+
        "\1\26\1\27\1\30\1\31\1\32\1\33\1\34\1\35\1\36\1\37\1\40\1\41\1\42"+
        "\1\43\1\44\1\45\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56\1\57"+
        "\1\60\1\61\1\62\1\63\1\64\1\65\1\66\1\67\1\70\1\71\1\72\1\73\1\74"+
        "\1\75\1\76\1\77\1\100\1\101\1\102\1\103\1\104\1\105\1\106\1\107"+
        "\1\110\1\111\1\112\1\113\1\114\1\115\1\116\1\117\1\120\1\121\1\122"+
        "\1\123\1\124\1\125\1\126\3\uffff\1\127\1\uffff\1\130\1\131\1\132"+
        "\1\133\1\134\1\135\1\136\1\137\1\140\1\141\1\142\1\143\1\144\4\uffff"+
        "\1\145\1\146\1\147\1\150\1\151\1\152\1\153\1\154\1\155\1\156\1\157"+
        "\1\160\1\161\1\162\1\163\4\uffff\1\164\1\165\1\166\1\167\1\170\1"+
        "\171\1\172\1\173\1\174\1\175\1\176\1\177\1\u0080\1\u0081\4\uffff"+
        "\1\u0082\1\u0083\1\u0084\1\u0085\1\u0086\1\u0087\1\u0088\1\u0089"+
        "\1\u008a\1\u008b\1\u008c\1\u008d\1\u008e\1\u008f\4\uffff\1\u0090"+
        "\1\u0091\1\u0092\1\u0093\1\u0094\1\u0095\1\u0096\1\u0097\1\u0098"+
        "\1\u0099\1\u009a\1\u009b\1\u009c\1\uffff\1\u009d\3\uffff\1\u009e"+
        "\1\u009f\1\u00a0}>";
    static final String[] DFA71_transitionS = {
            "\1\5\12\uffff\1\4\1\uffff\1\2\2\uffff\1\20\1\uffff\1\3\1\uffff"+
            "\1\4\3\uffff\1\4\1\uffff\1\7\1\10\65\uffff\1\1\1\uffff\1\14"+
            "\6\uffff\1\6\1\17\1\11\1\12\1\13\1\15\1\16",
            "\1\41\1\44\1\41\1\22\3\uffff\1\50\1\35\1\34\1\21\1\23\1\uffff"+
            "\1\47\2\uffff\1\26\1\32\1\33\1\uffff\2\26\3\25\1\uffff\1\46"+
            "\24\uffff\1\36\1\40\1\37\1\24\43\uffff\1\46\1\31\1\30\1\27\1"+
            "\uffff\1\45",
            "\1\51\103\uffff\1\52",
            "\1\55\12\uffff\1\54\1\uffff\1\60\2\uffff\1\72\1\uffff\1\53"+
            "\1\uffff\1\54\3\uffff\1\54\1\uffff\1\61\1\62\65\uffff\1\57\1"+
            "\uffff\1\66\6\uffff\1\56\1\71\1\63\1\64\1\65\1\67\1\70",
            "\1\75\2\uffff\1\107\11\uffff\1\76\1\77\65\uffff\1\74\1\uffff"+
            "\1\103\6\uffff\1\73\1\106\1\100\1\101\1\102\1\104\1\105",
            "\1\115\12\uffff\1\114\1\uffff\1\112\2\uffff\1\130\1\uffff\1"+
            "\113\1\uffff\1\114\3\uffff\1\114\1\uffff\1\117\1\120\65\uffff"+
            "\1\111\1\uffff\1\124\5\uffff\1\110\1\116\1\127\1\121\1\122\1"+
            "\123\1\125\1\126",
            "\1\132\103\uffff\1\131",
            "\1\134\103\uffff\1\133",
            "\1\136\103\uffff\1\135",
            "\1\41\1\uffff\1\41\4\uffff\1\50\1\150\1\147\3\uffff\1\157\2"+
            "\uffff\1\141\1\145\1\146\1\uffff\2\141\3\140\26\uffff\1\151"+
            "\1\153\1\152\1\137\44\uffff\1\144\1\143\1\142",
            "\1\41\1\uffff\1\41\4\uffff\1\50\1\172\1\171\3\uffff\1\u0082"+
            "\2\uffff\1\163\1\167\1\170\1\uffff\2\163\3\162\26\uffff\1\173"+
            "\1\175\1\174\1\161\44\uffff\1\166\1\165\1\164",
            "\1\41\1\uffff\1\41\4\uffff\1\50\1\u008c\1\u008b\3\uffff\1\u008d"+
            "\2\uffff\1\u0085\1\u0089\1\u008a\1\uffff\2\u0085\3\u0084\26"+
            "\uffff\1\u008e\1\u0090\1\u008f\1\u0083\44\uffff\1\u0088\1\u0087"+
            "\1\u0086",
            "\1\41\1\uffff\1\41\4\uffff\1\50\1\u009e\1\u009d\3\uffff\1\u009f"+
            "\2\uffff\1\u0097\1\u009b\1\u009c\1\uffff\2\u0097\3\u0096\26"+
            "\uffff\1\u00a0\1\u00a2\1\u00a1\1\u0095\44\uffff\1\u009a\1\u0099"+
            "\1\u0098",
            "\1\41\1\uffff\1\41\4\uffff\1\50\1\u00b0\1\u00af\3\uffff\1\u00b1"+
            "\2\uffff\1\u00a9\1\u00ad\1\u00ae\1\uffff\2\u00a9\3\u00a8\26"+
            "\uffff\1\u00b2\1\u00b4\1\u00b3\1\u00a7\44\uffff\1\u00ac\1\u00ab"+
            "\1\u00aa",
            "\1\41\1\uffff\1\41\4\uffff\1\50\1\u00c2\1\u00c1\3\uffff\1\u00c7"+
            "\2\uffff\1\u00bb\1\u00bf\1\u00c0\1\uffff\2\u00bb\3\u00ba\26"+
            "\uffff\1\u00c3\1\u00c5\1\u00c4\1\u00b9\44\uffff\1\u00be\1\u00bd"+
            "\1\u00bc",
            "\1\u00cb",
            "\1\u00cd\103\uffff\1\u00cc",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff"
    };

    static final short[] DFA71_eot = DFA.unpackEncodedString(DFA71_eotS);
    static final short[] DFA71_eof = DFA.unpackEncodedString(DFA71_eofS);
    static final char[] DFA71_min = DFA.unpackEncodedStringToUnsignedChars(DFA71_minS);
    static final char[] DFA71_max = DFA.unpackEncodedStringToUnsignedChars(DFA71_maxS);
    static final short[] DFA71_accept = DFA.unpackEncodedString(DFA71_acceptS);
    static final short[] DFA71_special = DFA.unpackEncodedString(DFA71_specialS);
    static final short[][] DFA71_transition;

    static {
        int numStates = DFA71_transitionS.length;
        DFA71_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA71_transition[i] = DFA.unpackEncodedString(DFA71_transitionS[i]);
        }
    }

    class DFA71 extends DFA {

        public DFA71(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 71;
            this.eot = DFA71_eot;
            this.eof = DFA71_eof;
            this.min = DFA71_min;
            this.max = DFA71_max;
            this.accept = DFA71_accept;
            this.special = DFA71_special;
            this.transition = DFA71_transition;
        }
        public String getDescription() {
            return "421:7: ( keyValuePair | expression )";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA71_17 = input.LA(1);

                         
                        int index71_17 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_17);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA71_18 = input.LA(1);

                         
                        int index71_18 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_18);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA71_19 = input.LA(1);

                         
                        int index71_19 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_19);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA71_20 = input.LA(1);

                         
                        int index71_20 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_20);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA71_21 = input.LA(1);

                         
                        int index71_21 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_21);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA71_22 = input.LA(1);

                         
                        int index71_22 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_22);
                        if ( s>=0 ) return s;
                        break;
                    case 6 : 
                        int LA71_23 = input.LA(1);

                         
                        int index71_23 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_23);
                        if ( s>=0 ) return s;
                        break;
                    case 7 : 
                        int LA71_24 = input.LA(1);

                         
                        int index71_24 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_24);
                        if ( s>=0 ) return s;
                        break;
                    case 8 : 
                        int LA71_25 = input.LA(1);

                         
                        int index71_25 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_25);
                        if ( s>=0 ) return s;
                        break;
                    case 9 : 
                        int LA71_26 = input.LA(1);

                         
                        int index71_26 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_26);
                        if ( s>=0 ) return s;
                        break;
                    case 10 : 
                        int LA71_27 = input.LA(1);

                         
                        int index71_27 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_27);
                        if ( s>=0 ) return s;
                        break;
                    case 11 : 
                        int LA71_28 = input.LA(1);

                         
                        int index71_28 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_28);
                        if ( s>=0 ) return s;
                        break;
                    case 12 : 
                        int LA71_29 = input.LA(1);

                         
                        int index71_29 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_29);
                        if ( s>=0 ) return s;
                        break;
                    case 13 : 
                        int LA71_30 = input.LA(1);

                         
                        int index71_30 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_30);
                        if ( s>=0 ) return s;
                        break;
                    case 14 : 
                        int LA71_31 = input.LA(1);

                         
                        int index71_31 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_31);
                        if ( s>=0 ) return s;
                        break;
                    case 15 : 
                        int LA71_32 = input.LA(1);

                         
                        int index71_32 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_32);
                        if ( s>=0 ) return s;
                        break;
                    case 16 : 
                        int LA71_36 = input.LA(1);

                         
                        int index71_36 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_36);
                        if ( s>=0 ) return s;
                        break;
                    case 17 : 
                        int LA71_37 = input.LA(1);

                         
                        int index71_37 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_37);
                        if ( s>=0 ) return s;
                        break;
                    case 18 : 
                        int LA71_38 = input.LA(1);

                         
                        int index71_38 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_38);
                        if ( s>=0 ) return s;
                        break;
                    case 19 : 
                        int LA71_39 = input.LA(1);

                         
                        int index71_39 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_39);
                        if ( s>=0 ) return s;
                        break;
                    case 20 : 
                        int LA71_41 = input.LA(1);

                         
                        int index71_41 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_41);
                        if ( s>=0 ) return s;
                        break;
                    case 21 : 
                        int LA71_42 = input.LA(1);

                         
                        int index71_42 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_42);
                        if ( s>=0 ) return s;
                        break;
                    case 22 : 
                        int LA71_43 = input.LA(1);

                         
                        int index71_43 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_43);
                        if ( s>=0 ) return s;
                        break;
                    case 23 : 
                        int LA71_44 = input.LA(1);

                         
                        int index71_44 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_44);
                        if ( s>=0 ) return s;
                        break;
                    case 24 : 
                        int LA71_45 = input.LA(1);

                         
                        int index71_45 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_45);
                        if ( s>=0 ) return s;
                        break;
                    case 25 : 
                        int LA71_46 = input.LA(1);

                         
                        int index71_46 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_46);
                        if ( s>=0 ) return s;
                        break;
                    case 26 : 
                        int LA71_47 = input.LA(1);

                         
                        int index71_47 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_47);
                        if ( s>=0 ) return s;
                        break;
                    case 27 : 
                        int LA71_48 = input.LA(1);

                         
                        int index71_48 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_48);
                        if ( s>=0 ) return s;
                        break;
                    case 28 : 
                        int LA71_49 = input.LA(1);

                         
                        int index71_49 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_49);
                        if ( s>=0 ) return s;
                        break;
                    case 29 : 
                        int LA71_50 = input.LA(1);

                         
                        int index71_50 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_50);
                        if ( s>=0 ) return s;
                        break;
                    case 30 : 
                        int LA71_51 = input.LA(1);

                         
                        int index71_51 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_51);
                        if ( s>=0 ) return s;
                        break;
                    case 31 : 
                        int LA71_52 = input.LA(1);

                         
                        int index71_52 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_52);
                        if ( s>=0 ) return s;
                        break;
                    case 32 : 
                        int LA71_53 = input.LA(1);

                         
                        int index71_53 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_53);
                        if ( s>=0 ) return s;
                        break;
                    case 33 : 
                        int LA71_54 = input.LA(1);

                         
                        int index71_54 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_54);
                        if ( s>=0 ) return s;
                        break;
                    case 34 : 
                        int LA71_55 = input.LA(1);

                         
                        int index71_55 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_55);
                        if ( s>=0 ) return s;
                        break;
                    case 35 : 
                        int LA71_56 = input.LA(1);

                         
                        int index71_56 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_56);
                        if ( s>=0 ) return s;
                        break;
                    case 36 : 
                        int LA71_57 = input.LA(1);

                         
                        int index71_57 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_57);
                        if ( s>=0 ) return s;
                        break;
                    case 37 : 
                        int LA71_58 = input.LA(1);

                         
                        int index71_58 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_58);
                        if ( s>=0 ) return s;
                        break;
                    case 38 : 
                        int LA71_59 = input.LA(1);

                         
                        int index71_59 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_59);
                        if ( s>=0 ) return s;
                        break;
                    case 39 : 
                        int LA71_60 = input.LA(1);

                         
                        int index71_60 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_60);
                        if ( s>=0 ) return s;
                        break;
                    case 40 : 
                        int LA71_61 = input.LA(1);

                         
                        int index71_61 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_61);
                        if ( s>=0 ) return s;
                        break;
                    case 41 : 
                        int LA71_62 = input.LA(1);

                         
                        int index71_62 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_62);
                        if ( s>=0 ) return s;
                        break;
                    case 42 : 
                        int LA71_63 = input.LA(1);

                         
                        int index71_63 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_63);
                        if ( s>=0 ) return s;
                        break;
                    case 43 : 
                        int LA71_64 = input.LA(1);

                         
                        int index71_64 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_64);
                        if ( s>=0 ) return s;
                        break;
                    case 44 : 
                        int LA71_65 = input.LA(1);

                         
                        int index71_65 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_65);
                        if ( s>=0 ) return s;
                        break;
                    case 45 : 
                        int LA71_66 = input.LA(1);

                         
                        int index71_66 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_66);
                        if ( s>=0 ) return s;
                        break;
                    case 46 : 
                        int LA71_67 = input.LA(1);

                         
                        int index71_67 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_67);
                        if ( s>=0 ) return s;
                        break;
                    case 47 : 
                        int LA71_68 = input.LA(1);

                         
                        int index71_68 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_68);
                        if ( s>=0 ) return s;
                        break;
                    case 48 : 
                        int LA71_69 = input.LA(1);

                         
                        int index71_69 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_69);
                        if ( s>=0 ) return s;
                        break;
                    case 49 : 
                        int LA71_70 = input.LA(1);

                         
                        int index71_70 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_70);
                        if ( s>=0 ) return s;
                        break;
                    case 50 : 
                        int LA71_71 = input.LA(1);

                         
                        int index71_71 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_71);
                        if ( s>=0 ) return s;
                        break;
                    case 51 : 
                        int LA71_72 = input.LA(1);

                         
                        int index71_72 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_72);
                        if ( s>=0 ) return s;
                        break;
                    case 52 : 
                        int LA71_73 = input.LA(1);

                         
                        int index71_73 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_73);
                        if ( s>=0 ) return s;
                        break;
                    case 53 : 
                        int LA71_74 = input.LA(1);

                         
                        int index71_74 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_74);
                        if ( s>=0 ) return s;
                        break;
                    case 54 : 
                        int LA71_75 = input.LA(1);

                         
                        int index71_75 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_75);
                        if ( s>=0 ) return s;
                        break;
                    case 55 : 
                        int LA71_76 = input.LA(1);

                         
                        int index71_76 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_76);
                        if ( s>=0 ) return s;
                        break;
                    case 56 : 
                        int LA71_77 = input.LA(1);

                         
                        int index71_77 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_77);
                        if ( s>=0 ) return s;
                        break;
                    case 57 : 
                        int LA71_78 = input.LA(1);

                         
                        int index71_78 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_78);
                        if ( s>=0 ) return s;
                        break;
                    case 58 : 
                        int LA71_79 = input.LA(1);

                         
                        int index71_79 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_79);
                        if ( s>=0 ) return s;
                        break;
                    case 59 : 
                        int LA71_80 = input.LA(1);

                         
                        int index71_80 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_80);
                        if ( s>=0 ) return s;
                        break;
                    case 60 : 
                        int LA71_81 = input.LA(1);

                         
                        int index71_81 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_81);
                        if ( s>=0 ) return s;
                        break;
                    case 61 : 
                        int LA71_82 = input.LA(1);

                         
                        int index71_82 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_82);
                        if ( s>=0 ) return s;
                        break;
                    case 62 : 
                        int LA71_83 = input.LA(1);

                         
                        int index71_83 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_83);
                        if ( s>=0 ) return s;
                        break;
                    case 63 : 
                        int LA71_84 = input.LA(1);

                         
                        int index71_84 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_84);
                        if ( s>=0 ) return s;
                        break;
                    case 64 : 
                        int LA71_85 = input.LA(1);

                         
                        int index71_85 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_85);
                        if ( s>=0 ) return s;
                        break;
                    case 65 : 
                        int LA71_86 = input.LA(1);

                         
                        int index71_86 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_86);
                        if ( s>=0 ) return s;
                        break;
                    case 66 : 
                        int LA71_87 = input.LA(1);

                         
                        int index71_87 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_87);
                        if ( s>=0 ) return s;
                        break;
                    case 67 : 
                        int LA71_88 = input.LA(1);

                         
                        int index71_88 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_88);
                        if ( s>=0 ) return s;
                        break;
                    case 68 : 
                        int LA71_89 = input.LA(1);

                         
                        int index71_89 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_89);
                        if ( s>=0 ) return s;
                        break;
                    case 69 : 
                        int LA71_90 = input.LA(1);

                         
                        int index71_90 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_90);
                        if ( s>=0 ) return s;
                        break;
                    case 70 : 
                        int LA71_91 = input.LA(1);

                         
                        int index71_91 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_91);
                        if ( s>=0 ) return s;
                        break;
                    case 71 : 
                        int LA71_92 = input.LA(1);

                         
                        int index71_92 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_92);
                        if ( s>=0 ) return s;
                        break;
                    case 72 : 
                        int LA71_93 = input.LA(1);

                         
                        int index71_93 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_93);
                        if ( s>=0 ) return s;
                        break;
                    case 73 : 
                        int LA71_94 = input.LA(1);

                         
                        int index71_94 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_94);
                        if ( s>=0 ) return s;
                        break;
                    case 74 : 
                        int LA71_95 = input.LA(1);

                         
                        int index71_95 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_95);
                        if ( s>=0 ) return s;
                        break;
                    case 75 : 
                        int LA71_96 = input.LA(1);

                         
                        int index71_96 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_96);
                        if ( s>=0 ) return s;
                        break;
                    case 76 : 
                        int LA71_97 = input.LA(1);

                         
                        int index71_97 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_97);
                        if ( s>=0 ) return s;
                        break;
                    case 77 : 
                        int LA71_98 = input.LA(1);

                         
                        int index71_98 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_98);
                        if ( s>=0 ) return s;
                        break;
                    case 78 : 
                        int LA71_99 = input.LA(1);

                         
                        int index71_99 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_99);
                        if ( s>=0 ) return s;
                        break;
                    case 79 : 
                        int LA71_100 = input.LA(1);

                         
                        int index71_100 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_100);
                        if ( s>=0 ) return s;
                        break;
                    case 80 : 
                        int LA71_101 = input.LA(1);

                         
                        int index71_101 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_101);
                        if ( s>=0 ) return s;
                        break;
                    case 81 : 
                        int LA71_102 = input.LA(1);

                         
                        int index71_102 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_102);
                        if ( s>=0 ) return s;
                        break;
                    case 82 : 
                        int LA71_103 = input.LA(1);

                         
                        int index71_103 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_103);
                        if ( s>=0 ) return s;
                        break;
                    case 83 : 
                        int LA71_104 = input.LA(1);

                         
                        int index71_104 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_104);
                        if ( s>=0 ) return s;
                        break;
                    case 84 : 
                        int LA71_105 = input.LA(1);

                         
                        int index71_105 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_105);
                        if ( s>=0 ) return s;
                        break;
                    case 85 : 
                        int LA71_106 = input.LA(1);

                         
                        int index71_106 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_106);
                        if ( s>=0 ) return s;
                        break;
                    case 86 : 
                        int LA71_107 = input.LA(1);

                         
                        int index71_107 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_107);
                        if ( s>=0 ) return s;
                        break;
                    case 87 : 
                        int LA71_111 = input.LA(1);

                         
                        int index71_111 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_111);
                        if ( s>=0 ) return s;
                        break;
                    case 88 : 
                        int LA71_113 = input.LA(1);

                         
                        int index71_113 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_113);
                        if ( s>=0 ) return s;
                        break;
                    case 89 : 
                        int LA71_114 = input.LA(1);

                         
                        int index71_114 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_114);
                        if ( s>=0 ) return s;
                        break;
                    case 90 : 
                        int LA71_115 = input.LA(1);

                         
                        int index71_115 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_115);
                        if ( s>=0 ) return s;
                        break;
                    case 91 : 
                        int LA71_116 = input.LA(1);

                         
                        int index71_116 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_116);
                        if ( s>=0 ) return s;
                        break;
                    case 92 : 
                        int LA71_117 = input.LA(1);

                         
                        int index71_117 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_117);
                        if ( s>=0 ) return s;
                        break;
                    case 93 : 
                        int LA71_118 = input.LA(1);

                         
                        int index71_118 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_118);
                        if ( s>=0 ) return s;
                        break;
                    case 94 : 
                        int LA71_119 = input.LA(1);

                         
                        int index71_119 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_119);
                        if ( s>=0 ) return s;
                        break;
                    case 95 : 
                        int LA71_120 = input.LA(1);

                         
                        int index71_120 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_120);
                        if ( s>=0 ) return s;
                        break;
                    case 96 : 
                        int LA71_121 = input.LA(1);

                         
                        int index71_121 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_121);
                        if ( s>=0 ) return s;
                        break;
                    case 97 : 
                        int LA71_122 = input.LA(1);

                         
                        int index71_122 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_122);
                        if ( s>=0 ) return s;
                        break;
                    case 98 : 
                        int LA71_123 = input.LA(1);

                         
                        int index71_123 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_123);
                        if ( s>=0 ) return s;
                        break;
                    case 99 : 
                        int LA71_124 = input.LA(1);

                         
                        int index71_124 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_124);
                        if ( s>=0 ) return s;
                        break;
                    case 100 : 
                        int LA71_125 = input.LA(1);

                         
                        int index71_125 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_125);
                        if ( s>=0 ) return s;
                        break;
                    case 101 : 
                        int LA71_130 = input.LA(1);

                         
                        int index71_130 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_130);
                        if ( s>=0 ) return s;
                        break;
                    case 102 : 
                        int LA71_131 = input.LA(1);

                         
                        int index71_131 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_131);
                        if ( s>=0 ) return s;
                        break;
                    case 103 : 
                        int LA71_132 = input.LA(1);

                         
                        int index71_132 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_132);
                        if ( s>=0 ) return s;
                        break;
                    case 104 : 
                        int LA71_133 = input.LA(1);

                         
                        int index71_133 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_133);
                        if ( s>=0 ) return s;
                        break;
                    case 105 : 
                        int LA71_134 = input.LA(1);

                         
                        int index71_134 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_134);
                        if ( s>=0 ) return s;
                        break;
                    case 106 : 
                        int LA71_135 = input.LA(1);

                         
                        int index71_135 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_135);
                        if ( s>=0 ) return s;
                        break;
                    case 107 : 
                        int LA71_136 = input.LA(1);

                         
                        int index71_136 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_136);
                        if ( s>=0 ) return s;
                        break;
                    case 108 : 
                        int LA71_137 = input.LA(1);

                         
                        int index71_137 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_137);
                        if ( s>=0 ) return s;
                        break;
                    case 109 : 
                        int LA71_138 = input.LA(1);

                         
                        int index71_138 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_138);
                        if ( s>=0 ) return s;
                        break;
                    case 110 : 
                        int LA71_139 = input.LA(1);

                         
                        int index71_139 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_139);
                        if ( s>=0 ) return s;
                        break;
                    case 111 : 
                        int LA71_140 = input.LA(1);

                         
                        int index71_140 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_140);
                        if ( s>=0 ) return s;
                        break;
                    case 112 : 
                        int LA71_141 = input.LA(1);

                         
                        int index71_141 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_141);
                        if ( s>=0 ) return s;
                        break;
                    case 113 : 
                        int LA71_142 = input.LA(1);

                         
                        int index71_142 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_142);
                        if ( s>=0 ) return s;
                        break;
                    case 114 : 
                        int LA71_143 = input.LA(1);

                         
                        int index71_143 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_143);
                        if ( s>=0 ) return s;
                        break;
                    case 115 : 
                        int LA71_144 = input.LA(1);

                         
                        int index71_144 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_144);
                        if ( s>=0 ) return s;
                        break;
                    case 116 : 
                        int LA71_149 = input.LA(1);

                         
                        int index71_149 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_149);
                        if ( s>=0 ) return s;
                        break;
                    case 117 : 
                        int LA71_150 = input.LA(1);

                         
                        int index71_150 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_150);
                        if ( s>=0 ) return s;
                        break;
                    case 118 : 
                        int LA71_151 = input.LA(1);

                         
                        int index71_151 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_151);
                        if ( s>=0 ) return s;
                        break;
                    case 119 : 
                        int LA71_152 = input.LA(1);

                         
                        int index71_152 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_152);
                        if ( s>=0 ) return s;
                        break;
                    case 120 : 
                        int LA71_153 = input.LA(1);

                         
                        int index71_153 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_153);
                        if ( s>=0 ) return s;
                        break;
                    case 121 : 
                        int LA71_154 = input.LA(1);

                         
                        int index71_154 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_154);
                        if ( s>=0 ) return s;
                        break;
                    case 122 : 
                        int LA71_155 = input.LA(1);

                         
                        int index71_155 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_155);
                        if ( s>=0 ) return s;
                        break;
                    case 123 : 
                        int LA71_156 = input.LA(1);

                         
                        int index71_156 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_156);
                        if ( s>=0 ) return s;
                        break;
                    case 124 : 
                        int LA71_157 = input.LA(1);

                         
                        int index71_157 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_157);
                        if ( s>=0 ) return s;
                        break;
                    case 125 : 
                        int LA71_158 = input.LA(1);

                         
                        int index71_158 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_158);
                        if ( s>=0 ) return s;
                        break;
                    case 126 : 
                        int LA71_159 = input.LA(1);

                         
                        int index71_159 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_159);
                        if ( s>=0 ) return s;
                        break;
                    case 127 : 
                        int LA71_160 = input.LA(1);

                         
                        int index71_160 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_160);
                        if ( s>=0 ) return s;
                        break;
                    case 128 : 
                        int LA71_161 = input.LA(1);

                         
                        int index71_161 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_161);
                        if ( s>=0 ) return s;
                        break;
                    case 129 : 
                        int LA71_162 = input.LA(1);

                         
                        int index71_162 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_162);
                        if ( s>=0 ) return s;
                        break;
                    case 130 : 
                        int LA71_167 = input.LA(1);

                         
                        int index71_167 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_167);
                        if ( s>=0 ) return s;
                        break;
                    case 131 : 
                        int LA71_168 = input.LA(1);

                         
                        int index71_168 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_168);
                        if ( s>=0 ) return s;
                        break;
                    case 132 : 
                        int LA71_169 = input.LA(1);

                         
                        int index71_169 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_169);
                        if ( s>=0 ) return s;
                        break;
                    case 133 : 
                        int LA71_170 = input.LA(1);

                         
                        int index71_170 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_170);
                        if ( s>=0 ) return s;
                        break;
                    case 134 : 
                        int LA71_171 = input.LA(1);

                         
                        int index71_171 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_171);
                        if ( s>=0 ) return s;
                        break;
                    case 135 : 
                        int LA71_172 = input.LA(1);

                         
                        int index71_172 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_172);
                        if ( s>=0 ) return s;
                        break;
                    case 136 : 
                        int LA71_173 = input.LA(1);

                         
                        int index71_173 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_173);
                        if ( s>=0 ) return s;
                        break;
                    case 137 : 
                        int LA71_174 = input.LA(1);

                         
                        int index71_174 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_174);
                        if ( s>=0 ) return s;
                        break;
                    case 138 : 
                        int LA71_175 = input.LA(1);

                         
                        int index71_175 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_175);
                        if ( s>=0 ) return s;
                        break;
                    case 139 : 
                        int LA71_176 = input.LA(1);

                         
                        int index71_176 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_176);
                        if ( s>=0 ) return s;
                        break;
                    case 140 : 
                        int LA71_177 = input.LA(1);

                         
                        int index71_177 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_177);
                        if ( s>=0 ) return s;
                        break;
                    case 141 : 
                        int LA71_178 = input.LA(1);

                         
                        int index71_178 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_178);
                        if ( s>=0 ) return s;
                        break;
                    case 142 : 
                        int LA71_179 = input.LA(1);

                         
                        int index71_179 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_179);
                        if ( s>=0 ) return s;
                        break;
                    case 143 : 
                        int LA71_180 = input.LA(1);

                         
                        int index71_180 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_180);
                        if ( s>=0 ) return s;
                        break;
                    case 144 : 
                        int LA71_185 = input.LA(1);

                         
                        int index71_185 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_185);
                        if ( s>=0 ) return s;
                        break;
                    case 145 : 
                        int LA71_186 = input.LA(1);

                         
                        int index71_186 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_186);
                        if ( s>=0 ) return s;
                        break;
                    case 146 : 
                        int LA71_187 = input.LA(1);

                         
                        int index71_187 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_187);
                        if ( s>=0 ) return s;
                        break;
                    case 147 : 
                        int LA71_188 = input.LA(1);

                         
                        int index71_188 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_188);
                        if ( s>=0 ) return s;
                        break;
                    case 148 : 
                        int LA71_189 = input.LA(1);

                         
                        int index71_189 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_189);
                        if ( s>=0 ) return s;
                        break;
                    case 149 : 
                        int LA71_190 = input.LA(1);

                         
                        int index71_190 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_190);
                        if ( s>=0 ) return s;
                        break;
                    case 150 : 
                        int LA71_191 = input.LA(1);

                         
                        int index71_191 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_191);
                        if ( s>=0 ) return s;
                        break;
                    case 151 : 
                        int LA71_192 = input.LA(1);

                         
                        int index71_192 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_192);
                        if ( s>=0 ) return s;
                        break;
                    case 152 : 
                        int LA71_193 = input.LA(1);

                         
                        int index71_193 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_193);
                        if ( s>=0 ) return s;
                        break;
                    case 153 : 
                        int LA71_194 = input.LA(1);

                         
                        int index71_194 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_194);
                        if ( s>=0 ) return s;
                        break;
                    case 154 : 
                        int LA71_195 = input.LA(1);

                         
                        int index71_195 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_195);
                        if ( s>=0 ) return s;
                        break;
                    case 155 : 
                        int LA71_196 = input.LA(1);

                         
                        int index71_196 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_196);
                        if ( s>=0 ) return s;
                        break;
                    case 156 : 
                        int LA71_197 = input.LA(1);

                         
                        int index71_197 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_197);
                        if ( s>=0 ) return s;
                        break;
                    case 157 : 
                        int LA71_199 = input.LA(1);

                         
                        int index71_199 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_199);
                        if ( s>=0 ) return s;
                        break;
                    case 158 : 
                        int LA71_203 = input.LA(1);

                         
                        int index71_203 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_203);
                        if ( s>=0 ) return s;
                        break;
                    case 159 : 
                        int LA71_204 = input.LA(1);

                         
                        int index71_204 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_204);
                        if ( s>=0 ) return s;
                        break;
                    case 160 : 
                        int LA71_205 = input.LA(1);

                         
                        int index71_205 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred108_Php()) ) {s = 40;}

                        else if ( (true) ) {s = 33;}

                         
                        input.seek(index71_205);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 71, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA76_eotS =
        "\37\uffff";
    static final String DFA76_eofS =
        "\1\uffff\1\7\35\uffff";
    static final String DFA76_minS =
        "\1\23\1\4\1\23\3\0\27\uffff\2\0";
    static final String DFA76_maxS =
        "\1\127\1\136\1\127\3\0\27\uffff\2\0";
    static final String DFA76_acceptS =
        "\6\uffff\1\1\1\2\27\uffff";
    static final String DFA76_specialS =
        "\3\uffff\1\0\1\1\1\2\27\uffff\1\3\1\4}>";
    static final String[] DFA76_transitionS = {
            "\1\2\103\uffff\1\1",
            "\2\7\1\6\1\7\1\4\1\7\2\uffff\3\7\1\3\1\5\1\uffff\1\7\1\uffff"+
            "\4\7\1\uffff\5\7\26\uffff\4\7\36\uffff\1\7\5\uffff\3\7",
            "\1\35\103\uffff\1\36",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff"
    };

    static final short[] DFA76_eot = DFA.unpackEncodedString(DFA76_eotS);
    static final short[] DFA76_eof = DFA.unpackEncodedString(DFA76_eofS);
    static final char[] DFA76_min = DFA.unpackEncodedStringToUnsignedChars(DFA76_minS);
    static final char[] DFA76_max = DFA.unpackEncodedStringToUnsignedChars(DFA76_maxS);
    static final short[] DFA76_accept = DFA.unpackEncodedString(DFA76_acceptS);
    static final short[] DFA76_special = DFA.unpackEncodedString(DFA76_specialS);
    static final short[][] DFA76_transition;

    static {
        int numStates = DFA76_transitionS.length;
        DFA76_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA76_transition[i] = DFA.unpackEncodedString(DFA76_transitionS[i]);
        }
    }

    class DFA76 extends DFA {

        public DFA76(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 76;
            this.eot = DFA76_eot;
            this.eof = DFA76_eof;
            this.min = DFA76_min;
            this.max = DFA76_max;
            this.accept = DFA76_accept;
            this.special = DFA76_special;
            this.transition = DFA76_transition;
        }
        public String getDescription() {
            return "437:1: nameOrFunctionCall : ( name OPEN_BRACE ( expression ( COMMA expression )* )? CLOSE_BRACE -> ^( Apply name ( expression )* ) | name );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA76_3 = input.LA(1);

                         
                        int index76_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred118_Php()) ) {s = 6;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index76_3);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA76_4 = input.LA(1);

                         
                        int index76_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred118_Php()) ) {s = 6;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index76_4);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA76_5 = input.LA(1);

                         
                        int index76_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred118_Php()) ) {s = 6;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index76_5);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA76_29 = input.LA(1);

                         
                        int index76_29 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred118_Php()) ) {s = 6;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index76_29);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA76_30 = input.LA(1);

                         
                        int index76_30 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred118_Php()) ) {s = 6;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index76_30);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 76, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA75_eotS =
        "\22\uffff";
    static final String DFA75_eofS =
        "\22\uffff";
    static final String DFA75_minS =
        "\1\6\21\uffff";
    static final String DFA75_maxS =
        "\1\146\21\uffff";
    static final String DFA75_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA75_specialS =
        "\22\uffff}>";
    static final String[] DFA75_transitionS = {
            "\1\1\1\21\11\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1"+
            "\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff\1\1"+
            "\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA75_eot = DFA.unpackEncodedString(DFA75_eotS);
    static final short[] DFA75_eof = DFA.unpackEncodedString(DFA75_eofS);
    static final char[] DFA75_min = DFA.unpackEncodedStringToUnsignedChars(DFA75_minS);
    static final char[] DFA75_max = DFA.unpackEncodedStringToUnsignedChars(DFA75_maxS);
    static final short[] DFA75_accept = DFA.unpackEncodedString(DFA75_acceptS);
    static final short[] DFA75_special = DFA.unpackEncodedString(DFA75_specialS);
    static final short[][] DFA75_transition;

    static {
        int numStates = DFA75_transitionS.length;
        DFA75_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA75_transition[i] = DFA.unpackEncodedString(DFA75_transitionS[i]);
        }
    }

    class DFA75 extends DFA {

        public DFA75(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 75;
            this.eot = DFA75_eot;
            this.eof = DFA75_eof;
            this.min = DFA75_min;
            this.max = DFA75_max;
            this.accept = DFA75_accept;
            this.special = DFA75_special;
            this.transition = DFA75_transition;
        }
        public String getDescription() {
            return "438:23: ( expression ( COMMA expression )* )?";
        }
    }
    static final String DFA77_eotS =
        "\43\uffff";
    static final String DFA77_eofS =
        "\43\uffff";
    static final String DFA77_minS =
        "\1\23\1\17\1\23\36\uffff\2\0";
    static final String DFA77_maxS =
        "\1\127\1\17\1\127\36\uffff\2\0";
    static final String DFA77_acceptS =
        "\3\uffff\1\1\33\uffff\1\2\1\3\2\uffff";
    static final String DFA77_specialS =
        "\1\uffff\1\0\37\uffff\1\1\1\2}>";
    static final String[] DFA77_transitionS = {
            "\1\2\103\uffff\1\1",
            "\1\3",
            "\1\41\103\uffff\1\42",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "\1\uffff"
    };

    static final short[] DFA77_eot = DFA.unpackEncodedString(DFA77_eotS);
    static final short[] DFA77_eof = DFA.unpackEncodedString(DFA77_eofS);
    static final char[] DFA77_min = DFA.unpackEncodedStringToUnsignedChars(DFA77_minS);
    static final char[] DFA77_max = DFA.unpackEncodedStringToUnsignedChars(DFA77_maxS);
    static final short[] DFA77_accept = DFA.unpackEncodedString(DFA77_acceptS);
    static final short[] DFA77_special = DFA.unpackEncodedString(DFA77_specialS);
    static final short[][] DFA77_transition;

    static {
        int numStates = DFA77_transitionS.length;
        DFA77_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA77_transition[i] = DFA.unpackEncodedString(DFA77_transitionS[i]);
        }
    }

    class DFA77 extends DFA {

        public DFA77(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 77;
            this.eot = DFA77_eot;
            this.eof = DFA77_eof;
            this.min = DFA77_min;
            this.max = DFA77_max;
            this.accept = DFA77_accept;
            this.special = DFA77_special;
            this.transition = DFA77_transition;
        }
        public String getDescription() {
            return "442:1: name : ( staticMemberAccess | memberAccess | variable );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA77_1 = input.LA(1);

                         
                        int index77_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA77_1==CLASS_MEMBER) ) {s = 3;}

                        else if ( (synpred120_Php()) ) {s = 31;}

                        else if ( (true) ) {s = 32;}

                         
                        input.seek(index77_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA77_33 = input.LA(1);

                         
                        int index77_33 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred120_Php()) ) {s = 31;}

                        else if ( (true) ) {s = 32;}

                         
                        input.seek(index77_33);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA77_34 = input.LA(1);

                         
                        int index77_34 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred120_Php()) ) {s = 31;}

                        else if ( (true) ) {s = 32;}

                         
                        input.seek(index77_34);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 77, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA78_eotS =
        "\34\uffff";
    static final String DFA78_eofS =
        "\1\1\33\uffff";
    static final String DFA78_minS =
        "\1\4\33\uffff";
    static final String DFA78_maxS =
        "\1\140\33\uffff";
    static final String DFA78_acceptS =
        "\1\uffff\1\3\30\uffff\1\1\1\2";
    static final String DFA78_specialS =
        "\34\uffff}>";
    static final String[] DFA78_transitionS = {
            "\4\1\1\32\1\1\2\uffff\3\1\1\uffff\1\33\1\uffff\1\1\1\uffff\4"+
            "\1\1\uffff\5\1\1\uffff\1\1\24\uffff\4\1\36\uffff\1\1\4\uffff"+
            "\4\1\1\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA78_eot = DFA.unpackEncodedString(DFA78_eotS);
    static final short[] DFA78_eof = DFA.unpackEncodedString(DFA78_eofS);
    static final char[] DFA78_min = DFA.unpackEncodedStringToUnsignedChars(DFA78_minS);
    static final char[] DFA78_max = DFA.unpackEncodedStringToUnsignedChars(DFA78_maxS);
    static final short[] DFA78_accept = DFA.unpackEncodedString(DFA78_acceptS);
    static final short[] DFA78_special = DFA.unpackEncodedString(DFA78_specialS);
    static final short[][] DFA78_transition;

    static {
        int numStates = DFA78_transitionS.length;
        DFA78_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA78_transition[i] = DFA.unpackEncodedString(DFA78_transitionS[i]);
        }
    }

    class DFA78 extends DFA {

        public DFA78(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 78;
            this.eot = DFA78_eot;
            this.eof = DFA78_eof;
            this.min = DFA78_min;
            this.max = DFA78_max;
            this.accept = DFA78_accept;
            this.special = DFA78_special;
            this.transition = DFA78_transition;
        }
        public String getDescription() {
            return "()* loopback of 453:9: ( OPEN_SQUARE_BRACE expression CLOSE_SQUARE_BRACE | '->' UnquotedString )*";
        }
    }
    static final String DFA80_eotS =
        "\32\uffff";
    static final String DFA80_eofS =
        "\32\uffff";
    static final String DFA80_minS =
        "\1\6\31\uffff";
    static final String DFA80_maxS =
        "\1\146\31\uffff";
    static final String DFA80_acceptS =
        "\1\uffff\1\1\27\uffff\1\2";
    static final String DFA80_specialS =
        "\32\uffff}>";
    static final String[] DFA80_transitionS = {
            "\1\1\12\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1\uffff"+
            "\1\1\3\uffff\1\1\1\uffff\4\1\13\uffff\5\1\42\uffff\1\31\1\1"+
            "\1\uffff\2\1\5\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA80_eot = DFA.unpackEncodedString(DFA80_eotS);
    static final short[] DFA80_eof = DFA.unpackEncodedString(DFA80_eofS);
    static final char[] DFA80_min = DFA.unpackEncodedStringToUnsignedChars(DFA80_minS);
    static final char[] DFA80_max = DFA.unpackEncodedStringToUnsignedChars(DFA80_maxS);
    static final short[] DFA80_accept = DFA.unpackEncodedString(DFA80_acceptS);
    static final short[] DFA80_special = DFA.unpackEncodedString(DFA80_specialS);
    static final short[][] DFA80_transition;

    static {
        int numStates = DFA80_transitionS.length;
        DFA80_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA80_transition[i] = DFA.unpackEncodedString(DFA80_transitionS[i]);
        }
    }

    class DFA80 extends DFA {

        public DFA80(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 80;
            this.eot = DFA80_eot;
            this.eof = DFA80_eof;
            this.min = DFA80_min;
            this.max = DFA80_max;
            this.accept = DFA80_accept;
            this.special = DFA80_special;
            this.transition = DFA80_transition;
        }
        public String getDescription() {
            return "142:7: ( simpleStatement )?";
        }
    }
    static final String DFA98_eotS =
        "\22\uffff";
    static final String DFA98_eofS =
        "\22\uffff";
    static final String DFA98_minS =
        "\1\6\21\uffff";
    static final String DFA98_maxS =
        "\1\146\21\uffff";
    static final String DFA98_acceptS =
        "\1\uffff\1\1\17\uffff\1\2";
    static final String DFA98_specialS =
        "\22\uffff}>";
    static final String[] DFA98_transitionS = {
            "\1\1\1\21\11\uffff\1\1\1\uffff\1\1\2\uffff\1\1\1\uffff\1\1\1"+
            "\uffff\1\1\3\uffff\1\1\1\uffff\2\1\65\uffff\1\1\1\uffff\1\1"+
            "\6\uffff\7\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA98_eot = DFA.unpackEncodedString(DFA98_eotS);
    static final short[] DFA98_eof = DFA.unpackEncodedString(DFA98_eofS);
    static final char[] DFA98_min = DFA.unpackEncodedStringToUnsignedChars(DFA98_minS);
    static final char[] DFA98_max = DFA.unpackEncodedStringToUnsignedChars(DFA98_maxS);
    static final short[] DFA98_accept = DFA.unpackEncodedString(DFA98_acceptS);
    static final short[] DFA98_special = DFA.unpackEncodedString(DFA98_specialS);
    static final short[][] DFA98_transition;

    static {
        int numStates = DFA98_transitionS.length;
        DFA98_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA98_transition[i] = DFA.unpackEncodedString(DFA98_transitionS[i]);
        }
    }

    class DFA98 extends DFA {

        public DFA98(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 98;
            this.eot = DFA98_eot;
            this.eof = DFA98_eof;
            this.min = DFA98_min;
            this.max = DFA98_max;
            this.accept = DFA98_accept;
            this.special = DFA98_special;
            this.transition = DFA98_transition;
        }
        public String getDescription() {
            return "438:23: ( expression ( COMMA expression )* )?";
        }
    }
 

    public static final BitSet FOLLOW_statement_in_prog945 = new BitSet(new long[]{0x930FCF9F454A0442L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_simpleStatement_in_statement958 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_BodyString_in_statement961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_CURLY_BRACE_in_statement969 = new BitSet(new long[]{0x930FCF9F454A0C40L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_statement971 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_CLOSE_CURLY_BRACE_in_statement973 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_bracketedBlock_in_statement985 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_classDefinition_in_statement998 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_interfaceDefinition_in_statement1006 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_complexStatement_in_statement1014 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleStatement_in_statement1022 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_statement1024 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_CURLY_BRACE_in_bracketedBlock1050 = new BitSet(new long[]{0x930FCF9F454A0C40L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_bracketedBlock1052 = new BitSet(new long[]{0x930FCF9F454A0C40L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_CLOSE_CURLY_BRACE_in_bracketedBlock1055 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTERFACE_in_interfaceDefinition1081 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceDefinition1085 = new BitSet(new long[]{0x0400000000000400L});
    public static final BitSet FOLLOW_interfaceExtends_in_interfaceDefinition1087 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_OPEN_CURLY_BRACE_in_interfaceDefinition1098 = new BitSet(new long[]{0x5008400000000800L,0x0020000001000000L});
    public static final BitSet FOLLOW_interfaceMember_in_interfaceDefinition1108 = new BitSet(new long[]{0x5008400000000800L,0x0020000001000000L});
    public static final BitSet FOLLOW_CLOSE_CURLY_BRACE_in_interfaceDefinition1119 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Extends_in_interfaceExtends1159 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceExtends1162 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_COMMA_in_interfaceExtends1165 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceExtends1168 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_CONST_in_interfaceMember1186 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceMember1188 = new BitSet(new long[]{0x0000000080000010L});
    public static final BitSet FOLLOW_EQUALS_in_interfaceMember1191 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_interfaceMember1193 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_interfaceMember1197 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldModifier_in_interfaceMember1225 = new BitSet(new long[]{0x1008400000000000L,0x0020000001000000L});
    public static final BitSet FOLLOW_FUNCTION_in_interfaceMember1228 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceMember1230 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_parametersDefinition_in_interfaceMember1232 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_interfaceMember1234 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_classModifier_in_classDefinition1278 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_CLASS_in_classDefinition1290 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classDefinition1294 = new BitSet(new long[]{0x0C00000000000400L});
    public static final BitSet FOLLOW_Extends_in_classDefinition1306 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classDefinition1310 = new BitSet(new long[]{0x0800000000000400L});
    public static final BitSet FOLLOW_classImplements_in_classDefinition1323 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_OPEN_CURLY_BRACE_in_classDefinition1334 = new BitSet(new long[]{0x7008400000080800L,0x0020000001000000L});
    public static final BitSet FOLLOW_classMember_in_classDefinition1344 = new BitSet(new long[]{0x7008400000080800L,0x0020000001000000L});
    public static final BitSet FOLLOW_CLOSE_CURLY_BRACE_in_classDefinition1355 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IMPLEMENTS_in_classImplements1437 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classImplements1441 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_COMMA_in_classImplements1444 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classImplements1447 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_fieldModifier_in_classMember1467 = new BitSet(new long[]{0x1008400000000000L,0x0020000001000000L});
    public static final BitSet FOLLOW_FUNCTION_in_classMember1470 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember1472 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_parametersDefinition_in_classMember1474 = new BitSet(new long[]{0x0000000000000410L});
    public static final BitSet FOLLOW_bracketedBlock_in_classMember1486 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SEMICOLON_in_classMember1490 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VAR_in_classMember1527 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_DOLLAR_in_classMember1529 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember1531 = new BitSet(new long[]{0x0000000080000010L});
    public static final BitSet FOLLOW_EQUALS_in_classMember1534 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_classMember1536 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_classMember1540 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONST_in_classMember1573 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember1575 = new BitSet(new long[]{0x0000000080000010L});
    public static final BitSet FOLLOW_EQUALS_in_classMember1578 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_classMember1580 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_classMember1584 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldModifier_in_classMember1612 = new BitSet(new long[]{0x1008000000080000L,0x0020000001000000L});
    public static final BitSet FOLLOW_DOLLAR_in_classMember1616 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember1618 = new BitSet(new long[]{0x0000000080000010L});
    public static final BitSet FOLLOW_EQUALS_in_classMember1622 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_classMember1624 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_classMember1628 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_in_fieldDefinition1676 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_fieldDefinition1678 = new BitSet(new long[]{0x0000000080000010L});
    public static final BitSet FOLLOW_EQUALS_in_fieldDefinition1681 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_fieldDefinition1683 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_fieldDefinition1687 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ABSTRACT_in_classModifier1722 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_fieldModifier0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_in_complexStatement1768 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement1770 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_complexStatement1774 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement1776 = new BitSet(new long[]{0x930FCFFF454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_complexStatement1780 = new BitSet(new long[]{0x0000006000000002L});
    public static final BitSet FOLLOW_conditional_in_complexStatement1782 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOR_in_complexStatement1805 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement1807 = new BitSet(new long[]{0x000F800F454A0050L,0x0000007F06800000L});
    public static final BitSet FOLLOW_forInit_in_complexStatement1809 = new BitSet(new long[]{0x000F800F454A0050L,0x0000007F06800000L});
    public static final BitSet FOLLOW_forCondition_in_complexStatement1811 = new BitSet(new long[]{0x000F800F454A00C0L,0x0000007F06800000L});
    public static final BitSet FOLLOW_forUpdate_in_complexStatement1813 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement1815 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_complexStatement1817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOR_EACH_in_complexStatement1839 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement1841 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_variable_in_complexStatement1843 = new BitSet(new long[]{0x0000000000000000L,0x0040000000000000L});
    public static final BitSet FOLLOW_118_in_complexStatement1845 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_arrayEntry_in_complexStatement1847 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement1849 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_complexStatement1851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_in_complexStatement1871 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement1873 = new BitSet(new long[]{0x000F800F454A00C0L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_complexStatement1877 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement1880 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_complexStatement1882 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DO_in_complexStatement1901 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_complexStatement1903 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_WHILE_in_complexStatement1905 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement1907 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_complexStatement1911 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement1913 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_complexStatement1915 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SWITCH_in_complexStatement1934 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement1936 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_complexStatement1938 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement1940 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_OPEN_CURLY_BRACE_in_complexStatement1942 = new BitSet(new long[]{0x0000300000000000L});
    public static final BitSet FOLLOW_cases_in_complexStatement1943 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_CLOSE_CURLY_BRACE_in_complexStatement1944 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_TRY_in_complexStatement1962 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000FL});
    public static final BitSet FOLLOW_statement_in_complexStatement1964 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000FL});
    public static final BitSet FOLLOW_catchStatement_in_complexStatement1966 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_THROW_in_complexStatement1984 = new BitSet(new long[]{0x0000000100080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_throwException_in_complexStatement1986 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_complexStatement1988 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DECLARE_in_complexStatement2004 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_complexStatement2006 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_declareList_in_complexStatement2008 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_complexStatement2010 = new BitSet(new long[]{0x930FCF9F454A0450L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_SEMICOLON_in_complexStatement2013 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_complexStatement2017 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_USE_in_complexStatement2037 = new BitSet(new long[]{0x0000000000000040L,0x0000007E02000000L});
    public static final BitSet FOLLOW_useFilename_in_complexStatement2039 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_complexStatement2041 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionDefinition_in_complexStatement2057 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ECHO_in_simpleStatement2074 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_commaList_in_simpleStatement2077 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRINT_in_simpleStatement2085 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_commaList_in_simpleStatement2088 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_GLOBAL_in_simpleStatement2096 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_name_in_simpleStatement2099 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_COMMA_in_simpleStatement2102 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_name_in_simpleStatement2105 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_STATIC_in_simpleStatement2115 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_variable_in_simpleStatement2118 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_EQUALS_in_simpleStatement2120 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_simpleStatement2123 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BREAK_in_simpleStatement2136 = new BitSet(new long[]{0x0000000000000002L,0x0000000002000000L});
    public static final BitSet FOLLOW_Integer_in_simpleStatement2139 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONTINUE_in_simpleStatement2148 = new BitSet(new long[]{0x0000000000000002L,0x0000000002000000L});
    public static final BitSet FOLLOW_Integer_in_simpleStatement2151 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RETURN_in_simpleStatement2165 = new BitSet(new long[]{0x000F800F454A0042L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_simpleStatement2168 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RequireOperator_in_simpleStatement2177 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_simpleStatement2180 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_simpleStatement2188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSE_IF_in_conditional2206 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_conditional2208 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_conditional2212 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_conditional2214 = new BitSet(new long[]{0x930FCFFF454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_conditional2218 = new BitSet(new long[]{0x0000006000000002L});
    public static final BitSet FOLLOW_conditional_in_conditional2220 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSE_in_conditional2244 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_conditional2246 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_commaList_in_forInit2267 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_forInit2270 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_commaList_in_forCondition2296 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_SEMICOLON_in_forCondition2299 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_commaList_in_forUpdate2329 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_casestatement_in_cases2357 = new BitSet(new long[]{0x0000300000000000L});
    public static final BitSet FOLLOW_defaultcase_in_cases2361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_in_casestatement2378 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_casestatement2381 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_COLON_in_casestatement2383 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_casestatement2386 = new BitSet(new long[]{0x930FCF9F454A0442L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_DEFAULT_in_defaultcase2406 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_COLON_in_defaultcase2409 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_defaultcase2412 = new BitSet(new long[]{0x930FCF9F454A0442L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_CATCH_in_catchStatement2431 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_catchStatement2433 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_catchException_in_catchStatement2435 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_catchStatement2437 = new BitSet(new long[]{0x930FCF9F454A0440L,0x0000007F06C0000FL});
    public static final BitSet FOLLOW_statement_in_catchStatement2439 = new BitSet(new long[]{0x930FCF9F454A0442L,0x0000007F06C0000FL});
    public static final BitSet FOLLOW_catchStatement_in_catchStatement2441 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UnquotedString_in_catchException2472 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_variable_in_catchException2474 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEW_in_throwException2491 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_throwException2493 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_throwException2495 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_throwException2497 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_throwException2499 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_throwException2517 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_commaList_in_declareList2534 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_in_useFilename2559 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_useFilename2567 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_useFilename2569 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_useFilename2571 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_functionDefinition2588 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_functionDefinition2590 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_parametersDefinition_in_functionDefinition2592 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_bracketedBlock_in_functionDefinition2594 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_parametersDefinition2632 = new BitSet(new long[]{0x0000000000480080L});
    public static final BitSet FOLLOW_paramDef_in_parametersDefinition2635 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_COMMA_in_parametersDefinition2638 = new BitSet(new long[]{0x0000000000480000L});
    public static final BitSet FOLLOW_paramDef_in_parametersDefinition2640 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_parametersDefinition2646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_paramName_in_paramDef2673 = new BitSet(new long[]{0x0000000080000002L});
    public static final BitSet FOLLOW_EQUALS_in_paramDef2676 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_paramDef2679 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_in_paramName2698 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_paramName2701 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AMPERSAND_in_paramName2709 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_DOLLAR_in_paramName2711 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_paramName2713 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_commaList2742 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_COMMA_in_commaList2745 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_commaList2748 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_weakLogicalOr_in_expression2772 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_weakLogicalXor_in_weakLogicalOr2789 = new BitSet(new long[]{0x0020000000000002L});
    public static final BitSet FOLLOW_OR_in_weakLogicalOr2792 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_weakLogicalXor_in_weakLogicalOr2795 = new BitSet(new long[]{0x0020000000000002L});
    public static final BitSet FOLLOW_weakLogicalAnd_in_weakLogicalXor2814 = new BitSet(new long[]{0x0040000000000002L});
    public static final BitSet FOLLOW_XOR_in_weakLogicalXor2817 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_weakLogicalAnd_in_weakLogicalXor2820 = new BitSet(new long[]{0x0040000000000002L});
    public static final BitSet FOLLOW_assignment_in_weakLogicalAnd2843 = new BitSet(new long[]{0x0010000000000002L});
    public static final BitSet FOLLOW_AND_in_weakLogicalAnd2846 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_assignment_in_weakLogicalAnd2849 = new BitSet(new long[]{0x0010000000000002L});
    public static final BitSet FOLLOW_name_in_assignment2868 = new BitSet(new long[]{0x0000000080000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_set_in_assignment2871 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_assignment_in_assignment2880 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ternary_in_assignment2889 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalOr_in_ternary2906 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_QUESTION_MARK_in_ternary2908 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_ternary2910 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_COLON_in_ternary2912 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_ternary2914 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalOr_in_ternary2933 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalAnd_in_logicalOr2954 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_LOGICAL_OR_in_logicalOr2957 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_logicalAnd_in_logicalOr2960 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_bitwiseOr_in_logicalAnd2979 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_LOGICAL_AND_in_logicalAnd2982 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_bitwiseOr_in_logicalAnd2985 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_bitWiseAnd_in_bitwiseOr3008 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_PIPE_in_bitwiseOr3011 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_bitWiseAnd_in_bitwiseOr3014 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_equalityCheck_in_bitWiseAnd3033 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_AMPERSAND_in_bitWiseAnd3036 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_equalityCheck_in_bitWiseAnd3039 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_comparisionCheck_in_equalityCheck3058 = new BitSet(new long[]{0x0000000000000002L,0x0000000010000000L});
    public static final BitSet FOLLOW_EqualityOperator_in_equalityCheck3061 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_comparisionCheck_in_equalityCheck3064 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_bitWiseShift_in_comparisionCheck3087 = new BitSet(new long[]{0x0000000000000002L,0x0000000020000000L});
    public static final BitSet FOLLOW_ComparisionOperator_in_comparisionCheck3090 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_bitWiseShift_in_comparisionCheck3093 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_addition_in_bitWiseShift3112 = new BitSet(new long[]{0x0000000000000002L,0x0000000040000000L});
    public static final BitSet FOLLOW_ShiftOperator_in_bitWiseShift3115 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_addition_in_bitWiseShift3118 = new BitSet(new long[]{0x0000000000000002L,0x0000000040000000L});
    public static final BitSet FOLLOW_multiplication_in_addition3141 = new BitSet(new long[]{0x0000000006200002L});
    public static final BitSet FOLLOW_set_in_addition3144 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_multiplication_in_addition3157 = new BitSet(new long[]{0x0000000006200002L});
    public static final BitSet FOLLOW_logicalNot_in_multiplication3176 = new BitSet(new long[]{0x0000000038000002L});
    public static final BitSet FOLLOW_set_in_multiplication3179 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_logicalNot_in_multiplication3192 = new BitSet(new long[]{0x0000000038000002L});
    public static final BitSet FOLLOW_BANG_in_logicalNot3211 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_logicalNot_in_logicalNot3214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_instanceOf_in_logicalNot3222 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_negateOrCast_in_instanceOf3239 = new BitSet(new long[]{0x0080000000000002L});
    public static final BitSet FOLLOW_INSTANCE_OF_in_instanceOf3242 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_negateOrCast_in_instanceOf3245 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_negateOrCast3264 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_increment_in_negateOrCast3277 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_negateOrCast3285 = new BitSet(new long[]{0x0000000000000000L,0x0000000080000000L});
    public static final BitSet FOLLOW_PrimitiveType_in_negateOrCast3287 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_negateOrCast3289 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_increment_in_negateOrCast3291 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_negateOrCast3309 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_weakLogicalAnd_in_negateOrCast3312 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_negateOrCast3314 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_increment_in_negateOrCast3323 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IncrementOperator_in_increment3340 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_name_in_increment3342 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_increment3360 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_IncrementOperator_in_increment3362 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_newOrClone_in_increment3380 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEW_in_newOrClone3397 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_nameOrFunctionCall_in_newOrClone3400 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLONE_in_newOrClone3408 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_name_in_newOrClone3411 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atomOrReference_in_newOrClone3419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_in_atomOrReference3436 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_in_atomOrReference3444 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Array_in_arrayDeclaration3461 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_arrayDeclaration3463 = new BitSet(new long[]{0x000F800F454A00C0L,0x0000007F06800000L});
    public static final BitSet FOLLOW_arrayEntry_in_arrayDeclaration3466 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_COMMA_in_arrayDeclaration3469 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_arrayEntry_in_arrayDeclaration3471 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_arrayDeclaration3477 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_keyValuePair_in_arrayEntry3504 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_arrayEntry3508 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_keyValuePair3527 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_ARRAY_ASSIGN_in_keyValuePair3529 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_keyValuePair3531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SingleQuotedString_in_atom3553 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DoubleQuotedString_in_atom3557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_HereDoc_in_atom3561 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Integer_in_atom3565 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Real_in_atom3569 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Boolean_in_atom3573 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_arrayDeclaration_in_atom3577 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AMPERSAND_in_reference3595 = new BitSet(new long[]{0x00000003454A0040L,0x0000007F02800000L});
    public static final BitSet FOLLOW_nameOrFunctionCall_in_reference3598 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_nameOrFunctionCall_in_reference3606 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_nameOrFunctionCall3623 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_nameOrFunctionCall3625 = new BitSet(new long[]{0x000F800F454A00C0L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_nameOrFunctionCall3628 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_COMMA_in_nameOrFunctionCall3631 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_nameOrFunctionCall3633 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_nameOrFunctionCall3639 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_nameOrFunctionCall3658 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_staticMemberAccess_in_name3670 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_memberAccess_in_name3678 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_name3686 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UnquotedString_in_staticMemberAccess3707 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_CLASS_MEMBER_in_staticMemberAccess3709 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_variable_in_staticMemberAccess3712 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_memberAccess3729 = new BitSet(new long[]{0x0000000000010102L});
    public static final BitSet FOLLOW_OPEN_SQUARE_BRACE_in_memberAccess3742 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_memberAccess3745 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_CLOSE_SQUARE_BRACE_in_memberAccess3747 = new BitSet(new long[]{0x0000000000010102L});
    public static final BitSet FOLLOW_INSTANCE_MEMBER_in_memberAccess3760 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_memberAccess3763 = new BitSet(new long[]{0x0000000000010102L});
    public static final BitSet FOLLOW_DOLLAR_in_variable3786 = new BitSet(new long[]{0x0000000000080000L,0x0000000000800000L});
    public static final BitSet FOLLOW_variable_in_variable3789 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UnquotedString_in_variable3797 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleStatement_in_synpred3_Php958 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_BodyString_in_synpred3_Php961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_CURLY_BRACE_in_synpred4_Php969 = new BitSet(new long[]{0x930FCF9F454A0C40L,0x0000007F06C0000EL});
    public static final BitSet FOLLOW_statement_in_synpred4_Php971 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_CLOSE_CURLY_BRACE_in_synpred4_Php973 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_bracketedBlock_in_synpred5_Php985 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldModifier_in_synpred23_Php1467 = new BitSet(new long[]{0x1008400000000000L,0x0020000001000000L});
    public static final BitSet FOLLOW_FUNCTION_in_synpred23_Php1470 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_synpred23_Php1472 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_parametersDefinition_in_synpred23_Php1474 = new BitSet(new long[]{0x0000000000000410L});
    public static final BitSet FOLLOW_bracketedBlock_in_synpred23_Php1486 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SEMICOLON_in_synpred23_Php1490 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_conditional_in_synpred34_Php1782 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_conditional_in_synpred59_Php2220 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_catchStatement_in_synpred67_Php2441 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OR_in_synpred75_Php2792 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_weakLogicalXor_in_synpred75_Php2795 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_XOR_in_synpred76_Php2817 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_weakLogicalAnd_in_synpred76_Php2820 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AND_in_synpred77_Php2846 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_assignment_in_synpred77_Php2849 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_synpred79_Php2868 = new BitSet(new long[]{0x0000000080000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_set_in_synpred79_Php2871 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_assignment_in_synpred79_Php2880 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalOr_in_synpred80_Php2906 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_QUESTION_MARK_in_synpred80_Php2908 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_synpred80_Php2910 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_COLON_in_synpred80_Php2912 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_synpred80_Php2914 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_synpred102_Php3360 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_IncrementOperator_in_synpred102_Php3362 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_keyValuePair_in_synpred108_Php3504 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_synpred118_Php3623 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_OPEN_BRACE_in_synpred118_Php3625 = new BitSet(new long[]{0x000F800F454A00C0L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_synpred118_Php3628 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_COMMA_in_synpred118_Php3631 = new BitSet(new long[]{0x000F800F454A0040L,0x0000007F06800000L});
    public static final BitSet FOLLOW_expression_in_synpred118_Php3633 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_CLOSE_BRACE_in_synpred118_Php3639 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_memberAccess_in_synpred120_Php3678 = new BitSet(new long[]{0x0000000000000002L});

}
