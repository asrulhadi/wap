// $ANTLR 3.2 Sep 23, 2009 12:02:23 /home/iberiam/phpparser-1.2/grammar/PhpTree.g 2010-05-09 19:46:53

    package org.homeunix.awap.php.parser;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class PhpTree extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "SEMICOLON", "COMMA", "OPEN_BRACE", "CLOSE_BRACE", "OPEN_SQUARE_BRACE", "CLOSE_SQUARE_BRACE", "OPEN_CURLY_BRACE", "CLOSE_CURLY_BRACE", "ARRAY_ASSIGN", "LOGICAL_OR", "LOGICAL_AND", "CLASS_MEMBER", "INSTANCE_MEMBER", "SUPPRESS_WARNINGS", "QUESTION_MARK", "DOLLAR", "COLON", "DOT", "AMPERSAND", "PIPE", "BANG", "PLUS", "MINUS", "ASTERISK", "PERCENT", "FORWARD_SLASH", "TILDE", "EQUALS", "NEW", "CLONE", "ECHO", "PRINT", "IF", "ELSE", "ELSE_IF", "FOR", "FOR_EACH", "WHILE", "DO", "SWITCH", "CASE", "DEFAULT", "FUNCTION", "BREAK", "CONTINUE", "RETURN", "GLOBAL", "STATIC", "AND", "OR", "XOR", "INSTANCE_OF", "CLASS", "INTERFACE", "Extends", "IMPLEMENTS", "ABSTRACT", "VAR", "CONST", "TRY", "CATCH", "THROW", "DECLARE", "USE", "Modifiers", "ClassDefinition", "Block", "Params", "Apply", "Member", "Reference", "Prefix", "Postfix", "IfExpression", "Label", "Cast", "ForInit", "ForCondition", "ForUpdate", "DeclareList", "Field", "Method", "BodyString", "UnquotedString", "AccessModifier", "Integer", "RequireOperator", "AsignmentOperator", "EqualityOperator", "ComparisionOperator", "ShiftOperator", "PrimitiveType", "IncrementOperator", "Array", "SingleQuotedString", "DoubleQuotedString", "HereDoc", "Real", "Boolean", "FirstBodyString", "MultilineComment", "SinglelineComment", "UnixComment", "Decimal", "Hexadecimal", "Octal", "Digits", "DNum", "Exponent_DNum", "EscapeCharector", "HereDocContents", "Eol", "WhiteSpace", "'final'", "'as'"
    };
    public static final int FUNCTION=46;
    public static final int ARRAY_ASSIGN=12;
    public static final int Method=85;
    public static final int CLOSE_SQUARE_BRACE=9;
    public static final int ForCondition=81;
    public static final int WHILE=41;
    public static final int Array=97;
    public static final int CONST=62;
    public static final int CLONE=33;
    public static final int CASE=44;
    public static final int NEW=32;
    public static final int DO=42;
    public static final int EQUALS=31;
    public static final int Decimal=107;
    public static final int Extends=58;
    public static final int EOF=-1;
    public static final int BREAK=47;
    public static final int LOGICAL_AND=14;
    public static final int DoubleQuotedString=99;
    public static final int Digits=110;
    public static final int INSTANCE_OF=55;
    public static final int SUPPRESS_WARNINGS=17;
    public static final int RETURN=49;
    public static final int QUESTION_MARK=18;
    public static final int VAR=61;
    public static final int WhiteSpace=116;
    public static final int UnixComment=106;
    public static final int OPEN_CURLY_BRACE=10;
    public static final int CLOSE_CURLY_BRACE=11;
    public static final int Member=73;
    public static final int Hexadecimal=108;
    public static final int STATIC=51;
    public static final int SWITCH=43;
    public static final int ELSE=37;
    public static final int PrimitiveType=95;
    public static final int SEMICOLON=4;
    public static final int HereDoc=100;
    public static final int Apply=72;
    public static final int TRY=63;
    public static final int Block=70;
    public static final int ForUpdate=82;
    public static final int EscapeCharector=113;
    public static final int OR=53;
    public static final int BodyString=86;
    public static final int DNum=111;
    public static final int FirstBodyString=103;
    public static final int USE=67;
    public static final int CATCH=64;
    public static final int Params=71;
    public static final int Label=78;
    public static final int THROW=65;
    public static final int SingleQuotedString=98;
    public static final int DOLLAR=19;
    public static final int CLASS=56;
    public static final int T__118=118;
    public static final int CLASS_MEMBER=15;
    public static final int Modifiers=68;
    public static final int T__117=117;
    public static final int IfExpression=77;
    public static final int FOR=39;
    public static final int SinglelineComment=105;
    public static final int ABSTRACT=60;
    public static final int Cast=79;
    public static final int AND=52;
    public static final int DeclareList=83;
    public static final int ComparisionOperator=93;
    public static final int ASTERISK=27;
    public static final int IF=36;
    public static final int Exponent_DNum=112;
    public static final int IncrementOperator=96;
    public static final int IMPLEMENTS=59;
    public static final int ClassDefinition=69;
    public static final int CONTINUE=48;
    public static final int COMMA=5;
    public static final int Prefix=75;
    public static final int TILDE=30;
    public static final int LOGICAL_OR=13;
    public static final int Real=101;
    public static final int PLUS=25;
    public static final int PIPE=23;
    public static final int UnquotedString=87;
    public static final int DOT=21;
    public static final int INSTANCE_MEMBER=16;
    public static final int AsignmentOperator=91;
    public static final int Reference=74;
    public static final int ELSE_IF=38;
    public static final int Postfix=76;
    public static final int Field=84;
    public static final int XOR=54;
    public static final int PERCENT=28;
    public static final int ShiftOperator=94;
    public static final int AccessModifier=88;
    public static final int DEFAULT=45;
    public static final int AMPERSAND=22;
    public static final int BANG=24;
    public static final int CLOSE_BRACE=7;
    public static final int ForInit=80;
    public static final int MINUS=26;
    public static final int PRINT=35;
    public static final int OPEN_SQUARE_BRACE=8;
    public static final int Eol=115;
    public static final int RequireOperator=90;
    public static final int COLON=20;
    public static final int ECHO=34;
    public static final int Boolean=102;
    public static final int Octal=109;
    public static final int HereDocContents=114;
    public static final int DECLARE=66;
    public static final int INTERFACE=57;
    public static final int GLOBAL=50;
    public static final int EqualityOperator=92;
    public static final int MultilineComment=104;
    public static final int OPEN_BRACE=6;
    public static final int FOR_EACH=40;
    public static final int Integer=89;
    public static final int FORWARD_SLASH=29;

    // delegates
    // delegators


        public PhpTree(TreeNodeStream input) {
            this(input, new RecognizerSharedState());
        }
        public PhpTree(TreeNodeStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return PhpTree.tokenNames; }
    public String getGrammarFileName() { return "/home/iberiam/phpparser-1.2/grammar/PhpTree.g"; }


    public static class prog_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:13:1: prog : ( statement )* ;
    public final PhpTree.prog_return prog() throws RecognitionException {
        PhpTree.prog_return retval = new PhpTree.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        PhpTree.statement_return statement1 = null;



        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:13:6: ( ( statement )* )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:13:8: ( statement )*
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:13:8: ( statement )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==OPEN_SQUARE_BRACE||(LA1_0>=LOGICAL_OR && LA1_0<=SUPPRESS_WARNINGS)||LA1_0==DOLLAR||(LA1_0>=DOT && LA1_0<=IF)||(LA1_0>=FOR && LA1_0<=SWITCH)||(LA1_0>=FUNCTION && LA1_0<=INTERFACE)||LA1_0==TRY||(LA1_0>=THROW && LA1_0<=USE)||LA1_0==Block||LA1_0==Apply||(LA1_0>=Prefix && LA1_0<=IfExpression)||LA1_0==Cast||(LA1_0>=BodyString && LA1_0<=UnquotedString)||(LA1_0>=Integer && LA1_0<=ShiftOperator)||(LA1_0>=Array && LA1_0<=Boolean)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_statement_in_prog43);
            	    statement1=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_0, statement1.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class statement_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:15:1: statement : ( BodyString | ^( Block ( statement )* ) | classDefinition | interfaceDefinition | complexStatement | simpleStatement );
    public final PhpTree.statement_return statement() throws RecognitionException {
        PhpTree.statement_return retval = new PhpTree.statement_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree BodyString2=null;
        CommonTree Block3=null;
        PhpTree.statement_return statement4 = null;

        PhpTree.classDefinition_return classDefinition5 = null;

        PhpTree.interfaceDefinition_return interfaceDefinition6 = null;

        PhpTree.complexStatement_return complexStatement7 = null;

        PhpTree.simpleStatement_return simpleStatement8 = null;


        CommonTree BodyString2_tree=null;
        CommonTree Block3_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:16:5: ( BodyString | ^( Block ( statement )* ) | classDefinition | interfaceDefinition | complexStatement | simpleStatement )
            int alt3=6;
            switch ( input.LA(1) ) {
            case BodyString:
                {
                alt3=1;
                }
                break;
            case Block:
                {
                alt3=2;
                }
                break;
            case CLASS:
                {
                alt3=3;
                }
                break;
            case INTERFACE:
                {
                alt3=4;
                }
                break;
            case IF:
            case FOR:
            case FOR_EACH:
            case WHILE:
            case DO:
            case SWITCH:
            case FUNCTION:
            case TRY:
            case THROW:
            case DECLARE:
            case USE:
                {
                alt3=5;
                }
                break;
            case OPEN_SQUARE_BRACE:
            case LOGICAL_OR:
            case LOGICAL_AND:
            case CLASS_MEMBER:
            case INSTANCE_MEMBER:
            case SUPPRESS_WARNINGS:
            case DOLLAR:
            case DOT:
            case AMPERSAND:
            case PIPE:
            case BANG:
            case PLUS:
            case MINUS:
            case ASTERISK:
            case PERCENT:
            case FORWARD_SLASH:
            case TILDE:
            case EQUALS:
            case NEW:
            case CLONE:
            case ECHO:
            case PRINT:
            case BREAK:
            case CONTINUE:
            case RETURN:
            case GLOBAL:
            case STATIC:
            case AND:
            case OR:
            case XOR:
            case INSTANCE_OF:
            case Apply:
            case Prefix:
            case Postfix:
            case IfExpression:
            case Cast:
            case UnquotedString:
            case Integer:
            case RequireOperator:
            case AsignmentOperator:
            case EqualityOperator:
            case ComparisionOperator:
            case ShiftOperator:
            case Array:
            case SingleQuotedString:
            case DoubleQuotedString:
            case HereDoc:
            case Real:
            case Boolean:
                {
                alt3=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:16:7: BodyString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    BodyString2=(CommonTree)match(input,BodyString,FOLLOW_BodyString_in_statement56); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BodyString2_tree = (CommonTree)adaptor.dupNode(BodyString2);

                    adaptor.addChild(root_0, BodyString2_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:17:7: ^( Block ( statement )* )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Block3=(CommonTree)match(input,Block,FOLLOW_Block_in_statement65); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Block3_tree = (CommonTree)adaptor.dupNode(Block3);

                    root_1 = (CommonTree)adaptor.becomeRoot(Block3_tree, root_1);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:17:15: ( statement )*
                        loop2:
                        do {
                            int alt2=2;
                            int LA2_0 = input.LA(1);

                            if ( (LA2_0==OPEN_SQUARE_BRACE||(LA2_0>=LOGICAL_OR && LA2_0<=SUPPRESS_WARNINGS)||LA2_0==DOLLAR||(LA2_0>=DOT && LA2_0<=IF)||(LA2_0>=FOR && LA2_0<=SWITCH)||(LA2_0>=FUNCTION && LA2_0<=INTERFACE)||LA2_0==TRY||(LA2_0>=THROW && LA2_0<=USE)||LA2_0==Block||LA2_0==Apply||(LA2_0>=Prefix && LA2_0<=IfExpression)||LA2_0==Cast||(LA2_0>=BodyString && LA2_0<=UnquotedString)||(LA2_0>=Integer && LA2_0<=ShiftOperator)||(LA2_0>=Array && LA2_0<=Boolean)) ) {
                                alt2=1;
                            }


                            switch (alt2) {
                        	case 1 :
                        	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
                        	    {
                        	    _last = (CommonTree)input.LT(1);
                        	    pushFollow(FOLLOW_statement_in_statement67);
                        	    statement4=statement();

                        	    state._fsp--;
                        	    if (state.failed) return retval;
                        	    if ( state.backtracking==0 ) 
                        	    adaptor.addChild(root_1, statement4.getTree());

                        	    if ( state.backtracking==0 ) {
                        	    }
                        	    }
                        	    break;

                        	default :
                        	    break loop2;
                            }
                        } while (true);


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:19:7: classDefinition
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_classDefinition_in_statement82);
                    classDefinition5=classDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, classDefinition5.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:20:7: interfaceDefinition
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_interfaceDefinition_in_statement90);
                    interfaceDefinition6=interfaceDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, interfaceDefinition6.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:21:7: complexStatement
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_complexStatement_in_statement98);
                    complexStatement7=complexStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, complexStatement7.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:22:7: simpleStatement
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_simpleStatement_in_statement106);
                    simpleStatement8=simpleStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, simpleStatement8.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class interfaceDefinition_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "interfaceDefinition"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:25:1: interfaceDefinition : ^( INTERFACE UnquotedString ( interfaceExtends )? ( interfaceMember )* ) ;
    public final PhpTree.interfaceDefinition_return interfaceDefinition() throws RecognitionException {
        PhpTree.interfaceDefinition_return retval = new PhpTree.interfaceDefinition_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree INTERFACE9=null;
        CommonTree UnquotedString10=null;
        PhpTree.interfaceExtends_return interfaceExtends11 = null;

        PhpTree.interfaceMember_return interfaceMember12 = null;


        CommonTree INTERFACE9_tree=null;
        CommonTree UnquotedString10_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:26:5: ( ^( INTERFACE UnquotedString ( interfaceExtends )? ( interfaceMember )* ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:26:7: ^( INTERFACE UnquotedString ( interfaceExtends )? ( interfaceMember )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            INTERFACE9=(CommonTree)match(input,INTERFACE,FOLLOW_INTERFACE_in_interfaceDefinition124); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            INTERFACE9_tree = (CommonTree)adaptor.dupNode(INTERFACE9);

            root_1 = (CommonTree)adaptor.becomeRoot(INTERFACE9_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            UnquotedString10=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceDefinition126); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString10_tree = (CommonTree)adaptor.dupNode(UnquotedString10);

            adaptor.addChild(root_1, UnquotedString10_tree);
            }
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:26:34: ( interfaceExtends )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==Extends) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: interfaceExtends
                    {
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_interfaceExtends_in_interfaceDefinition128);
                    interfaceExtends11=interfaceExtends();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, interfaceExtends11.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:26:52: ( interfaceMember )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==CONST||LA5_0==Method) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: interfaceMember
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_interfaceMember_in_interfaceDefinition131);
            	    interfaceMember12=interfaceMember();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, interfaceMember12.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "interfaceDefinition"

    public static class interfaceExtends_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "interfaceExtends"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:29:1: interfaceExtends : Extends ( UnquotedString )+ ;
    public final PhpTree.interfaceExtends_return interfaceExtends() throws RecognitionException {
        PhpTree.interfaceExtends_return retval = new PhpTree.interfaceExtends_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree Extends13=null;
        CommonTree UnquotedString14=null;

        CommonTree Extends13_tree=null;
        CommonTree UnquotedString14_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:30:5: ( Extends ( UnquotedString )+ )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:30:7: Extends ( UnquotedString )+
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            Extends13=(CommonTree)match(input,Extends,FOLLOW_Extends_in_interfaceExtends150); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Extends13_tree = (CommonTree)adaptor.dupNode(Extends13);

            root_0 = (CommonTree)adaptor.becomeRoot(Extends13_tree, root_0);
            }
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:30:16: ( UnquotedString )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==UnquotedString) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: UnquotedString
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    UnquotedString14=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceExtends153); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    UnquotedString14_tree = (CommonTree)adaptor.dupNode(UnquotedString14);

            	    adaptor.addChild(root_0, UnquotedString14_tree);
            	    }

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "interfaceExtends"

    public static class interfaceMember_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "interfaceMember"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:32:1: interfaceMember : ( ^( CONST UnquotedString ( atom )? ) | ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString ^( Params ( paramDef )* ) ) );
    public final PhpTree.interfaceMember_return interfaceMember() throws RecognitionException {
        PhpTree.interfaceMember_return retval = new PhpTree.interfaceMember_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree CONST15=null;
        CommonTree UnquotedString16=null;
        CommonTree Method18=null;
        CommonTree Modifiers19=null;
        CommonTree UnquotedString21=null;
        CommonTree Params22=null;
        PhpTree.atom_return atom17 = null;

        PhpTree.fieldModifier_return fieldModifier20 = null;

        PhpTree.paramDef_return paramDef23 = null;


        CommonTree CONST15_tree=null;
        CommonTree UnquotedString16_tree=null;
        CommonTree Method18_tree=null;
        CommonTree Modifiers19_tree=null;
        CommonTree UnquotedString21_tree=null;
        CommonTree Params22_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:33:5: ( ^( CONST UnquotedString ( atom )? ) | ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString ^( Params ( paramDef )* ) ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==CONST) ) {
                alt10=1;
            }
            else if ( (LA10_0==Method) ) {
                alt10=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:33:7: ^( CONST UnquotedString ( atom )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    CONST15=(CommonTree)match(input,CONST,FOLLOW_CONST_in_interfaceMember171); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CONST15_tree = (CommonTree)adaptor.dupNode(CONST15);

                    root_1 = (CommonTree)adaptor.becomeRoot(CONST15_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString16=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceMember173); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString16_tree = (CommonTree)adaptor.dupNode(UnquotedString16);

                    adaptor.addChild(root_1, UnquotedString16_tree);
                    }
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:33:30: ( atom )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==Integer||(LA7_0>=Array && LA7_0<=Boolean)) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: atom
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_atom_in_interfaceMember175);
                            atom17=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, atom17.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:34:7: ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString ^( Params ( paramDef )* ) )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Method18=(CommonTree)match(input,Method,FOLLOW_Method_in_interfaceMember186); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Method18_tree = (CommonTree)adaptor.dupNode(Method18);

                    root_1 = (CommonTree)adaptor.becomeRoot(Method18_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Modifiers19=(CommonTree)match(input,Modifiers,FOLLOW_Modifiers_in_interfaceMember189); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Modifiers19_tree = (CommonTree)adaptor.dupNode(Modifiers19);

                    root_2 = (CommonTree)adaptor.becomeRoot(Modifiers19_tree, root_2);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:34:28: ( fieldModifier )*
                        loop8:
                        do {
                            int alt8=2;
                            int LA8_0 = input.LA(1);

                            if ( (LA8_0==STATIC||LA8_0==ABSTRACT||LA8_0==AccessModifier||LA8_0==117) ) {
                                alt8=1;
                            }


                            switch (alt8) {
                        	case 1 :
                        	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: fieldModifier
                        	    {
                        	    _last = (CommonTree)input.LT(1);
                        	    pushFollow(FOLLOW_fieldModifier_in_interfaceMember191);
                        	    fieldModifier20=fieldModifier();

                        	    state._fsp--;
                        	    if (state.failed) return retval;
                        	    if ( state.backtracking==0 ) 
                        	    adaptor.addChild(root_2, fieldModifier20.getTree());

                        	    if ( state.backtracking==0 ) {
                        	    }
                        	    }
                        	    break;

                        	default :
                        	    break loop8;
                            }
                        } while (true);


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (CommonTree)input.LT(1);
                    UnquotedString21=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_interfaceMember195); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString21_tree = (CommonTree)adaptor.dupNode(UnquotedString21);

                    adaptor.addChild(root_1, UnquotedString21_tree);
                    }
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Params22=(CommonTree)match(input,Params,FOLLOW_Params_in_interfaceMember198); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Params22_tree = (CommonTree)adaptor.dupNode(Params22);

                    root_2 = (CommonTree)adaptor.becomeRoot(Params22_tree, root_2);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:34:68: ( paramDef )*
                        loop9:
                        do {
                            int alt9=2;
                            int LA9_0 = input.LA(1);

                            if ( (LA9_0==DOLLAR||LA9_0==AMPERSAND||LA9_0==EQUALS) ) {
                                alt9=1;
                            }


                            switch (alt9) {
                        	case 1 :
                        	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: paramDef
                        	    {
                        	    _last = (CommonTree)input.LT(1);
                        	    pushFollow(FOLLOW_paramDef_in_interfaceMember200);
                        	    paramDef23=paramDef();

                        	    state._fsp--;
                        	    if (state.failed) return retval;
                        	    if ( state.backtracking==0 ) 
                        	    adaptor.addChild(root_2, paramDef23.getTree());

                        	    if ( state.backtracking==0 ) {
                        	    }
                        	    }
                        	    break;

                        	default :
                        	    break loop9;
                            }
                        } while (true);


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "interfaceMember"

    public static class classDefinition_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classDefinition"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:37:1: classDefinition : ^( CLASS ^( Modifiers ( classModifier )? ) UnquotedString ( ^( Extends UnquotedString ) )? ( classImplements )? ( classMember )* ) ;
    public final PhpTree.classDefinition_return classDefinition() throws RecognitionException {
        PhpTree.classDefinition_return retval = new PhpTree.classDefinition_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree CLASS24=null;
        CommonTree Modifiers25=null;
        CommonTree UnquotedString27=null;
        CommonTree Extends28=null;
        CommonTree UnquotedString29=null;
        PhpTree.classModifier_return classModifier26 = null;

        PhpTree.classImplements_return classImplements30 = null;

        PhpTree.classMember_return classMember31 = null;


        CommonTree CLASS24_tree=null;
        CommonTree Modifiers25_tree=null;
        CommonTree UnquotedString27_tree=null;
        CommonTree Extends28_tree=null;
        CommonTree UnquotedString29_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:5: ( ^( CLASS ^( Modifiers ( classModifier )? ) UnquotedString ( ^( Extends UnquotedString ) )? ( classImplements )? ( classMember )* ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:9: ^( CLASS ^( Modifiers ( classModifier )? ) UnquotedString ( ^( Extends UnquotedString ) )? ( classImplements )? ( classMember )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            CLASS24=(CommonTree)match(input,CLASS,FOLLOW_CLASS_in_classDefinition223); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            CLASS24_tree = (CommonTree)adaptor.dupNode(CLASS24);

            root_1 = (CommonTree)adaptor.becomeRoot(CLASS24_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_2 = _last;
            CommonTree _first_2 = null;
            CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            Modifiers25=(CommonTree)match(input,Modifiers,FOLLOW_Modifiers_in_classDefinition226); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Modifiers25_tree = (CommonTree)adaptor.dupNode(Modifiers25);

            root_2 = (CommonTree)adaptor.becomeRoot(Modifiers25_tree, root_2);
            }


            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:29: ( classModifier )?
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==ABSTRACT) ) {
                    alt11=1;
                }
                switch (alt11) {
                    case 1 :
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: classModifier
                        {
                        _last = (CommonTree)input.LT(1);
                        pushFollow(FOLLOW_classModifier_in_classDefinition228);
                        classModifier26=classModifier();

                        state._fsp--;
                        if (state.failed) return retval;
                        if ( state.backtracking==0 ) 
                        adaptor.addChild(root_2, classModifier26.getTree());

                        if ( state.backtracking==0 ) {
                        }
                        }
                        break;

                }


                match(input, Token.UP, null); if (state.failed) return retval;
            }adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            _last = (CommonTree)input.LT(1);
            UnquotedString27=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classDefinition232); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString27_tree = (CommonTree)adaptor.dupNode(UnquotedString27);

            adaptor.addChild(root_1, UnquotedString27_tree);
            }
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:60: ( ^( Extends UnquotedString ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==Extends) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:61: ^( Extends UnquotedString )
                    {
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Extends28=(CommonTree)match(input,Extends,FOLLOW_Extends_in_classDefinition236); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Extends28_tree = (CommonTree)adaptor.dupNode(Extends28);

                    root_2 = (CommonTree)adaptor.becomeRoot(Extends28_tree, root_2);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString29=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classDefinition238); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString29_tree = (CommonTree)adaptor.dupNode(UnquotedString29);

                    adaptor.addChild(root_2, UnquotedString29_tree);
                    }

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:89: ( classImplements )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==IMPLEMENTS) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: classImplements
                    {
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_classImplements_in_classDefinition243);
                    classImplements30=classImplements();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, classImplements30.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:38:106: ( classMember )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>=VAR && LA14_0<=CONST)||(LA14_0>=Field && LA14_0<=Method)) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: classMember
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_classMember_in_classDefinition246);
            	    classMember31=classMember();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, classMember31.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "classDefinition"

    public static class classImplements_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classImplements"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:41:1: classImplements : ^( IMPLEMENTS ( UnquotedString )+ ) ;
    public final PhpTree.classImplements_return classImplements() throws RecognitionException {
        PhpTree.classImplements_return retval = new PhpTree.classImplements_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree IMPLEMENTS32=null;
        CommonTree UnquotedString33=null;

        CommonTree IMPLEMENTS32_tree=null;
        CommonTree UnquotedString33_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:42:5: ( ^( IMPLEMENTS ( UnquotedString )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:42:8: ^( IMPLEMENTS ( UnquotedString )+ )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            IMPLEMENTS32=(CommonTree)match(input,IMPLEMENTS,FOLLOW_IMPLEMENTS_in_classImplements271); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            IMPLEMENTS32_tree = (CommonTree)adaptor.dupNode(IMPLEMENTS32);

            root_1 = (CommonTree)adaptor.becomeRoot(IMPLEMENTS32_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:42:21: ( UnquotedString )+
            int cnt15=0;
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==UnquotedString) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: UnquotedString
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    UnquotedString33=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classImplements273); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    UnquotedString33_tree = (CommonTree)adaptor.dupNode(UnquotedString33);

            	    adaptor.addChild(root_1, UnquotedString33_tree);
            	    }

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "classImplements"

    public static class classMember_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classMember"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:45:1: classMember : ( ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString ^( Params ( paramDef )* ) ( statementBlock )? ) | ^( VAR ^( DOLLAR UnquotedString ) ( atom )? ) | ^( CONST UnquotedString ( atom )? ) | ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? ) );
    public final PhpTree.classMember_return classMember() throws RecognitionException {
        PhpTree.classMember_return retval = new PhpTree.classMember_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree Method34=null;
        CommonTree Modifiers35=null;
        CommonTree UnquotedString37=null;
        CommonTree Params38=null;
        CommonTree VAR41=null;
        CommonTree DOLLAR42=null;
        CommonTree UnquotedString43=null;
        CommonTree CONST45=null;
        CommonTree UnquotedString46=null;
        CommonTree Field48=null;
        CommonTree Modifiers49=null;
        CommonTree DOLLAR51=null;
        CommonTree UnquotedString52=null;
        PhpTree.fieldModifier_return fieldModifier36 = null;

        PhpTree.paramDef_return paramDef39 = null;

        PhpTree.statementBlock_return statementBlock40 = null;

        PhpTree.atom_return atom44 = null;

        PhpTree.atom_return atom47 = null;

        PhpTree.fieldModifier_return fieldModifier50 = null;

        PhpTree.atom_return atom53 = null;


        CommonTree Method34_tree=null;
        CommonTree Modifiers35_tree=null;
        CommonTree UnquotedString37_tree=null;
        CommonTree Params38_tree=null;
        CommonTree VAR41_tree=null;
        CommonTree DOLLAR42_tree=null;
        CommonTree UnquotedString43_tree=null;
        CommonTree CONST45_tree=null;
        CommonTree UnquotedString46_tree=null;
        CommonTree Field48_tree=null;
        CommonTree Modifiers49_tree=null;
        CommonTree DOLLAR51_tree=null;
        CommonTree UnquotedString52_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:46:5: ( ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString ^( Params ( paramDef )* ) ( statementBlock )? ) | ^( VAR ^( DOLLAR UnquotedString ) ( atom )? ) | ^( CONST UnquotedString ( atom )? ) | ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? ) )
            int alt23=4;
            switch ( input.LA(1) ) {
            case Method:
                {
                alt23=1;
                }
                break;
            case VAR:
                {
                alt23=2;
                }
                break;
            case CONST:
                {
                alt23=3;
                }
                break;
            case Field:
                {
                alt23=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:46:7: ^( Method ^( Modifiers ( fieldModifier )* ) UnquotedString ^( Params ( paramDef )* ) ( statementBlock )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Method34=(CommonTree)match(input,Method,FOLLOW_Method_in_classMember293); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Method34_tree = (CommonTree)adaptor.dupNode(Method34);

                    root_1 = (CommonTree)adaptor.becomeRoot(Method34_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Modifiers35=(CommonTree)match(input,Modifiers,FOLLOW_Modifiers_in_classMember296); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Modifiers35_tree = (CommonTree)adaptor.dupNode(Modifiers35);

                    root_2 = (CommonTree)adaptor.becomeRoot(Modifiers35_tree, root_2);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:46:28: ( fieldModifier )*
                        loop16:
                        do {
                            int alt16=2;
                            int LA16_0 = input.LA(1);

                            if ( (LA16_0==STATIC||LA16_0==ABSTRACT||LA16_0==AccessModifier||LA16_0==117) ) {
                                alt16=1;
                            }


                            switch (alt16) {
                        	case 1 :
                        	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: fieldModifier
                        	    {
                        	    _last = (CommonTree)input.LT(1);
                        	    pushFollow(FOLLOW_fieldModifier_in_classMember298);
                        	    fieldModifier36=fieldModifier();

                        	    state._fsp--;
                        	    if (state.failed) return retval;
                        	    if ( state.backtracking==0 ) 
                        	    adaptor.addChild(root_2, fieldModifier36.getTree());

                        	    if ( state.backtracking==0 ) {
                        	    }
                        	    }
                        	    break;

                        	default :
                        	    break loop16;
                            }
                        } while (true);


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (CommonTree)input.LT(1);
                    UnquotedString37=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember302); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString37_tree = (CommonTree)adaptor.dupNode(UnquotedString37);

                    adaptor.addChild(root_1, UnquotedString37_tree);
                    }
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Params38=(CommonTree)match(input,Params,FOLLOW_Params_in_classMember305); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Params38_tree = (CommonTree)adaptor.dupNode(Params38);

                    root_2 = (CommonTree)adaptor.becomeRoot(Params38_tree, root_2);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:46:68: ( paramDef )*
                        loop17:
                        do {
                            int alt17=2;
                            int LA17_0 = input.LA(1);

                            if ( (LA17_0==DOLLAR||LA17_0==AMPERSAND||LA17_0==EQUALS) ) {
                                alt17=1;
                            }


                            switch (alt17) {
                        	case 1 :
                        	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: paramDef
                        	    {
                        	    _last = (CommonTree)input.LT(1);
                        	    pushFollow(FOLLOW_paramDef_in_classMember307);
                        	    paramDef39=paramDef();

                        	    state._fsp--;
                        	    if (state.failed) return retval;
                        	    if ( state.backtracking==0 ) 
                        	    adaptor.addChild(root_2, paramDef39.getTree());

                        	    if ( state.backtracking==0 ) {
                        	    }
                        	    }
                        	    break;

                        	default :
                        	    break loop17;
                            }
                        } while (true);


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:46:79: ( statementBlock )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==Block) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statementBlock
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_statementBlock_in_classMember311);
                            statementBlock40=statementBlock();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, statementBlock40.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:47:7: ^( VAR ^( DOLLAR UnquotedString ) ( atom )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    VAR41=(CommonTree)match(input,VAR,FOLLOW_VAR_in_classMember322); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    VAR41_tree = (CommonTree)adaptor.dupNode(VAR41);

                    root_1 = (CommonTree)adaptor.becomeRoot(VAR41_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DOLLAR42=(CommonTree)match(input,DOLLAR,FOLLOW_DOLLAR_in_classMember325); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR42_tree = (CommonTree)adaptor.dupNode(DOLLAR42);

                    root_2 = (CommonTree)adaptor.becomeRoot(DOLLAR42_tree, root_2);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString43=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember327); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString43_tree = (CommonTree)adaptor.dupNode(UnquotedString43);

                    adaptor.addChild(root_2, UnquotedString43_tree);
                    }

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:47:38: ( atom )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==Integer||(LA19_0>=Array && LA19_0<=Boolean)) ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: atom
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_atom_in_classMember330);
                            atom44=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, atom44.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:48:7: ^( CONST UnquotedString ( atom )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    CONST45=(CommonTree)match(input,CONST,FOLLOW_CONST_in_classMember342); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CONST45_tree = (CommonTree)adaptor.dupNode(CONST45);

                    root_1 = (CommonTree)adaptor.becomeRoot(CONST45_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString46=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember344); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString46_tree = (CommonTree)adaptor.dupNode(UnquotedString46);

                    adaptor.addChild(root_1, UnquotedString46_tree);
                    }
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:48:30: ( atom )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==Integer||(LA20_0>=Array && LA20_0<=Boolean)) ) {
                        alt20=1;
                    }
                    switch (alt20) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: atom
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_atom_in_classMember346);
                            atom47=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, atom47.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:49:7: ^( Field ^( Modifiers ( fieldModifier )* ) ^( DOLLAR UnquotedString ) ( atom )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Field48=(CommonTree)match(input,Field,FOLLOW_Field_in_classMember357); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Field48_tree = (CommonTree)adaptor.dupNode(Field48);

                    root_1 = (CommonTree)adaptor.becomeRoot(Field48_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Modifiers49=(CommonTree)match(input,Modifiers,FOLLOW_Modifiers_in_classMember360); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Modifiers49_tree = (CommonTree)adaptor.dupNode(Modifiers49);

                    root_2 = (CommonTree)adaptor.becomeRoot(Modifiers49_tree, root_2);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:49:27: ( fieldModifier )*
                        loop21:
                        do {
                            int alt21=2;
                            int LA21_0 = input.LA(1);

                            if ( (LA21_0==STATIC||LA21_0==ABSTRACT||LA21_0==AccessModifier||LA21_0==117) ) {
                                alt21=1;
                            }


                            switch (alt21) {
                        	case 1 :
                        	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: fieldModifier
                        	    {
                        	    _last = (CommonTree)input.LT(1);
                        	    pushFollow(FOLLOW_fieldModifier_in_classMember362);
                        	    fieldModifier50=fieldModifier();

                        	    state._fsp--;
                        	    if (state.failed) return retval;
                        	    if ( state.backtracking==0 ) 
                        	    adaptor.addChild(root_2, fieldModifier50.getTree());

                        	    if ( state.backtracking==0 ) {
                        	    }
                        	    }
                        	    break;

                        	default :
                        	    break loop21;
                            }
                        } while (true);


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DOLLAR51=(CommonTree)match(input,DOLLAR,FOLLOW_DOLLAR_in_classMember367); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR51_tree = (CommonTree)adaptor.dupNode(DOLLAR51);

                    root_2 = (CommonTree)adaptor.becomeRoot(DOLLAR51_tree, root_2);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString52=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_classMember369); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString52_tree = (CommonTree)adaptor.dupNode(UnquotedString52);

                    adaptor.addChild(root_2, UnquotedString52_tree);
                    }

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }

                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:49:68: ( atom )?
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==Integer||(LA22_0>=Array && LA22_0<=Boolean)) ) {
                        alt22=1;
                    }
                    switch (alt22) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: atom
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_atom_in_classMember372);
                            atom53=atom();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, atom53.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "classMember"

    public static class statementBlock_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statementBlock"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:52:1: statementBlock : ^( Block ( statement )* ) ;
    public final PhpTree.statementBlock_return statementBlock() throws RecognitionException {
        PhpTree.statementBlock_return retval = new PhpTree.statementBlock_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree Block54=null;
        PhpTree.statement_return statement55 = null;


        CommonTree Block54_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:53:5: ( ^( Block ( statement )* ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:53:7: ^( Block ( statement )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            Block54=(CommonTree)match(input,Block,FOLLOW_Block_in_statementBlock396); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Block54_tree = (CommonTree)adaptor.dupNode(Block54);

            root_1 = (CommonTree)adaptor.becomeRoot(Block54_tree, root_1);
            }


            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:53:15: ( statement )*
                loop24:
                do {
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==OPEN_SQUARE_BRACE||(LA24_0>=LOGICAL_OR && LA24_0<=SUPPRESS_WARNINGS)||LA24_0==DOLLAR||(LA24_0>=DOT && LA24_0<=IF)||(LA24_0>=FOR && LA24_0<=SWITCH)||(LA24_0>=FUNCTION && LA24_0<=INTERFACE)||LA24_0==TRY||(LA24_0>=THROW && LA24_0<=USE)||LA24_0==Block||LA24_0==Apply||(LA24_0>=Prefix && LA24_0<=IfExpression)||LA24_0==Cast||(LA24_0>=BodyString && LA24_0<=UnquotedString)||(LA24_0>=Integer && LA24_0<=ShiftOperator)||(LA24_0>=Array && LA24_0<=Boolean)) ) {
                        alt24=1;
                    }


                    switch (alt24) {
                	case 1 :
                	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
                	    {
                	    _last = (CommonTree)input.LT(1);
                	    pushFollow(FOLLOW_statement_in_statementBlock398);
                	    statement55=statement();

                	    state._fsp--;
                	    if (state.failed) return retval;
                	    if ( state.backtracking==0 ) 
                	    adaptor.addChild(root_1, statement55.getTree());

                	    if ( state.backtracking==0 ) {
                	    }
                	    }
                	    break;

                	default :
                	    break loop24;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return retval;
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statementBlock"

    public static class fieldDefinition_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldDefinition"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:56:1: fieldDefinition : ^( Field ^( DOLLAR UnquotedString ) ( atom )? ) ;
    public final PhpTree.fieldDefinition_return fieldDefinition() throws RecognitionException {
        PhpTree.fieldDefinition_return retval = new PhpTree.fieldDefinition_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree Field56=null;
        CommonTree DOLLAR57=null;
        CommonTree UnquotedString58=null;
        PhpTree.atom_return atom59 = null;


        CommonTree Field56_tree=null;
        CommonTree DOLLAR57_tree=null;
        CommonTree UnquotedString58_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:57:5: ( ^( Field ^( DOLLAR UnquotedString ) ( atom )? ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:57:7: ^( Field ^( DOLLAR UnquotedString ) ( atom )? )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            Field56=(CommonTree)match(input,Field,FOLLOW_Field_in_fieldDefinition418); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Field56_tree = (CommonTree)adaptor.dupNode(Field56);

            root_1 = (CommonTree)adaptor.becomeRoot(Field56_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_2 = _last;
            CommonTree _first_2 = null;
            CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            DOLLAR57=(CommonTree)match(input,DOLLAR,FOLLOW_DOLLAR_in_fieldDefinition421); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            DOLLAR57_tree = (CommonTree)adaptor.dupNode(DOLLAR57);

            root_2 = (CommonTree)adaptor.becomeRoot(DOLLAR57_tree, root_2);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            UnquotedString58=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_fieldDefinition423); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString58_tree = (CommonTree)adaptor.dupNode(UnquotedString58);

            adaptor.addChild(root_2, UnquotedString58_tree);
            }

            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:57:40: ( atom )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==Integer||(LA25_0>=Array && LA25_0<=Boolean)) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: atom
                    {
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atom_in_fieldDefinition426);
                    atom59=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, atom59.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldDefinition"

    public static class classModifier_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "classModifier"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:60:1: classModifier : 'abstract' ;
    public final PhpTree.classModifier_return classModifier() throws RecognitionException {
        PhpTree.classModifier_return retval = new PhpTree.classModifier_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree string_literal60=null;

        CommonTree string_literal60_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:61:5: ( 'abstract' )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:61:7: 'abstract'
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            string_literal60=(CommonTree)match(input,ABSTRACT,FOLLOW_ABSTRACT_in_classModifier449); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            string_literal60_tree = (CommonTree)adaptor.dupNode(string_literal60);

            adaptor.addChild(root_0, string_literal60_tree);
            }

            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "classModifier"

    public static class fieldModifier_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldModifier"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:63:1: fieldModifier : ( AccessModifier | 'abstract' | 'static' | 'final' );
    public final PhpTree.fieldModifier_return fieldModifier() throws RecognitionException {
        PhpTree.fieldModifier_return retval = new PhpTree.fieldModifier_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree set61=null;

        CommonTree set61_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:64:5: ( AccessModifier | 'abstract' | 'static' | 'final' )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            set61=(CommonTree)input.LT(1);
            if ( input.LA(1)==STATIC||input.LA(1)==ABSTRACT||input.LA(1)==AccessModifier||input.LA(1)==117 ) {
                input.consume();

                if ( state.backtracking==0 ) {
                set61_tree = (CommonTree)adaptor.dupNode(set61);

                adaptor.addChild(root_0, set61_tree);
                }
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            if ( state.backtracking==0 ) {
            } 

            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldModifier"

    public static class complexStatement_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "complexStatement"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:68:1: complexStatement : ( ^( IF expression statement ( statement )? ) | ^( FOR forInit forCondition forUpdate statement ) | ^( FOR_EACH variable arrayEntry statement ) | ^( WHILE expression statement ) | ^( DO statement expression ) | ^( SWITCH expression cases ) | ^( TRY statement catchStatement ) | ^( THROW throwException ) | ^( DECLARE declareList ( statement )? ) | ^( USE atom ) | functionDefinition );
    public final PhpTree.complexStatement_return complexStatement() throws RecognitionException {
        PhpTree.complexStatement_return retval = new PhpTree.complexStatement_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree IF62=null;
        CommonTree FOR66=null;
        CommonTree FOR_EACH71=null;
        CommonTree WHILE75=null;
        CommonTree DO78=null;
        CommonTree SWITCH81=null;
        CommonTree TRY84=null;
        CommonTree THROW87=null;
        CommonTree DECLARE89=null;
        CommonTree USE92=null;
        PhpTree.expression_return expression63 = null;

        PhpTree.statement_return statement64 = null;

        PhpTree.statement_return statement65 = null;

        PhpTree.forInit_return forInit67 = null;

        PhpTree.forCondition_return forCondition68 = null;

        PhpTree.forUpdate_return forUpdate69 = null;

        PhpTree.statement_return statement70 = null;

        PhpTree.variable_return variable72 = null;

        PhpTree.arrayEntry_return arrayEntry73 = null;

        PhpTree.statement_return statement74 = null;

        PhpTree.expression_return expression76 = null;

        PhpTree.statement_return statement77 = null;

        PhpTree.statement_return statement79 = null;

        PhpTree.expression_return expression80 = null;

        PhpTree.expression_return expression82 = null;

        PhpTree.cases_return cases83 = null;

        PhpTree.statement_return statement85 = null;

        PhpTree.catchStatement_return catchStatement86 = null;

        PhpTree.throwException_return throwException88 = null;

        PhpTree.declareList_return declareList90 = null;

        PhpTree.statement_return statement91 = null;

        PhpTree.atom_return atom93 = null;

        PhpTree.functionDefinition_return functionDefinition94 = null;


        CommonTree IF62_tree=null;
        CommonTree FOR66_tree=null;
        CommonTree FOR_EACH71_tree=null;
        CommonTree WHILE75_tree=null;
        CommonTree DO78_tree=null;
        CommonTree SWITCH81_tree=null;
        CommonTree TRY84_tree=null;
        CommonTree THROW87_tree=null;
        CommonTree DECLARE89_tree=null;
        CommonTree USE92_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:69:5: ( ^( IF expression statement ( statement )? ) | ^( FOR forInit forCondition forUpdate statement ) | ^( FOR_EACH variable arrayEntry statement ) | ^( WHILE expression statement ) | ^( DO statement expression ) | ^( SWITCH expression cases ) | ^( TRY statement catchStatement ) | ^( THROW throwException ) | ^( DECLARE declareList ( statement )? ) | ^( USE atom ) | functionDefinition )
            int alt28=11;
            switch ( input.LA(1) ) {
            case IF:
                {
                alt28=1;
                }
                break;
            case FOR:
                {
                alt28=2;
                }
                break;
            case FOR_EACH:
                {
                alt28=3;
                }
                break;
            case WHILE:
                {
                alt28=4;
                }
                break;
            case DO:
                {
                alt28=5;
                }
                break;
            case SWITCH:
                {
                alt28=6;
                }
                break;
            case TRY:
                {
                alt28=7;
                }
                break;
            case THROW:
                {
                alt28=8;
                }
                break;
            case DECLARE:
                {
                alt28=9;
                }
                break;
            case USE:
                {
                alt28=10;
                }
                break;
            case FUNCTION:
                {
                alt28=11;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:69:7: ^( IF expression statement ( statement )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    IF62=(CommonTree)match(input,IF,FOLLOW_IF_in_complexStatement496); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IF62_tree = (CommonTree)adaptor.dupNode(IF62);

                    root_1 = (CommonTree)adaptor.becomeRoot(IF62_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_complexStatement498);
                    expression63=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression63.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_statement_in_complexStatement500);
                    statement64=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, statement64.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:69:33: ( statement )?
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==OPEN_SQUARE_BRACE||(LA26_0>=LOGICAL_OR && LA26_0<=SUPPRESS_WARNINGS)||LA26_0==DOLLAR||(LA26_0>=DOT && LA26_0<=IF)||(LA26_0>=FOR && LA26_0<=SWITCH)||(LA26_0>=FUNCTION && LA26_0<=INTERFACE)||LA26_0==TRY||(LA26_0>=THROW && LA26_0<=USE)||LA26_0==Block||LA26_0==Apply||(LA26_0>=Prefix && LA26_0<=IfExpression)||LA26_0==Cast||(LA26_0>=BodyString && LA26_0<=UnquotedString)||(LA26_0>=Integer && LA26_0<=ShiftOperator)||(LA26_0>=Array && LA26_0<=Boolean)) ) {
                        alt26=1;
                    }
                    switch (alt26) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_statement_in_complexStatement502);
                            statement65=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, statement65.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:70:7: ^( FOR forInit forCondition forUpdate statement )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    FOR66=(CommonTree)match(input,FOR,FOLLOW_FOR_in_complexStatement513); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FOR66_tree = (CommonTree)adaptor.dupNode(FOR66);

                    root_1 = (CommonTree)adaptor.becomeRoot(FOR66_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_forInit_in_complexStatement515);
                    forInit67=forInit();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, forInit67.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_forCondition_in_complexStatement517);
                    forCondition68=forCondition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, forCondition68.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_forUpdate_in_complexStatement519);
                    forUpdate69=forUpdate();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, forUpdate69.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_statement_in_complexStatement521);
                    statement70=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, statement70.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:71:7: ^( FOR_EACH variable arrayEntry statement )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    FOR_EACH71=(CommonTree)match(input,FOR_EACH,FOLLOW_FOR_EACH_in_complexStatement531); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FOR_EACH71_tree = (CommonTree)adaptor.dupNode(FOR_EACH71);

                    root_1 = (CommonTree)adaptor.becomeRoot(FOR_EACH71_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_complexStatement533);
                    variable72=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, variable72.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_arrayEntry_in_complexStatement535);
                    arrayEntry73=arrayEntry();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, arrayEntry73.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_statement_in_complexStatement537);
                    statement74=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, statement74.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:72:7: ^( WHILE expression statement )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    WHILE75=(CommonTree)match(input,WHILE,FOLLOW_WHILE_in_complexStatement547); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    WHILE75_tree = (CommonTree)adaptor.dupNode(WHILE75);

                    root_1 = (CommonTree)adaptor.becomeRoot(WHILE75_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_complexStatement549);
                    expression76=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression76.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_statement_in_complexStatement551);
                    statement77=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, statement77.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:73:7: ^( DO statement expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DO78=(CommonTree)match(input,DO,FOLLOW_DO_in_complexStatement561); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DO78_tree = (CommonTree)adaptor.dupNode(DO78);

                    root_1 = (CommonTree)adaptor.becomeRoot(DO78_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_statement_in_complexStatement563);
                    statement79=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, statement79.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_complexStatement565);
                    expression80=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression80.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:74:7: ^( SWITCH expression cases )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    SWITCH81=(CommonTree)match(input,SWITCH,FOLLOW_SWITCH_in_complexStatement575); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    SWITCH81_tree = (CommonTree)adaptor.dupNode(SWITCH81);

                    root_1 = (CommonTree)adaptor.becomeRoot(SWITCH81_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_complexStatement577);
                    expression82=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression82.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_cases_in_complexStatement579);
                    cases83=cases();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, cases83.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:75:7: ^( TRY statement catchStatement )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    TRY84=(CommonTree)match(input,TRY,FOLLOW_TRY_in_complexStatement589); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    TRY84_tree = (CommonTree)adaptor.dupNode(TRY84);

                    root_1 = (CommonTree)adaptor.becomeRoot(TRY84_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_statement_in_complexStatement591);
                    statement85=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, statement85.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_catchStatement_in_complexStatement593);
                    catchStatement86=catchStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, catchStatement86.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 8 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:76:7: ^( THROW throwException )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    THROW87=(CommonTree)match(input,THROW,FOLLOW_THROW_in_complexStatement603); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    THROW87_tree = (CommonTree)adaptor.dupNode(THROW87);

                    root_1 = (CommonTree)adaptor.becomeRoot(THROW87_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_throwException_in_complexStatement605);
                    throwException88=throwException();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, throwException88.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 9 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:77:7: ^( DECLARE declareList ( statement )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DECLARE89=(CommonTree)match(input,DECLARE,FOLLOW_DECLARE_in_complexStatement615); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DECLARE89_tree = (CommonTree)adaptor.dupNode(DECLARE89);

                    root_1 = (CommonTree)adaptor.becomeRoot(DECLARE89_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_declareList_in_complexStatement617);
                    declareList90=declareList();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, declareList90.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:77:29: ( statement )?
                    int alt27=2;
                    int LA27_0 = input.LA(1);

                    if ( (LA27_0==OPEN_SQUARE_BRACE||(LA27_0>=LOGICAL_OR && LA27_0<=SUPPRESS_WARNINGS)||LA27_0==DOLLAR||(LA27_0>=DOT && LA27_0<=IF)||(LA27_0>=FOR && LA27_0<=SWITCH)||(LA27_0>=FUNCTION && LA27_0<=INTERFACE)||LA27_0==TRY||(LA27_0>=THROW && LA27_0<=USE)||LA27_0==Block||LA27_0==Apply||(LA27_0>=Prefix && LA27_0<=IfExpression)||LA27_0==Cast||(LA27_0>=BodyString && LA27_0<=UnquotedString)||(LA27_0>=Integer && LA27_0<=ShiftOperator)||(LA27_0>=Array && LA27_0<=Boolean)) ) {
                        alt27=1;
                    }
                    switch (alt27) {
                        case 1 :
                            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
                            {
                            _last = (CommonTree)input.LT(1);
                            pushFollow(FOLLOW_statement_in_complexStatement619);
                            statement91=statement();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) 
                            adaptor.addChild(root_1, statement91.getTree());

                            if ( state.backtracking==0 ) {
                            }
                            }
                            break;

                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 10 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:78:7: ^( USE atom )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    USE92=(CommonTree)match(input,USE,FOLLOW_USE_in_complexStatement630); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    USE92_tree = (CommonTree)adaptor.dupNode(USE92);

                    root_1 = (CommonTree)adaptor.becomeRoot(USE92_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atom_in_complexStatement632);
                    atom93=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, atom93.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 11 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:79:7: functionDefinition
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_functionDefinition_in_complexStatement641);
                    functionDefinition94=functionDefinition();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, functionDefinition94.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "complexStatement"

    public static class simpleStatement_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleStatement"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:82:1: simpleStatement : ( ^( ECHO ( expression )+ ) | ^( PRINT ( expression )+ ) | ^( GLOBAL ( name )+ ) | ^( STATIC variable atom ) | ^( BREAK ( Integer )? ) | ^( CONTINUE ( Integer )? ) | ^( RETURN ( expression )? ) | ^( RequireOperator expression ) | expression );
    public final PhpTree.simpleStatement_return simpleStatement() throws RecognitionException {
        PhpTree.simpleStatement_return retval = new PhpTree.simpleStatement_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree ECHO95=null;
        CommonTree PRINT97=null;
        CommonTree GLOBAL99=null;
        CommonTree STATIC101=null;
        CommonTree BREAK104=null;
        CommonTree Integer105=null;
        CommonTree CONTINUE106=null;
        CommonTree Integer107=null;
        CommonTree RETURN108=null;
        CommonTree RequireOperator110=null;
        PhpTree.expression_return expression96 = null;

        PhpTree.expression_return expression98 = null;

        PhpTree.name_return name100 = null;

        PhpTree.variable_return variable102 = null;

        PhpTree.atom_return atom103 = null;

        PhpTree.expression_return expression109 = null;

        PhpTree.expression_return expression111 = null;

        PhpTree.expression_return expression112 = null;


        CommonTree ECHO95_tree=null;
        CommonTree PRINT97_tree=null;
        CommonTree GLOBAL99_tree=null;
        CommonTree STATIC101_tree=null;
        CommonTree BREAK104_tree=null;
        CommonTree Integer105_tree=null;
        CommonTree CONTINUE106_tree=null;
        CommonTree Integer107_tree=null;
        CommonTree RETURN108_tree=null;
        CommonTree RequireOperator110_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:83:5: ( ^( ECHO ( expression )+ ) | ^( PRINT ( expression )+ ) | ^( GLOBAL ( name )+ ) | ^( STATIC variable atom ) | ^( BREAK ( Integer )? ) | ^( CONTINUE ( Integer )? ) | ^( RETURN ( expression )? ) | ^( RequireOperator expression ) | expression )
            int alt35=9;
            switch ( input.LA(1) ) {
            case ECHO:
                {
                alt35=1;
                }
                break;
            case PRINT:
                {
                alt35=2;
                }
                break;
            case GLOBAL:
                {
                alt35=3;
                }
                break;
            case STATIC:
                {
                alt35=4;
                }
                break;
            case BREAK:
                {
                alt35=5;
                }
                break;
            case CONTINUE:
                {
                alt35=6;
                }
                break;
            case RETURN:
                {
                alt35=7;
                }
                break;
            case RequireOperator:
                {
                alt35=8;
                }
                break;
            case OPEN_SQUARE_BRACE:
            case LOGICAL_OR:
            case LOGICAL_AND:
            case CLASS_MEMBER:
            case INSTANCE_MEMBER:
            case SUPPRESS_WARNINGS:
            case DOLLAR:
            case DOT:
            case AMPERSAND:
            case PIPE:
            case BANG:
            case PLUS:
            case MINUS:
            case ASTERISK:
            case PERCENT:
            case FORWARD_SLASH:
            case TILDE:
            case EQUALS:
            case NEW:
            case CLONE:
            case AND:
            case OR:
            case XOR:
            case INSTANCE_OF:
            case Apply:
            case Prefix:
            case Postfix:
            case IfExpression:
            case Cast:
            case UnquotedString:
            case Integer:
            case AsignmentOperator:
            case EqualityOperator:
            case ComparisionOperator:
            case ShiftOperator:
            case Array:
            case SingleQuotedString:
            case DoubleQuotedString:
            case HereDoc:
            case Real:
            case Boolean:
                {
                alt35=9;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }

            switch (alt35) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:83:7: ^( ECHO ( expression )+ )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    ECHO95=(CommonTree)match(input,ECHO,FOLLOW_ECHO_in_simpleStatement659); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ECHO95_tree = (CommonTree)adaptor.dupNode(ECHO95);

                    root_1 = (CommonTree)adaptor.becomeRoot(ECHO95_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:83:14: ( expression )+
                    int cnt29=0;
                    loop29:
                    do {
                        int alt29=2;
                        int LA29_0 = input.LA(1);

                        if ( (LA29_0==OPEN_SQUARE_BRACE||(LA29_0>=LOGICAL_OR && LA29_0<=SUPPRESS_WARNINGS)||LA29_0==DOLLAR||(LA29_0>=DOT && LA29_0<=CLONE)||(LA29_0>=AND && LA29_0<=INSTANCE_OF)||LA29_0==Apply||(LA29_0>=Prefix && LA29_0<=IfExpression)||LA29_0==Cast||LA29_0==UnquotedString||LA29_0==Integer||(LA29_0>=AsignmentOperator && LA29_0<=ShiftOperator)||(LA29_0>=Array && LA29_0<=Boolean)) ) {
                            alt29=1;
                        }


                        switch (alt29) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
                    	    {
                    	    _last = (CommonTree)input.LT(1);
                    	    pushFollow(FOLLOW_expression_in_simpleStatement661);
                    	    expression96=expression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) 
                    	    adaptor.addChild(root_1, expression96.getTree());

                    	    if ( state.backtracking==0 ) {
                    	    }
                    	    }
                    	    break;

                    	default :
                    	    if ( cnt29 >= 1 ) break loop29;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(29, input);
                                throw eee;
                        }
                        cnt29++;
                    } while (true);


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:84:7: ^( PRINT ( expression )+ )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    PRINT97=(CommonTree)match(input,PRINT,FOLLOW_PRINT_in_simpleStatement672); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    PRINT97_tree = (CommonTree)adaptor.dupNode(PRINT97);

                    root_1 = (CommonTree)adaptor.becomeRoot(PRINT97_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:84:15: ( expression )+
                    int cnt30=0;
                    loop30:
                    do {
                        int alt30=2;
                        int LA30_0 = input.LA(1);

                        if ( (LA30_0==OPEN_SQUARE_BRACE||(LA30_0>=LOGICAL_OR && LA30_0<=SUPPRESS_WARNINGS)||LA30_0==DOLLAR||(LA30_0>=DOT && LA30_0<=CLONE)||(LA30_0>=AND && LA30_0<=INSTANCE_OF)||LA30_0==Apply||(LA30_0>=Prefix && LA30_0<=IfExpression)||LA30_0==Cast||LA30_0==UnquotedString||LA30_0==Integer||(LA30_0>=AsignmentOperator && LA30_0<=ShiftOperator)||(LA30_0>=Array && LA30_0<=Boolean)) ) {
                            alt30=1;
                        }


                        switch (alt30) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
                    	    {
                    	    _last = (CommonTree)input.LT(1);
                    	    pushFollow(FOLLOW_expression_in_simpleStatement674);
                    	    expression98=expression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) 
                    	    adaptor.addChild(root_1, expression98.getTree());

                    	    if ( state.backtracking==0 ) {
                    	    }
                    	    }
                    	    break;

                    	default :
                    	    if ( cnt30 >= 1 ) break loop30;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(30, input);
                                throw eee;
                        }
                        cnt30++;
                    } while (true);


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:85:7: ^( GLOBAL ( name )+ )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    GLOBAL99=(CommonTree)match(input,GLOBAL,FOLLOW_GLOBAL_in_simpleStatement685); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    GLOBAL99_tree = (CommonTree)adaptor.dupNode(GLOBAL99);

                    root_1 = (CommonTree)adaptor.becomeRoot(GLOBAL99_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:85:16: ( name )+
                    int cnt31=0;
                    loop31:
                    do {
                        int alt31=2;
                        int LA31_0 = input.LA(1);

                        if ( (LA31_0==OPEN_SQUARE_BRACE||(LA31_0>=CLASS_MEMBER && LA31_0<=INSTANCE_MEMBER)||LA31_0==DOLLAR||LA31_0==UnquotedString) ) {
                            alt31=1;
                        }


                        switch (alt31) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: name
                    	    {
                    	    _last = (CommonTree)input.LT(1);
                    	    pushFollow(FOLLOW_name_in_simpleStatement687);
                    	    name100=name();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) 
                    	    adaptor.addChild(root_1, name100.getTree());

                    	    if ( state.backtracking==0 ) {
                    	    }
                    	    }
                    	    break;

                    	default :
                    	    if ( cnt31 >= 1 ) break loop31;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(31, input);
                                throw eee;
                        }
                        cnt31++;
                    } while (true);


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:86:7: ^( STATIC variable atom )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    STATIC101=(CommonTree)match(input,STATIC,FOLLOW_STATIC_in_simpleStatement698); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STATIC101_tree = (CommonTree)adaptor.dupNode(STATIC101);

                    root_1 = (CommonTree)adaptor.becomeRoot(STATIC101_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_simpleStatement700);
                    variable102=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, variable102.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atom_in_simpleStatement702);
                    atom103=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, atom103.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:88:7: ^( BREAK ( Integer )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    BREAK104=(CommonTree)match(input,BREAK,FOLLOW_BREAK_in_simpleStatement717); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BREAK104_tree = (CommonTree)adaptor.dupNode(BREAK104);

                    root_1 = (CommonTree)adaptor.becomeRoot(BREAK104_tree, root_1);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:88:15: ( Integer )?
                        int alt32=2;
                        int LA32_0 = input.LA(1);

                        if ( (LA32_0==Integer) ) {
                            alt32=1;
                        }
                        switch (alt32) {
                            case 1 :
                                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: Integer
                                {
                                _last = (CommonTree)input.LT(1);
                                Integer105=(CommonTree)match(input,Integer,FOLLOW_Integer_in_simpleStatement719); if (state.failed) return retval;
                                if ( state.backtracking==0 ) {
                                Integer105_tree = (CommonTree)adaptor.dupNode(Integer105);

                                adaptor.addChild(root_1, Integer105_tree);
                                }

                                if ( state.backtracking==0 ) {
                                }
                                }
                                break;

                        }


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:89:7: ^( CONTINUE ( Integer )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    CONTINUE106=(CommonTree)match(input,CONTINUE,FOLLOW_CONTINUE_in_simpleStatement730); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CONTINUE106_tree = (CommonTree)adaptor.dupNode(CONTINUE106);

                    root_1 = (CommonTree)adaptor.becomeRoot(CONTINUE106_tree, root_1);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:89:18: ( Integer )?
                        int alt33=2;
                        int LA33_0 = input.LA(1);

                        if ( (LA33_0==Integer) ) {
                            alt33=1;
                        }
                        switch (alt33) {
                            case 1 :
                                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: Integer
                                {
                                _last = (CommonTree)input.LT(1);
                                Integer107=(CommonTree)match(input,Integer,FOLLOW_Integer_in_simpleStatement732); if (state.failed) return retval;
                                if ( state.backtracking==0 ) {
                                Integer107_tree = (CommonTree)adaptor.dupNode(Integer107);

                                adaptor.addChild(root_1, Integer107_tree);
                                }

                                if ( state.backtracking==0 ) {
                                }
                                }
                                break;

                        }


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:91:7: ^( RETURN ( expression )? )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    RETURN108=(CommonTree)match(input,RETURN,FOLLOW_RETURN_in_simpleStatement748); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RETURN108_tree = (CommonTree)adaptor.dupNode(RETURN108);

                    root_1 = (CommonTree)adaptor.becomeRoot(RETURN108_tree, root_1);
                    }


                    if ( input.LA(1)==Token.DOWN ) {
                        match(input, Token.DOWN, null); if (state.failed) return retval;
                        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:91:16: ( expression )?
                        int alt34=2;
                        int LA34_0 = input.LA(1);

                        if ( (LA34_0==OPEN_SQUARE_BRACE||(LA34_0>=LOGICAL_OR && LA34_0<=SUPPRESS_WARNINGS)||LA34_0==DOLLAR||(LA34_0>=DOT && LA34_0<=CLONE)||(LA34_0>=AND && LA34_0<=INSTANCE_OF)||LA34_0==Apply||(LA34_0>=Prefix && LA34_0<=IfExpression)||LA34_0==Cast||LA34_0==UnquotedString||LA34_0==Integer||(LA34_0>=AsignmentOperator && LA34_0<=ShiftOperator)||(LA34_0>=Array && LA34_0<=Boolean)) ) {
                            alt34=1;
                        }
                        switch (alt34) {
                            case 1 :
                                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
                                {
                                _last = (CommonTree)input.LT(1);
                                pushFollow(FOLLOW_expression_in_simpleStatement750);
                                expression109=expression();

                                state._fsp--;
                                if (state.failed) return retval;
                                if ( state.backtracking==0 ) 
                                adaptor.addChild(root_1, expression109.getTree());

                                if ( state.backtracking==0 ) {
                                }
                                }
                                break;

                        }


                        match(input, Token.UP, null); if (state.failed) return retval;
                    }adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 8 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:92:7: ^( RequireOperator expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    RequireOperator110=(CommonTree)match(input,RequireOperator,FOLLOW_RequireOperator_in_simpleStatement761); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    RequireOperator110_tree = (CommonTree)adaptor.dupNode(RequireOperator110);

                    root_1 = (CommonTree)adaptor.becomeRoot(RequireOperator110_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_simpleStatement763);
                    expression111=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression111.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 9 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:93:7: expression
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_simpleStatement772);
                    expression112=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, expression112.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleStatement"

    public static class forInit_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forInit"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:97:1: forInit : ^( ForInit ( expression )+ ) ;
    public final PhpTree.forInit_return forInit() throws RecognitionException {
        PhpTree.forInit_return retval = new PhpTree.forInit_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree ForInit113=null;
        PhpTree.expression_return expression114 = null;


        CommonTree ForInit113_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:98:5: ( ^( ForInit ( expression )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:98:7: ^( ForInit ( expression )+ )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            ForInit113=(CommonTree)match(input,ForInit,FOLLOW_ForInit_in_forInit791); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            ForInit113_tree = (CommonTree)adaptor.dupNode(ForInit113);

            root_1 = (CommonTree)adaptor.becomeRoot(ForInit113_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:98:17: ( expression )+
            int cnt36=0;
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==OPEN_SQUARE_BRACE||(LA36_0>=LOGICAL_OR && LA36_0<=SUPPRESS_WARNINGS)||LA36_0==DOLLAR||(LA36_0>=DOT && LA36_0<=CLONE)||(LA36_0>=AND && LA36_0<=INSTANCE_OF)||LA36_0==Apply||(LA36_0>=Prefix && LA36_0<=IfExpression)||LA36_0==Cast||LA36_0==UnquotedString||LA36_0==Integer||(LA36_0>=AsignmentOperator && LA36_0<=ShiftOperator)||(LA36_0>=Array && LA36_0<=Boolean)) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_forInit793);
            	    expression114=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, expression114.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt36 >= 1 ) break loop36;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(36, input);
                        throw eee;
                }
                cnt36++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "forInit"

    public static class forCondition_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forCondition"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:101:1: forCondition : ^( ForCondition ( expression )+ ) ;
    public final PhpTree.forCondition_return forCondition() throws RecognitionException {
        PhpTree.forCondition_return retval = new PhpTree.forCondition_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree ForCondition115=null;
        PhpTree.expression_return expression116 = null;


        CommonTree ForCondition115_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:102:5: ( ^( ForCondition ( expression )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:102:7: ^( ForCondition ( expression )+ )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            ForCondition115=(CommonTree)match(input,ForCondition,FOLLOW_ForCondition_in_forCondition813); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            ForCondition115_tree = (CommonTree)adaptor.dupNode(ForCondition115);

            root_1 = (CommonTree)adaptor.becomeRoot(ForCondition115_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:102:22: ( expression )+
            int cnt37=0;
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==OPEN_SQUARE_BRACE||(LA37_0>=LOGICAL_OR && LA37_0<=SUPPRESS_WARNINGS)||LA37_0==DOLLAR||(LA37_0>=DOT && LA37_0<=CLONE)||(LA37_0>=AND && LA37_0<=INSTANCE_OF)||LA37_0==Apply||(LA37_0>=Prefix && LA37_0<=IfExpression)||LA37_0==Cast||LA37_0==UnquotedString||LA37_0==Integer||(LA37_0>=AsignmentOperator && LA37_0<=ShiftOperator)||(LA37_0>=Array && LA37_0<=Boolean)) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_forCondition815);
            	    expression116=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, expression116.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt37 >= 1 ) break loop37;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(37, input);
                        throw eee;
                }
                cnt37++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "forCondition"

    public static class forUpdate_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forUpdate"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:105:1: forUpdate : ^( ForUpdate ( expression )+ ) ;
    public final PhpTree.forUpdate_return forUpdate() throws RecognitionException {
        PhpTree.forUpdate_return retval = new PhpTree.forUpdate_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree ForUpdate117=null;
        PhpTree.expression_return expression118 = null;


        CommonTree ForUpdate117_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:106:5: ( ^( ForUpdate ( expression )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:106:7: ^( ForUpdate ( expression )+ )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            ForUpdate117=(CommonTree)match(input,ForUpdate,FOLLOW_ForUpdate_in_forUpdate839); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            ForUpdate117_tree = (CommonTree)adaptor.dupNode(ForUpdate117);

            root_1 = (CommonTree)adaptor.becomeRoot(ForUpdate117_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:106:19: ( expression )+
            int cnt38=0;
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==OPEN_SQUARE_BRACE||(LA38_0>=LOGICAL_OR && LA38_0<=SUPPRESS_WARNINGS)||LA38_0==DOLLAR||(LA38_0>=DOT && LA38_0<=CLONE)||(LA38_0>=AND && LA38_0<=INSTANCE_OF)||LA38_0==Apply||(LA38_0>=Prefix && LA38_0<=IfExpression)||LA38_0==Cast||LA38_0==UnquotedString||LA38_0==Integer||(LA38_0>=AsignmentOperator && LA38_0<=ShiftOperator)||(LA38_0>=Array && LA38_0<=Boolean)) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_forUpdate841);
            	    expression118=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, expression118.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt38 >= 1 ) break loop38;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(38, input);
                        throw eee;
                }
                cnt38++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "forUpdate"

    public static class cases_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cases"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:109:1: cases : ( casestatement )* defaultcase ;
    public final PhpTree.cases_return cases() throws RecognitionException {
        PhpTree.cases_return retval = new PhpTree.cases_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        PhpTree.casestatement_return casestatement119 = null;

        PhpTree.defaultcase_return defaultcase120 = null;



        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:110:5: ( ( casestatement )* defaultcase )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:110:7: ( casestatement )* defaultcase
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:110:7: ( casestatement )*
            loop39:
            do {
                int alt39=2;
                int LA39_0 = input.LA(1);

                if ( (LA39_0==CASE) ) {
                    alt39=1;
                }


                switch (alt39) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: casestatement
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_casestatement_in_cases861);
            	    casestatement119=casestatement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_0, casestatement119.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    break loop39;
                }
            } while (true);

            _last = (CommonTree)input.LT(1);
            pushFollow(FOLLOW_defaultcase_in_cases865);
            defaultcase120=defaultcase();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) 
            adaptor.addChild(root_0, defaultcase120.getTree());

            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cases"

    public static class casestatement_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "casestatement"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:113:1: casestatement : ^( CASE expression ( statement )* ) ;
    public final PhpTree.casestatement_return casestatement() throws RecognitionException {
        PhpTree.casestatement_return retval = new PhpTree.casestatement_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree CASE121=null;
        PhpTree.expression_return expression122 = null;

        PhpTree.statement_return statement123 = null;


        CommonTree CASE121_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:114:5: ( ^( CASE expression ( statement )* ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:114:7: ^( CASE expression ( statement )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            CASE121=(CommonTree)match(input,CASE,FOLLOW_CASE_in_casestatement883); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            CASE121_tree = (CommonTree)adaptor.dupNode(CASE121);

            root_1 = (CommonTree)adaptor.becomeRoot(CASE121_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            pushFollow(FOLLOW_expression_in_casestatement885);
            expression122=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) 
            adaptor.addChild(root_1, expression122.getTree());
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:114:25: ( statement )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==OPEN_SQUARE_BRACE||(LA40_0>=LOGICAL_OR && LA40_0<=SUPPRESS_WARNINGS)||LA40_0==DOLLAR||(LA40_0>=DOT && LA40_0<=IF)||(LA40_0>=FOR && LA40_0<=SWITCH)||(LA40_0>=FUNCTION && LA40_0<=INTERFACE)||LA40_0==TRY||(LA40_0>=THROW && LA40_0<=USE)||LA40_0==Block||LA40_0==Apply||(LA40_0>=Prefix && LA40_0<=IfExpression)||LA40_0==Cast||(LA40_0>=BodyString && LA40_0<=UnquotedString)||(LA40_0>=Integer && LA40_0<=ShiftOperator)||(LA40_0>=Array && LA40_0<=Boolean)) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_statement_in_casestatement887);
            	    statement123=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, statement123.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "casestatement"

    public static class defaultcase_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "defaultcase"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:117:1: defaultcase : ^( DEFAULT ( statement )* ) ;
    public final PhpTree.defaultcase_return defaultcase() throws RecognitionException {
        PhpTree.defaultcase_return retval = new PhpTree.defaultcase_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree DEFAULT124=null;
        PhpTree.statement_return statement125 = null;


        CommonTree DEFAULT124_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:118:5: ( ^( DEFAULT ( statement )* ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:118:7: ^( DEFAULT ( statement )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            DEFAULT124=(CommonTree)match(input,DEFAULT,FOLLOW_DEFAULT_in_defaultcase908); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            DEFAULT124_tree = (CommonTree)adaptor.dupNode(DEFAULT124);

            root_1 = (CommonTree)adaptor.becomeRoot(DEFAULT124_tree, root_1);
            }


            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:118:17: ( statement )*
                loop41:
                do {
                    int alt41=2;
                    int LA41_0 = input.LA(1);

                    if ( (LA41_0==OPEN_SQUARE_BRACE||(LA41_0>=LOGICAL_OR && LA41_0<=SUPPRESS_WARNINGS)||LA41_0==DOLLAR||(LA41_0>=DOT && LA41_0<=IF)||(LA41_0>=FOR && LA41_0<=SWITCH)||(LA41_0>=FUNCTION && LA41_0<=INTERFACE)||LA41_0==TRY||(LA41_0>=THROW && LA41_0<=USE)||LA41_0==Block||LA41_0==Apply||(LA41_0>=Prefix && LA41_0<=IfExpression)||LA41_0==Cast||(LA41_0>=BodyString && LA41_0<=UnquotedString)||(LA41_0>=Integer && LA41_0<=ShiftOperator)||(LA41_0>=Array && LA41_0<=Boolean)) ) {
                        alt41=1;
                    }


                    switch (alt41) {
                	case 1 :
                	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
                	    {
                	    _last = (CommonTree)input.LT(1);
                	    pushFollow(FOLLOW_statement_in_defaultcase910);
                	    statement125=statement();

                	    state._fsp--;
                	    if (state.failed) return retval;
                	    if ( state.backtracking==0 ) 
                	    adaptor.addChild(root_1, statement125.getTree());

                	    if ( state.backtracking==0 ) {
                	    }
                	    }
                	    break;

                	default :
                	    break loop41;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return retval;
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "defaultcase"

    public static class catchStatement_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catchStatement"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:121:1: catchStatement : ^( CATCH catchException statement ( catchStatement )? ) ;
    public final PhpTree.catchStatement_return catchStatement() throws RecognitionException {
        PhpTree.catchStatement_return retval = new PhpTree.catchStatement_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree CATCH126=null;
        PhpTree.catchException_return catchException127 = null;

        PhpTree.statement_return statement128 = null;

        PhpTree.catchStatement_return catchStatement129 = null;


        CommonTree CATCH126_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:122:5: ( ^( CATCH catchException statement ( catchStatement )? ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:122:7: ^( CATCH catchException statement ( catchStatement )? )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            CATCH126=(CommonTree)match(input,CATCH,FOLLOW_CATCH_in_catchStatement930); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            CATCH126_tree = (CommonTree)adaptor.dupNode(CATCH126);

            root_1 = (CommonTree)adaptor.becomeRoot(CATCH126_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            pushFollow(FOLLOW_catchException_in_catchStatement932);
            catchException127=catchException();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) 
            adaptor.addChild(root_1, catchException127.getTree());
            _last = (CommonTree)input.LT(1);
            pushFollow(FOLLOW_statement_in_catchStatement934);
            statement128=statement();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) 
            adaptor.addChild(root_1, statement128.getTree());
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:122:40: ( catchStatement )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==CATCH) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: catchStatement
                    {
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_catchStatement_in_catchStatement936);
                    catchStatement129=catchStatement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, catchStatement129.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catchStatement"

    public static class catchException_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "catchException"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:125:1: catchException : UnquotedString variable ;
    public final PhpTree.catchException_return catchException() throws RecognitionException {
        PhpTree.catchException_return retval = new PhpTree.catchException_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree UnquotedString130=null;
        PhpTree.variable_return variable131 = null;


        CommonTree UnquotedString130_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:126:5: ( UnquotedString variable )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:126:7: UnquotedString variable
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            UnquotedString130=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_catchException955); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString130_tree = (CommonTree)adaptor.dupNode(UnquotedString130);

            adaptor.addChild(root_0, UnquotedString130_tree);
            }
            _last = (CommonTree)input.LT(1);
            pushFollow(FOLLOW_variable_in_catchException957);
            variable131=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) 
            adaptor.addChild(root_0, variable131.getTree());

            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "catchException"

    public static class throwException_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "throwException"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:129:1: throwException : ( ^( NEW UnquotedString atom ) | variable );
    public final PhpTree.throwException_return throwException() throws RecognitionException {
        PhpTree.throwException_return retval = new PhpTree.throwException_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree NEW132=null;
        CommonTree UnquotedString133=null;
        PhpTree.atom_return atom134 = null;

        PhpTree.variable_return variable135 = null;


        CommonTree NEW132_tree=null;
        CommonTree UnquotedString133_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:130:5: ( ^( NEW UnquotedString atom ) | variable )
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==NEW) ) {
                alt43=1;
            }
            else if ( (LA43_0==DOLLAR||LA43_0==UnquotedString) ) {
                alt43=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 43, 0, input);

                throw nvae;
            }
            switch (alt43) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:130:7: ^( NEW UnquotedString atom )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    NEW132=(CommonTree)match(input,NEW,FOLLOW_NEW_in_throwException975); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    NEW132_tree = (CommonTree)adaptor.dupNode(NEW132);

                    root_1 = (CommonTree)adaptor.becomeRoot(NEW132_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString133=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_throwException977); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString133_tree = (CommonTree)adaptor.dupNode(UnquotedString133);

                    adaptor.addChild(root_1, UnquotedString133_tree);
                    }
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atom_in_throwException979);
                    atom134=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, atom134.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:131:7: variable
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_throwException988);
                    variable135=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, variable135.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "throwException"

    public static class declareList_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declareList"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:134:1: declareList : ^( DeclareList ( expression )+ ) ;
    public final PhpTree.declareList_return declareList() throws RecognitionException {
        PhpTree.declareList_return retval = new PhpTree.declareList_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree DeclareList136=null;
        PhpTree.expression_return expression137 = null;


        CommonTree DeclareList136_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:135:5: ( ^( DeclareList ( expression )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:135:7: ^( DeclareList ( expression )+ )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            DeclareList136=(CommonTree)match(input,DeclareList,FOLLOW_DeclareList_in_declareList1006); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            DeclareList136_tree = (CommonTree)adaptor.dupNode(DeclareList136);

            root_1 = (CommonTree)adaptor.becomeRoot(DeclareList136_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:135:21: ( expression )+
            int cnt44=0;
            loop44:
            do {
                int alt44=2;
                int LA44_0 = input.LA(1);

                if ( (LA44_0==OPEN_SQUARE_BRACE||(LA44_0>=LOGICAL_OR && LA44_0<=SUPPRESS_WARNINGS)||LA44_0==DOLLAR||(LA44_0>=DOT && LA44_0<=CLONE)||(LA44_0>=AND && LA44_0<=INSTANCE_OF)||LA44_0==Apply||(LA44_0>=Prefix && LA44_0<=IfExpression)||LA44_0==Cast||LA44_0==UnquotedString||LA44_0==Integer||(LA44_0>=AsignmentOperator && LA44_0<=ShiftOperator)||(LA44_0>=Array && LA44_0<=Boolean)) ) {
                    alt44=1;
                }


                switch (alt44) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_declareList1008);
            	    expression137=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, expression137.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt44 >= 1 ) break loop44;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(44, input);
                        throw eee;
                }
                cnt44++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declareList"

    public static class functionDefinition_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "functionDefinition"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:138:1: functionDefinition : ^( FUNCTION UnquotedString ^( Params ( paramDef )* ) ^( Block ( statement )* ) ) ;
    public final PhpTree.functionDefinition_return functionDefinition() throws RecognitionException {
        PhpTree.functionDefinition_return retval = new PhpTree.functionDefinition_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree FUNCTION138=null;
        CommonTree UnquotedString139=null;
        CommonTree Params140=null;
        CommonTree Block142=null;
        PhpTree.paramDef_return paramDef141 = null;

        PhpTree.statement_return statement143 = null;


        CommonTree FUNCTION138_tree=null;
        CommonTree UnquotedString139_tree=null;
        CommonTree Params140_tree=null;
        CommonTree Block142_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:139:5: ( ^( FUNCTION UnquotedString ^( Params ( paramDef )* ) ^( Block ( statement )* ) ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:139:7: ^( FUNCTION UnquotedString ^( Params ( paramDef )* ) ^( Block ( statement )* ) )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            FUNCTION138=(CommonTree)match(input,FUNCTION,FOLLOW_FUNCTION_in_functionDefinition1028); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            FUNCTION138_tree = (CommonTree)adaptor.dupNode(FUNCTION138);

            root_1 = (CommonTree)adaptor.becomeRoot(FUNCTION138_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            UnquotedString139=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_functionDefinition1030); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString139_tree = (CommonTree)adaptor.dupNode(UnquotedString139);

            adaptor.addChild(root_1, UnquotedString139_tree);
            }
            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_2 = _last;
            CommonTree _first_2 = null;
            CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            Params140=(CommonTree)match(input,Params,FOLLOW_Params_in_functionDefinition1033); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Params140_tree = (CommonTree)adaptor.dupNode(Params140);

            root_2 = (CommonTree)adaptor.becomeRoot(Params140_tree, root_2);
            }


            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:139:42: ( paramDef )*
                loop45:
                do {
                    int alt45=2;
                    int LA45_0 = input.LA(1);

                    if ( (LA45_0==DOLLAR||LA45_0==AMPERSAND||LA45_0==EQUALS) ) {
                        alt45=1;
                    }


                    switch (alt45) {
                	case 1 :
                	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: paramDef
                	    {
                	    _last = (CommonTree)input.LT(1);
                	    pushFollow(FOLLOW_paramDef_in_functionDefinition1035);
                	    paramDef141=paramDef();

                	    state._fsp--;
                	    if (state.failed) return retval;
                	    if ( state.backtracking==0 ) 
                	    adaptor.addChild(root_2, paramDef141.getTree());

                	    if ( state.backtracking==0 ) {
                	    }
                	    }
                	    break;

                	default :
                	    break loop45;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return retval;
            }adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_2 = _last;
            CommonTree _first_2 = null;
            CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            Block142=(CommonTree)match(input,Block,FOLLOW_Block_in_functionDefinition1040); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Block142_tree = (CommonTree)adaptor.dupNode(Block142);

            root_2 = (CommonTree)adaptor.becomeRoot(Block142_tree, root_2);
            }


            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:139:61: ( statement )*
                loop46:
                do {
                    int alt46=2;
                    int LA46_0 = input.LA(1);

                    if ( (LA46_0==OPEN_SQUARE_BRACE||(LA46_0>=LOGICAL_OR && LA46_0<=SUPPRESS_WARNINGS)||LA46_0==DOLLAR||(LA46_0>=DOT && LA46_0<=IF)||(LA46_0>=FOR && LA46_0<=SWITCH)||(LA46_0>=FUNCTION && LA46_0<=INTERFACE)||LA46_0==TRY||(LA46_0>=THROW && LA46_0<=USE)||LA46_0==Block||LA46_0==Apply||(LA46_0>=Prefix && LA46_0<=IfExpression)||LA46_0==Cast||(LA46_0>=BodyString && LA46_0<=UnquotedString)||(LA46_0>=Integer && LA46_0<=ShiftOperator)||(LA46_0>=Array && LA46_0<=Boolean)) ) {
                        alt46=1;
                    }


                    switch (alt46) {
                	case 1 :
                	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: statement
                	    {
                	    _last = (CommonTree)input.LT(1);
                	    pushFollow(FOLLOW_statement_in_functionDefinition1042);
                	    statement143=statement();

                	    state._fsp--;
                	    if (state.failed) return retval;
                	    if ( state.backtracking==0 ) 
                	    adaptor.addChild(root_2, statement143.getTree());

                	    if ( state.backtracking==0 ) {
                	    }
                	    }
                	    break;

                	default :
                	    break loop46;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return retval;
            }adaptor.addChild(root_1, root_2);_last = _save_last_2;
            }


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "functionDefinition"

    public static class paramDef_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "paramDef"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:142:1: paramDef : ( ^( EQUALS paramName atom ) | paramName );
    public final PhpTree.paramDef_return paramDef() throws RecognitionException {
        PhpTree.paramDef_return retval = new PhpTree.paramDef_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree EQUALS144=null;
        PhpTree.paramName_return paramName145 = null;

        PhpTree.atom_return atom146 = null;

        PhpTree.paramName_return paramName147 = null;


        CommonTree EQUALS144_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:143:5: ( ^( EQUALS paramName atom ) | paramName )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==EQUALS) ) {
                alt47=1;
            }
            else if ( (LA47_0==DOLLAR||LA47_0==AMPERSAND) ) {
                alt47=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:143:7: ^( EQUALS paramName atom )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    EQUALS144=(CommonTree)match(input,EQUALS,FOLLOW_EQUALS_in_paramDef1067); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EQUALS144_tree = (CommonTree)adaptor.dupNode(EQUALS144);

                    root_1 = (CommonTree)adaptor.becomeRoot(EQUALS144_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_paramName_in_paramDef1069);
                    paramName145=paramName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, paramName145.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atom_in_paramDef1071);
                    atom146=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, atom146.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:144:7: paramName
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_paramName_in_paramDef1081);
                    paramName147=paramName();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, paramName147.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "paramDef"

    public static class paramName_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "paramName"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:147:1: paramName : ( ^( DOLLAR UnquotedString ) | ^( AMPERSAND ^( DOLLAR UnquotedString ) ) );
    public final PhpTree.paramName_return paramName() throws RecognitionException {
        PhpTree.paramName_return retval = new PhpTree.paramName_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree DOLLAR148=null;
        CommonTree UnquotedString149=null;
        CommonTree AMPERSAND150=null;
        CommonTree DOLLAR151=null;
        CommonTree UnquotedString152=null;

        CommonTree DOLLAR148_tree=null;
        CommonTree UnquotedString149_tree=null;
        CommonTree AMPERSAND150_tree=null;
        CommonTree DOLLAR151_tree=null;
        CommonTree UnquotedString152_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:148:5: ( ^( DOLLAR UnquotedString ) | ^( AMPERSAND ^( DOLLAR UnquotedString ) ) )
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==DOLLAR) ) {
                alt48=1;
            }
            else if ( (LA48_0==AMPERSAND) ) {
                alt48=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 48, 0, input);

                throw nvae;
            }
            switch (alt48) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:148:7: ^( DOLLAR UnquotedString )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DOLLAR148=(CommonTree)match(input,DOLLAR,FOLLOW_DOLLAR_in_paramName1099); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR148_tree = (CommonTree)adaptor.dupNode(DOLLAR148);

                    root_1 = (CommonTree)adaptor.becomeRoot(DOLLAR148_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString149=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_paramName1101); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString149_tree = (CommonTree)adaptor.dupNode(UnquotedString149);

                    adaptor.addChild(root_1, UnquotedString149_tree);
                    }

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:149:7: ^( AMPERSAND ^( DOLLAR UnquotedString ) )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    AMPERSAND150=(CommonTree)match(input,AMPERSAND,FOLLOW_AMPERSAND_in_paramName1111); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    AMPERSAND150_tree = (CommonTree)adaptor.dupNode(AMPERSAND150);

                    root_1 = (CommonTree)adaptor.becomeRoot(AMPERSAND150_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_2 = _last;
                    CommonTree _first_2 = null;
                    CommonTree root_2 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DOLLAR151=(CommonTree)match(input,DOLLAR,FOLLOW_DOLLAR_in_paramName1114); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR151_tree = (CommonTree)adaptor.dupNode(DOLLAR151);

                    root_2 = (CommonTree)adaptor.becomeRoot(DOLLAR151_tree, root_2);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    UnquotedString152=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_paramName1116); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString152_tree = (CommonTree)adaptor.dupNode(UnquotedString152);

                    adaptor.addChild(root_2, UnquotedString152_tree);
                    }

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_1, root_2);_last = _save_last_2;
                    }


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "paramName"

    public static class expression_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:152:1: expression : ( ^( OR expression expression ) | ^( XOR expression expression ) | ^( AND expression expression ) | ^( EQUALS expression expression ) | ^( AsignmentOperator expression expression ) | ^( IfExpression expression expression expression ) | ^( LOGICAL_OR expression expression ) | ^( LOGICAL_AND expression expression ) | ^( PIPE expression expression ) | ^( AMPERSAND expression expression ) | ^( EqualityOperator expression expression ) | ^( ComparisionOperator expression expression ) | ^( ShiftOperator expression expression ) | ^( PLUS expression expression ) | ^( MINUS expression expression ) | ^( DOT expression expression ) | ^( ASTERISK expression expression ) | ^( FORWARD_SLASH expression expression ) | ^( PERCENT expression expression ) | ^( BANG expression ) | ^( INSTANCE_OF expression expression ) | ^( TILDE expression ) | ^( MINUS expression ) | ^( SUPPRESS_WARNINGS expression ) | ^( Cast PrimitiveType expression ) | ^( Prefix IncrementOperator name ) | ^( Postfix IncrementOperator name ) | ^( NEW nameOrFunctionCall ) | ^( CLONE name ) | atomOrReference );
    public final PhpTree.expression_return expression() throws RecognitionException {
        PhpTree.expression_return retval = new PhpTree.expression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree OR153=null;
        CommonTree XOR156=null;
        CommonTree AND159=null;
        CommonTree EQUALS162=null;
        CommonTree AsignmentOperator165=null;
        CommonTree IfExpression168=null;
        CommonTree LOGICAL_OR172=null;
        CommonTree LOGICAL_AND175=null;
        CommonTree PIPE178=null;
        CommonTree AMPERSAND181=null;
        CommonTree EqualityOperator184=null;
        CommonTree ComparisionOperator187=null;
        CommonTree ShiftOperator190=null;
        CommonTree PLUS193=null;
        CommonTree MINUS196=null;
        CommonTree DOT199=null;
        CommonTree ASTERISK202=null;
        CommonTree FORWARD_SLASH205=null;
        CommonTree PERCENT208=null;
        CommonTree BANG211=null;
        CommonTree INSTANCE_OF213=null;
        CommonTree TILDE216=null;
        CommonTree MINUS218=null;
        CommonTree SUPPRESS_WARNINGS220=null;
        CommonTree Cast222=null;
        CommonTree PrimitiveType223=null;
        CommonTree Prefix225=null;
        CommonTree IncrementOperator226=null;
        CommonTree Postfix228=null;
        CommonTree IncrementOperator229=null;
        CommonTree NEW231=null;
        CommonTree CLONE233=null;
        PhpTree.expression_return expression154 = null;

        PhpTree.expression_return expression155 = null;

        PhpTree.expression_return expression157 = null;

        PhpTree.expression_return expression158 = null;

        PhpTree.expression_return expression160 = null;

        PhpTree.expression_return expression161 = null;

        PhpTree.expression_return expression163 = null;

        PhpTree.expression_return expression164 = null;

        PhpTree.expression_return expression166 = null;

        PhpTree.expression_return expression167 = null;

        PhpTree.expression_return expression169 = null;

        PhpTree.expression_return expression170 = null;

        PhpTree.expression_return expression171 = null;

        PhpTree.expression_return expression173 = null;

        PhpTree.expression_return expression174 = null;

        PhpTree.expression_return expression176 = null;

        PhpTree.expression_return expression177 = null;

        PhpTree.expression_return expression179 = null;

        PhpTree.expression_return expression180 = null;

        PhpTree.expression_return expression182 = null;

        PhpTree.expression_return expression183 = null;

        PhpTree.expression_return expression185 = null;

        PhpTree.expression_return expression186 = null;

        PhpTree.expression_return expression188 = null;

        PhpTree.expression_return expression189 = null;

        PhpTree.expression_return expression191 = null;

        PhpTree.expression_return expression192 = null;

        PhpTree.expression_return expression194 = null;

        PhpTree.expression_return expression195 = null;

        PhpTree.expression_return expression197 = null;

        PhpTree.expression_return expression198 = null;

        PhpTree.expression_return expression200 = null;

        PhpTree.expression_return expression201 = null;

        PhpTree.expression_return expression203 = null;

        PhpTree.expression_return expression204 = null;

        PhpTree.expression_return expression206 = null;

        PhpTree.expression_return expression207 = null;

        PhpTree.expression_return expression209 = null;

        PhpTree.expression_return expression210 = null;

        PhpTree.expression_return expression212 = null;

        PhpTree.expression_return expression214 = null;

        PhpTree.expression_return expression215 = null;

        PhpTree.expression_return expression217 = null;

        PhpTree.expression_return expression219 = null;

        PhpTree.expression_return expression221 = null;

        PhpTree.expression_return expression224 = null;

        PhpTree.name_return name227 = null;

        PhpTree.name_return name230 = null;

        PhpTree.nameOrFunctionCall_return nameOrFunctionCall232 = null;

        PhpTree.name_return name234 = null;

        PhpTree.atomOrReference_return atomOrReference235 = null;


        CommonTree OR153_tree=null;
        CommonTree XOR156_tree=null;
        CommonTree AND159_tree=null;
        CommonTree EQUALS162_tree=null;
        CommonTree AsignmentOperator165_tree=null;
        CommonTree IfExpression168_tree=null;
        CommonTree LOGICAL_OR172_tree=null;
        CommonTree LOGICAL_AND175_tree=null;
        CommonTree PIPE178_tree=null;
        CommonTree AMPERSAND181_tree=null;
        CommonTree EqualityOperator184_tree=null;
        CommonTree ComparisionOperator187_tree=null;
        CommonTree ShiftOperator190_tree=null;
        CommonTree PLUS193_tree=null;
        CommonTree MINUS196_tree=null;
        CommonTree DOT199_tree=null;
        CommonTree ASTERISK202_tree=null;
        CommonTree FORWARD_SLASH205_tree=null;
        CommonTree PERCENT208_tree=null;
        CommonTree BANG211_tree=null;
        CommonTree INSTANCE_OF213_tree=null;
        CommonTree TILDE216_tree=null;
        CommonTree MINUS218_tree=null;
        CommonTree SUPPRESS_WARNINGS220_tree=null;
        CommonTree Cast222_tree=null;
        CommonTree PrimitiveType223_tree=null;
        CommonTree Prefix225_tree=null;
        CommonTree IncrementOperator226_tree=null;
        CommonTree Postfix228_tree=null;
        CommonTree IncrementOperator229_tree=null;
        CommonTree NEW231_tree=null;
        CommonTree CLONE233_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:153:5: ( ^( OR expression expression ) | ^( XOR expression expression ) | ^( AND expression expression ) | ^( EQUALS expression expression ) | ^( AsignmentOperator expression expression ) | ^( IfExpression expression expression expression ) | ^( LOGICAL_OR expression expression ) | ^( LOGICAL_AND expression expression ) | ^( PIPE expression expression ) | ^( AMPERSAND expression expression ) | ^( EqualityOperator expression expression ) | ^( ComparisionOperator expression expression ) | ^( ShiftOperator expression expression ) | ^( PLUS expression expression ) | ^( MINUS expression expression ) | ^( DOT expression expression ) | ^( ASTERISK expression expression ) | ^( FORWARD_SLASH expression expression ) | ^( PERCENT expression expression ) | ^( BANG expression ) | ^( INSTANCE_OF expression expression ) | ^( TILDE expression ) | ^( MINUS expression ) | ^( SUPPRESS_WARNINGS expression ) | ^( Cast PrimitiveType expression ) | ^( Prefix IncrementOperator name ) | ^( Postfix IncrementOperator name ) | ^( NEW nameOrFunctionCall ) | ^( CLONE name ) | atomOrReference )
            int alt49=30;
            alt49 = dfa49.predict(input);
            switch (alt49) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:153:7: ^( OR expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    OR153=(CommonTree)match(input,OR,FOLLOW_OR_in_expression1140); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    OR153_tree = (CommonTree)adaptor.dupNode(OR153);

                    root_1 = (CommonTree)adaptor.becomeRoot(OR153_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1142);
                    expression154=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression154.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1144);
                    expression155=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression155.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:154:7: ^( XOR expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    XOR156=(CommonTree)match(input,XOR,FOLLOW_XOR_in_expression1154); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    XOR156_tree = (CommonTree)adaptor.dupNode(XOR156);

                    root_1 = (CommonTree)adaptor.becomeRoot(XOR156_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1156);
                    expression157=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression157.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1158);
                    expression158=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression158.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:155:7: ^( AND expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    AND159=(CommonTree)match(input,AND,FOLLOW_AND_in_expression1168); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    AND159_tree = (CommonTree)adaptor.dupNode(AND159);

                    root_1 = (CommonTree)adaptor.becomeRoot(AND159_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1170);
                    expression160=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression160.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1172);
                    expression161=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression161.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:156:7: ^( EQUALS expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    EQUALS162=(CommonTree)match(input,EQUALS,FOLLOW_EQUALS_in_expression1182); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EQUALS162_tree = (CommonTree)adaptor.dupNode(EQUALS162);

                    root_1 = (CommonTree)adaptor.becomeRoot(EQUALS162_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1184);
                    expression163=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression163.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1186);
                    expression164=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression164.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:157:7: ^( AsignmentOperator expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    AsignmentOperator165=(CommonTree)match(input,AsignmentOperator,FOLLOW_AsignmentOperator_in_expression1196); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    AsignmentOperator165_tree = (CommonTree)adaptor.dupNode(AsignmentOperator165);

                    root_1 = (CommonTree)adaptor.becomeRoot(AsignmentOperator165_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1198);
                    expression166=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression166.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1200);
                    expression167=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression167.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:158:7: ^( IfExpression expression expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    IfExpression168=(CommonTree)match(input,IfExpression,FOLLOW_IfExpression_in_expression1210); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IfExpression168_tree = (CommonTree)adaptor.dupNode(IfExpression168);

                    root_1 = (CommonTree)adaptor.becomeRoot(IfExpression168_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1212);
                    expression169=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression169.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1214);
                    expression170=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression170.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1216);
                    expression171=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression171.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:159:7: ^( LOGICAL_OR expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    LOGICAL_OR172=(CommonTree)match(input,LOGICAL_OR,FOLLOW_LOGICAL_OR_in_expression1226); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LOGICAL_OR172_tree = (CommonTree)adaptor.dupNode(LOGICAL_OR172);

                    root_1 = (CommonTree)adaptor.becomeRoot(LOGICAL_OR172_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1228);
                    expression173=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression173.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1230);
                    expression174=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression174.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 8 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:160:7: ^( LOGICAL_AND expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    LOGICAL_AND175=(CommonTree)match(input,LOGICAL_AND,FOLLOW_LOGICAL_AND_in_expression1240); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LOGICAL_AND175_tree = (CommonTree)adaptor.dupNode(LOGICAL_AND175);

                    root_1 = (CommonTree)adaptor.becomeRoot(LOGICAL_AND175_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1242);
                    expression176=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression176.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1244);
                    expression177=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression177.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 9 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:161:7: ^( PIPE expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    PIPE178=(CommonTree)match(input,PIPE,FOLLOW_PIPE_in_expression1254); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    PIPE178_tree = (CommonTree)adaptor.dupNode(PIPE178);

                    root_1 = (CommonTree)adaptor.becomeRoot(PIPE178_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1256);
                    expression179=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression179.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1258);
                    expression180=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression180.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 10 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:162:7: ^( AMPERSAND expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    AMPERSAND181=(CommonTree)match(input,AMPERSAND,FOLLOW_AMPERSAND_in_expression1268); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    AMPERSAND181_tree = (CommonTree)adaptor.dupNode(AMPERSAND181);

                    root_1 = (CommonTree)adaptor.becomeRoot(AMPERSAND181_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1270);
                    expression182=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression182.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1272);
                    expression183=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression183.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 11 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:163:7: ^( EqualityOperator expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    EqualityOperator184=(CommonTree)match(input,EqualityOperator,FOLLOW_EqualityOperator_in_expression1282); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    EqualityOperator184_tree = (CommonTree)adaptor.dupNode(EqualityOperator184);

                    root_1 = (CommonTree)adaptor.becomeRoot(EqualityOperator184_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1284);
                    expression185=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression185.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1286);
                    expression186=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression186.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 12 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:164:7: ^( ComparisionOperator expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    ComparisionOperator187=(CommonTree)match(input,ComparisionOperator,FOLLOW_ComparisionOperator_in_expression1296); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ComparisionOperator187_tree = (CommonTree)adaptor.dupNode(ComparisionOperator187);

                    root_1 = (CommonTree)adaptor.becomeRoot(ComparisionOperator187_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1298);
                    expression188=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression188.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1300);
                    expression189=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression189.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 13 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:165:7: ^( ShiftOperator expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    ShiftOperator190=(CommonTree)match(input,ShiftOperator,FOLLOW_ShiftOperator_in_expression1310); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ShiftOperator190_tree = (CommonTree)adaptor.dupNode(ShiftOperator190);

                    root_1 = (CommonTree)adaptor.becomeRoot(ShiftOperator190_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1312);
                    expression191=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression191.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1314);
                    expression192=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression192.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 14 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:166:7: ^( PLUS expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    PLUS193=(CommonTree)match(input,PLUS,FOLLOW_PLUS_in_expression1324); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    PLUS193_tree = (CommonTree)adaptor.dupNode(PLUS193);

                    root_1 = (CommonTree)adaptor.becomeRoot(PLUS193_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1326);
                    expression194=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression194.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1328);
                    expression195=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression195.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 15 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:167:7: ^( MINUS expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    MINUS196=(CommonTree)match(input,MINUS,FOLLOW_MINUS_in_expression1338); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    MINUS196_tree = (CommonTree)adaptor.dupNode(MINUS196);

                    root_1 = (CommonTree)adaptor.becomeRoot(MINUS196_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1340);
                    expression197=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression197.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1342);
                    expression198=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression198.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 16 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:168:7: ^( DOT expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DOT199=(CommonTree)match(input,DOT,FOLLOW_DOT_in_expression1352); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOT199_tree = (CommonTree)adaptor.dupNode(DOT199);

                    root_1 = (CommonTree)adaptor.becomeRoot(DOT199_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1354);
                    expression200=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression200.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1356);
                    expression201=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression201.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 17 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:169:7: ^( ASTERISK expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    ASTERISK202=(CommonTree)match(input,ASTERISK,FOLLOW_ASTERISK_in_expression1366); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ASTERISK202_tree = (CommonTree)adaptor.dupNode(ASTERISK202);

                    root_1 = (CommonTree)adaptor.becomeRoot(ASTERISK202_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1368);
                    expression203=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression203.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1370);
                    expression204=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression204.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 18 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:170:7: ^( FORWARD_SLASH expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    FORWARD_SLASH205=(CommonTree)match(input,FORWARD_SLASH,FOLLOW_FORWARD_SLASH_in_expression1380); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FORWARD_SLASH205_tree = (CommonTree)adaptor.dupNode(FORWARD_SLASH205);

                    root_1 = (CommonTree)adaptor.becomeRoot(FORWARD_SLASH205_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1382);
                    expression206=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression206.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1384);
                    expression207=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression207.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 19 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:171:7: ^( PERCENT expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    PERCENT208=(CommonTree)match(input,PERCENT,FOLLOW_PERCENT_in_expression1394); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    PERCENT208_tree = (CommonTree)adaptor.dupNode(PERCENT208);

                    root_1 = (CommonTree)adaptor.becomeRoot(PERCENT208_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1396);
                    expression209=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression209.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1398);
                    expression210=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression210.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 20 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:172:7: ^( BANG expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    BANG211=(CommonTree)match(input,BANG,FOLLOW_BANG_in_expression1408); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    BANG211_tree = (CommonTree)adaptor.dupNode(BANG211);

                    root_1 = (CommonTree)adaptor.becomeRoot(BANG211_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1410);
                    expression212=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression212.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 21 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:173:7: ^( INSTANCE_OF expression expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    INSTANCE_OF213=(CommonTree)match(input,INSTANCE_OF,FOLLOW_INSTANCE_OF_in_expression1420); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INSTANCE_OF213_tree = (CommonTree)adaptor.dupNode(INSTANCE_OF213);

                    root_1 = (CommonTree)adaptor.becomeRoot(INSTANCE_OF213_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1422);
                    expression214=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression214.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1424);
                    expression215=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression215.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 22 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:174:7: ^( TILDE expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    TILDE216=(CommonTree)match(input,TILDE,FOLLOW_TILDE_in_expression1434); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    TILDE216_tree = (CommonTree)adaptor.dupNode(TILDE216);

                    root_1 = (CommonTree)adaptor.becomeRoot(TILDE216_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1436);
                    expression217=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression217.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 23 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:175:7: ^( MINUS expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    MINUS218=(CommonTree)match(input,MINUS,FOLLOW_MINUS_in_expression1446); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    MINUS218_tree = (CommonTree)adaptor.dupNode(MINUS218);

                    root_1 = (CommonTree)adaptor.becomeRoot(MINUS218_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1448);
                    expression219=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression219.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 24 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:176:7: ^( SUPPRESS_WARNINGS expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    SUPPRESS_WARNINGS220=(CommonTree)match(input,SUPPRESS_WARNINGS,FOLLOW_SUPPRESS_WARNINGS_in_expression1459); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    SUPPRESS_WARNINGS220_tree = (CommonTree)adaptor.dupNode(SUPPRESS_WARNINGS220);

                    root_1 = (CommonTree)adaptor.becomeRoot(SUPPRESS_WARNINGS220_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1461);
                    expression221=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression221.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 25 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:177:7: ^( Cast PrimitiveType expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Cast222=(CommonTree)match(input,Cast,FOLLOW_Cast_in_expression1471); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Cast222_tree = (CommonTree)adaptor.dupNode(Cast222);

                    root_1 = (CommonTree)adaptor.becomeRoot(Cast222_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    PrimitiveType223=(CommonTree)match(input,PrimitiveType,FOLLOW_PrimitiveType_in_expression1473); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    PrimitiveType223_tree = (CommonTree)adaptor.dupNode(PrimitiveType223);

                    adaptor.addChild(root_1, PrimitiveType223_tree);
                    }
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_expression1475);
                    expression224=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression224.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 26 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:178:7: ^( Prefix IncrementOperator name )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Prefix225=(CommonTree)match(input,Prefix,FOLLOW_Prefix_in_expression1485); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Prefix225_tree = (CommonTree)adaptor.dupNode(Prefix225);

                    root_1 = (CommonTree)adaptor.becomeRoot(Prefix225_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    IncrementOperator226=(CommonTree)match(input,IncrementOperator,FOLLOW_IncrementOperator_in_expression1487); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IncrementOperator226_tree = (CommonTree)adaptor.dupNode(IncrementOperator226);

                    adaptor.addChild(root_1, IncrementOperator226_tree);
                    }
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_name_in_expression1489);
                    name227=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, name227.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 27 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:179:7: ^( Postfix IncrementOperator name )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Postfix228=(CommonTree)match(input,Postfix,FOLLOW_Postfix_in_expression1499); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Postfix228_tree = (CommonTree)adaptor.dupNode(Postfix228);

                    root_1 = (CommonTree)adaptor.becomeRoot(Postfix228_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    IncrementOperator229=(CommonTree)match(input,IncrementOperator,FOLLOW_IncrementOperator_in_expression1501); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IncrementOperator229_tree = (CommonTree)adaptor.dupNode(IncrementOperator229);

                    adaptor.addChild(root_1, IncrementOperator229_tree);
                    }
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_name_in_expression1503);
                    name230=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, name230.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 28 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:180:7: ^( NEW nameOrFunctionCall )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    NEW231=(CommonTree)match(input,NEW,FOLLOW_NEW_in_expression1513); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    NEW231_tree = (CommonTree)adaptor.dupNode(NEW231);

                    root_1 = (CommonTree)adaptor.becomeRoot(NEW231_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_nameOrFunctionCall_in_expression1515);
                    nameOrFunctionCall232=nameOrFunctionCall();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, nameOrFunctionCall232.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 29 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:181:7: ^( CLONE name )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    CLONE233=(CommonTree)match(input,CLONE,FOLLOW_CLONE_in_expression1525); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CLONE233_tree = (CommonTree)adaptor.dupNode(CLONE233);

                    root_1 = (CommonTree)adaptor.becomeRoot(CLONE233_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_name_in_expression1527);
                    name234=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, name234.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 30 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:183:7: atomOrReference
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atomOrReference_in_expression1537);
                    atomOrReference235=atomOrReference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, atomOrReference235.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class atomOrReference_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atomOrReference"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:187:1: atomOrReference : ( atom | reference );
    public final PhpTree.atomOrReference_return atomOrReference() throws RecognitionException {
        PhpTree.atomOrReference_return retval = new PhpTree.atomOrReference_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        PhpTree.atom_return atom236 = null;

        PhpTree.reference_return reference237 = null;



        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:188:5: ( atom | reference )
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==Integer||(LA50_0>=Array && LA50_0<=Boolean)) ) {
                alt50=1;
            }
            else if ( (LA50_0==OPEN_SQUARE_BRACE||(LA50_0>=CLASS_MEMBER && LA50_0<=INSTANCE_MEMBER)||LA50_0==DOLLAR||LA50_0==AMPERSAND||LA50_0==Apply||LA50_0==UnquotedString) ) {
                alt50=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 50, 0, input);

                throw nvae;
            }
            switch (alt50) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:188:7: atom
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_atom_in_atomOrReference1555);
                    atom236=atom();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, atom236.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:189:7: reference
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_reference_in_atomOrReference1563);
                    reference237=reference();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, reference237.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atomOrReference"

    public static class arrayDeclaration_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arrayDeclaration"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:192:1: arrayDeclaration : ^( Array ( arrayEntry )* ) ;
    public final PhpTree.arrayDeclaration_return arrayDeclaration() throws RecognitionException {
        PhpTree.arrayDeclaration_return retval = new PhpTree.arrayDeclaration_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree Array238=null;
        PhpTree.arrayEntry_return arrayEntry239 = null;


        CommonTree Array238_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:193:5: ( ^( Array ( arrayEntry )* ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:193:7: ^( Array ( arrayEntry )* )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            Array238=(CommonTree)match(input,Array,FOLLOW_Array_in_arrayDeclaration1581); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            Array238_tree = (CommonTree)adaptor.dupNode(Array238);

            root_1 = (CommonTree)adaptor.becomeRoot(Array238_tree, root_1);
            }


            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:193:15: ( arrayEntry )*
                loop51:
                do {
                    int alt51=2;
                    int LA51_0 = input.LA(1);

                    if ( (LA51_0==OPEN_SQUARE_BRACE||(LA51_0>=ARRAY_ASSIGN && LA51_0<=SUPPRESS_WARNINGS)||LA51_0==DOLLAR||(LA51_0>=DOT && LA51_0<=CLONE)||(LA51_0>=AND && LA51_0<=INSTANCE_OF)||LA51_0==Apply||(LA51_0>=Prefix && LA51_0<=IfExpression)||LA51_0==Cast||LA51_0==UnquotedString||LA51_0==Integer||(LA51_0>=AsignmentOperator && LA51_0<=ShiftOperator)||(LA51_0>=Array && LA51_0<=Boolean)) ) {
                        alt51=1;
                    }


                    switch (alt51) {
                	case 1 :
                	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: arrayEntry
                	    {
                	    _last = (CommonTree)input.LT(1);
                	    pushFollow(FOLLOW_arrayEntry_in_arrayDeclaration1583);
                	    arrayEntry239=arrayEntry();

                	    state._fsp--;
                	    if (state.failed) return retval;
                	    if ( state.backtracking==0 ) 
                	    adaptor.addChild(root_1, arrayEntry239.getTree());

                	    if ( state.backtracking==0 ) {
                	    }
                	    }
                	    break;

                	default :
                	    break loop51;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return retval;
            }adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "arrayDeclaration"

    public static class arrayEntry_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arrayEntry"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:196:1: arrayEntry : ( keyValuePair | expression ) ;
    public final PhpTree.arrayEntry_return arrayEntry() throws RecognitionException {
        PhpTree.arrayEntry_return retval = new PhpTree.arrayEntry_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        PhpTree.keyValuePair_return keyValuePair240 = null;

        PhpTree.expression_return expression241 = null;



        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:197:5: ( ( keyValuePair | expression ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:197:7: ( keyValuePair | expression )
            {
            root_0 = (CommonTree)adaptor.nil();

            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:197:7: ( keyValuePair | expression )
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==ARRAY_ASSIGN) ) {
                alt52=1;
            }
            else if ( (LA52_0==OPEN_SQUARE_BRACE||(LA52_0>=LOGICAL_OR && LA52_0<=SUPPRESS_WARNINGS)||LA52_0==DOLLAR||(LA52_0>=DOT && LA52_0<=CLONE)||(LA52_0>=AND && LA52_0<=INSTANCE_OF)||LA52_0==Apply||(LA52_0>=Prefix && LA52_0<=IfExpression)||LA52_0==Cast||LA52_0==UnquotedString||LA52_0==Integer||(LA52_0>=AsignmentOperator && LA52_0<=ShiftOperator)||(LA52_0>=Array && LA52_0<=Boolean)) ) {
                alt52=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }
            switch (alt52) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:197:8: keyValuePair
                    {
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_keyValuePair_in_arrayEntry1603);
                    keyValuePair240=keyValuePair();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, keyValuePair240.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:197:23: expression
                    {
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_arrayEntry1607);
                    expression241=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, expression241.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "arrayEntry"

    public static class keyValuePair_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "keyValuePair"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:200:1: keyValuePair : ^( ARRAY_ASSIGN ( expression )+ ) ;
    public final PhpTree.keyValuePair_return keyValuePair() throws RecognitionException {
        PhpTree.keyValuePair_return retval = new PhpTree.keyValuePair_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree ARRAY_ASSIGN242=null;
        PhpTree.expression_return expression243 = null;


        CommonTree ARRAY_ASSIGN242_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:201:5: ( ^( ARRAY_ASSIGN ( expression )+ ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:201:7: ^( ARRAY_ASSIGN ( expression )+ )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            ARRAY_ASSIGN242=(CommonTree)match(input,ARRAY_ASSIGN,FOLLOW_ARRAY_ASSIGN_in_keyValuePair1626); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            ARRAY_ASSIGN242_tree = (CommonTree)adaptor.dupNode(ARRAY_ASSIGN242);

            root_1 = (CommonTree)adaptor.becomeRoot(ARRAY_ASSIGN242_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:201:22: ( expression )+
            int cnt53=0;
            loop53:
            do {
                int alt53=2;
                int LA53_0 = input.LA(1);

                if ( (LA53_0==OPEN_SQUARE_BRACE||(LA53_0>=LOGICAL_OR && LA53_0<=SUPPRESS_WARNINGS)||LA53_0==DOLLAR||(LA53_0>=DOT && LA53_0<=CLONE)||(LA53_0>=AND && LA53_0<=INSTANCE_OF)||LA53_0==Apply||(LA53_0>=Prefix && LA53_0<=IfExpression)||LA53_0==Cast||LA53_0==UnquotedString||LA53_0==Integer||(LA53_0>=AsignmentOperator && LA53_0<=ShiftOperator)||(LA53_0>=Array && LA53_0<=Boolean)) ) {
                    alt53=1;
                }


                switch (alt53) {
            	case 1 :
            	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
            	    {
            	    _last = (CommonTree)input.LT(1);
            	    pushFollow(FOLLOW_expression_in_keyValuePair1628);
            	    expression243=expression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) 
            	    adaptor.addChild(root_1, expression243.getTree());

            	    if ( state.backtracking==0 ) {
            	    }
            	    }
            	    break;

            	default :
            	    if ( cnt53 >= 1 ) break loop53;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(53, input);
                        throw eee;
                }
                cnt53++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "keyValuePair"

    public static class atom_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:1: atom : ( SingleQuotedString | DoubleQuotedString | HereDoc | Integer | Real | Boolean | arrayDeclaration );
    public final PhpTree.atom_return atom() throws RecognitionException {
        PhpTree.atom_return retval = new PhpTree.atom_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree SingleQuotedString244=null;
        CommonTree DoubleQuotedString245=null;
        CommonTree HereDoc246=null;
        CommonTree Integer247=null;
        CommonTree Real248=null;
        CommonTree Boolean249=null;
        PhpTree.arrayDeclaration_return arrayDeclaration250 = null;


        CommonTree SingleQuotedString244_tree=null;
        CommonTree DoubleQuotedString245_tree=null;
        CommonTree HereDoc246_tree=null;
        CommonTree Integer247_tree=null;
        CommonTree Real248_tree=null;
        CommonTree Boolean249_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:5: ( SingleQuotedString | DoubleQuotedString | HereDoc | Integer | Real | Boolean | arrayDeclaration )
            int alt54=7;
            switch ( input.LA(1) ) {
            case SingleQuotedString:
                {
                alt54=1;
                }
                break;
            case DoubleQuotedString:
                {
                alt54=2;
                }
                break;
            case HereDoc:
                {
                alt54=3;
                }
                break;
            case Integer:
                {
                alt54=4;
                }
                break;
            case Real:
                {
                alt54=5;
                }
                break;
            case Boolean:
                {
                alt54=6;
                }
                break;
            case Array:
                {
                alt54=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 54, 0, input);

                throw nvae;
            }

            switch (alt54) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:7: SingleQuotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    SingleQuotedString244=(CommonTree)match(input,SingleQuotedString,FOLLOW_SingleQuotedString_in_atom1642); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    SingleQuotedString244_tree = (CommonTree)adaptor.dupNode(SingleQuotedString244);

                    adaptor.addChild(root_0, SingleQuotedString244_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:28: DoubleQuotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    DoubleQuotedString245=(CommonTree)match(input,DoubleQuotedString,FOLLOW_DoubleQuotedString_in_atom1646); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DoubleQuotedString245_tree = (CommonTree)adaptor.dupNode(DoubleQuotedString245);

                    adaptor.addChild(root_0, DoubleQuotedString245_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:49: HereDoc
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    HereDoc246=(CommonTree)match(input,HereDoc,FOLLOW_HereDoc_in_atom1650); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    HereDoc246_tree = (CommonTree)adaptor.dupNode(HereDoc246);

                    adaptor.addChild(root_0, HereDoc246_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 4 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:59: Integer
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    Integer247=(CommonTree)match(input,Integer,FOLLOW_Integer_in_atom1654); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Integer247_tree = (CommonTree)adaptor.dupNode(Integer247);

                    adaptor.addChild(root_0, Integer247_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 5 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:69: Real
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    Real248=(CommonTree)match(input,Real,FOLLOW_Real_in_atom1658); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Real248_tree = (CommonTree)adaptor.dupNode(Real248);

                    adaptor.addChild(root_0, Real248_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 6 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:76: Boolean
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    Boolean249=(CommonTree)match(input,Boolean,FOLLOW_Boolean_in_atom1662); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Boolean249_tree = (CommonTree)adaptor.dupNode(Boolean249);

                    adaptor.addChild(root_0, Boolean249_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 7 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:204:86: arrayDeclaration
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_arrayDeclaration_in_atom1666);
                    arrayDeclaration250=arrayDeclaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, arrayDeclaration250.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom"

    public static class reference_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reference"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:208:1: reference : ( ^( AMPERSAND nameOrFunctionCall ) | nameOrFunctionCall );
    public final PhpTree.reference_return reference() throws RecognitionException {
        PhpTree.reference_return retval = new PhpTree.reference_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree AMPERSAND251=null;
        PhpTree.nameOrFunctionCall_return nameOrFunctionCall252 = null;

        PhpTree.nameOrFunctionCall_return nameOrFunctionCall253 = null;


        CommonTree AMPERSAND251_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:209:5: ( ^( AMPERSAND nameOrFunctionCall ) | nameOrFunctionCall )
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==AMPERSAND) ) {
                alt55=1;
            }
            else if ( (LA55_0==OPEN_SQUARE_BRACE||(LA55_0>=CLASS_MEMBER && LA55_0<=INSTANCE_MEMBER)||LA55_0==DOLLAR||LA55_0==Apply||LA55_0==UnquotedString) ) {
                alt55=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }
            switch (alt55) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:209:7: ^( AMPERSAND nameOrFunctionCall )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    AMPERSAND251=(CommonTree)match(input,AMPERSAND,FOLLOW_AMPERSAND_in_reference1685); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    AMPERSAND251_tree = (CommonTree)adaptor.dupNode(AMPERSAND251);

                    root_1 = (CommonTree)adaptor.becomeRoot(AMPERSAND251_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_nameOrFunctionCall_in_reference1687);
                    nameOrFunctionCall252=nameOrFunctionCall();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, nameOrFunctionCall252.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:210:7: nameOrFunctionCall
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_nameOrFunctionCall_in_reference1696);
                    nameOrFunctionCall253=nameOrFunctionCall();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, nameOrFunctionCall253.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reference"

    public static class nameOrFunctionCall_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "nameOrFunctionCall"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:213:1: nameOrFunctionCall : ( ^( Apply name ( expression )* ) | name );
    public final PhpTree.nameOrFunctionCall_return nameOrFunctionCall() throws RecognitionException {
        PhpTree.nameOrFunctionCall_return retval = new PhpTree.nameOrFunctionCall_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree Apply254=null;
        PhpTree.name_return name255 = null;

        PhpTree.expression_return expression256 = null;

        PhpTree.name_return name257 = null;


        CommonTree Apply254_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:214:5: ( ^( Apply name ( expression )* ) | name )
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==Apply) ) {
                alt57=1;
            }
            else if ( (LA57_0==OPEN_SQUARE_BRACE||(LA57_0>=CLASS_MEMBER && LA57_0<=INSTANCE_MEMBER)||LA57_0==DOLLAR||LA57_0==UnquotedString) ) {
                alt57=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 57, 0, input);

                throw nvae;
            }
            switch (alt57) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:214:7: ^( Apply name ( expression )* )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    Apply254=(CommonTree)match(input,Apply,FOLLOW_Apply_in_nameOrFunctionCall1714); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    Apply254_tree = (CommonTree)adaptor.dupNode(Apply254);

                    root_1 = (CommonTree)adaptor.becomeRoot(Apply254_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_name_in_nameOrFunctionCall1716);
                    name255=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, name255.getTree());
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:214:20: ( expression )*
                    loop56:
                    do {
                        int alt56=2;
                        int LA56_0 = input.LA(1);

                        if ( (LA56_0==OPEN_SQUARE_BRACE||(LA56_0>=LOGICAL_OR && LA56_0<=SUPPRESS_WARNINGS)||LA56_0==DOLLAR||(LA56_0>=DOT && LA56_0<=CLONE)||(LA56_0>=AND && LA56_0<=INSTANCE_OF)||LA56_0==Apply||(LA56_0>=Prefix && LA56_0<=IfExpression)||LA56_0==Cast||LA56_0==UnquotedString||LA56_0==Integer||(LA56_0>=AsignmentOperator && LA56_0<=ShiftOperator)||(LA56_0>=Array && LA56_0<=Boolean)) ) {
                            alt56=1;
                        }


                        switch (alt56) {
                    	case 1 :
                    	    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:0:0: expression
                    	    {
                    	    _last = (CommonTree)input.LT(1);
                    	    pushFollow(FOLLOW_expression_in_nameOrFunctionCall1718);
                    	    expression256=expression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) 
                    	    adaptor.addChild(root_1, expression256.getTree());

                    	    if ( state.backtracking==0 ) {
                    	    }
                    	    }
                    	    break;

                    	default :
                    	    break loop56;
                        }
                    } while (true);


                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:215:7: name
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_name_in_nameOrFunctionCall1728);
                    name257=name();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, name257.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "nameOrFunctionCall"

    public static class name_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "name"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:218:1: name : ( staticMemberAccess | memberAccess | variable );
    public final PhpTree.name_return name() throws RecognitionException {
        PhpTree.name_return retval = new PhpTree.name_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        PhpTree.staticMemberAccess_return staticMemberAccess258 = null;

        PhpTree.memberAccess_return memberAccess259 = null;

        PhpTree.variable_return variable260 = null;



        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:218:5: ( staticMemberAccess | memberAccess | variable )
            int alt58=3;
            switch ( input.LA(1) ) {
            case CLASS_MEMBER:
                {
                alt58=1;
                }
                break;
            case OPEN_SQUARE_BRACE:
            case INSTANCE_MEMBER:
                {
                alt58=2;
                }
                break;
            case DOLLAR:
            case UnquotedString:
                {
                alt58=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 58, 0, input);

                throw nvae;
            }

            switch (alt58) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:218:7: staticMemberAccess
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_staticMemberAccess_in_name1740);
                    staticMemberAccess258=staticMemberAccess();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, staticMemberAccess258.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:219:7: memberAccess
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_memberAccess_in_name1748);
                    memberAccess259=memberAccess();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, memberAccess259.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 3 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:220:7: variable
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_name1756);
                    variable260=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_0, variable260.getTree());

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "name"

    public static class staticMemberAccess_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "staticMemberAccess"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:223:1: staticMemberAccess : ^( '::' UnquotedString variable ) ;
    public final PhpTree.staticMemberAccess_return staticMemberAccess() throws RecognitionException {
        PhpTree.staticMemberAccess_return retval = new PhpTree.staticMemberAccess_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree string_literal261=null;
        CommonTree UnquotedString262=null;
        PhpTree.variable_return variable263 = null;


        CommonTree string_literal261_tree=null;
        CommonTree UnquotedString262_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:224:5: ( ^( '::' UnquotedString variable ) )
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:224:7: ^( '::' UnquotedString variable )
            {
            root_0 = (CommonTree)adaptor.nil();

            _last = (CommonTree)input.LT(1);
            {
            CommonTree _save_last_1 = _last;
            CommonTree _first_1 = null;
            CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
            string_literal261=(CommonTree)match(input,CLASS_MEMBER,FOLLOW_CLASS_MEMBER_in_staticMemberAccess1778); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            string_literal261_tree = (CommonTree)adaptor.dupNode(string_literal261);

            root_1 = (CommonTree)adaptor.becomeRoot(string_literal261_tree, root_1);
            }


            match(input, Token.DOWN, null); if (state.failed) return retval;
            _last = (CommonTree)input.LT(1);
            UnquotedString262=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_staticMemberAccess1780); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            UnquotedString262_tree = (CommonTree)adaptor.dupNode(UnquotedString262);

            adaptor.addChild(root_1, UnquotedString262_tree);
            }
            _last = (CommonTree)input.LT(1);
            pushFollow(FOLLOW_variable_in_staticMemberAccess1783);
            variable263=variable();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) 
            adaptor.addChild(root_1, variable263.getTree());

            match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
            }


            if ( state.backtracking==0 ) {
            }
            }

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "staticMemberAccess"

    public static class memberAccess_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "memberAccess"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:227:1: memberAccess : ( ^( OPEN_SQUARE_BRACE variable expression ) | ^( '->' variable UnquotedString ) );
    public final PhpTree.memberAccess_return memberAccess() throws RecognitionException {
        PhpTree.memberAccess_return retval = new PhpTree.memberAccess_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree OPEN_SQUARE_BRACE264=null;
        CommonTree string_literal267=null;
        CommonTree UnquotedString269=null;
        PhpTree.variable_return variable265 = null;

        PhpTree.expression_return expression266 = null;

        PhpTree.variable_return variable268 = null;


        CommonTree OPEN_SQUARE_BRACE264_tree=null;
        CommonTree string_literal267_tree=null;
        CommonTree UnquotedString269_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:228:5: ( ^( OPEN_SQUARE_BRACE variable expression ) | ^( '->' variable UnquotedString ) )
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==OPEN_SQUARE_BRACE) ) {
                alt59=1;
            }
            else if ( (LA59_0==INSTANCE_MEMBER) ) {
                alt59=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 59, 0, input);

                throw nvae;
            }
            switch (alt59) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:228:7: ^( OPEN_SQUARE_BRACE variable expression )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    OPEN_SQUARE_BRACE264=(CommonTree)match(input,OPEN_SQUARE_BRACE,FOLLOW_OPEN_SQUARE_BRACE_in_memberAccess1802); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    OPEN_SQUARE_BRACE264_tree = (CommonTree)adaptor.dupNode(OPEN_SQUARE_BRACE264);

                    root_1 = (CommonTree)adaptor.becomeRoot(OPEN_SQUARE_BRACE264_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_memberAccess1804);
                    variable265=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, variable265.getTree());
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_expression_in_memberAccess1806);
                    expression266=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, expression266.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:229:7: ^( '->' variable UnquotedString )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    string_literal267=(CommonTree)match(input,INSTANCE_MEMBER,FOLLOW_INSTANCE_MEMBER_in_memberAccess1816); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal267_tree = (CommonTree)adaptor.dupNode(string_literal267);

                    root_1 = (CommonTree)adaptor.becomeRoot(string_literal267_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_memberAccess1818);
                    variable268=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, variable268.getTree());
                    _last = (CommonTree)input.LT(1);
                    UnquotedString269=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_memberAccess1820); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString269_tree = (CommonTree)adaptor.dupNode(UnquotedString269);

                    adaptor.addChild(root_1, UnquotedString269_tree);
                    }

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "memberAccess"

    public static class variable_return extends TreeRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:232:1: variable : ( ^( DOLLAR variable ) | UnquotedString );
    public final PhpTree.variable_return variable() throws RecognitionException {
        PhpTree.variable_return retval = new PhpTree.variable_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        CommonTree _first_0 = null;
        CommonTree _last = null;

        CommonTree DOLLAR270=null;
        CommonTree UnquotedString272=null;
        PhpTree.variable_return variable271 = null;


        CommonTree DOLLAR270_tree=null;
        CommonTree UnquotedString272_tree=null;

        try {
            // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:233:5: ( ^( DOLLAR variable ) | UnquotedString )
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==DOLLAR) ) {
                alt60=1;
            }
            else if ( (LA60_0==UnquotedString) ) {
                alt60=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 60, 0, input);

                throw nvae;
            }
            switch (alt60) {
                case 1 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:233:7: ^( DOLLAR variable )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    {
                    CommonTree _save_last_1 = _last;
                    CommonTree _first_1 = null;
                    CommonTree root_1 = (CommonTree)adaptor.nil();_last = (CommonTree)input.LT(1);
                    DOLLAR270=(CommonTree)match(input,DOLLAR,FOLLOW_DOLLAR_in_variable1843); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    DOLLAR270_tree = (CommonTree)adaptor.dupNode(DOLLAR270);

                    root_1 = (CommonTree)adaptor.becomeRoot(DOLLAR270_tree, root_1);
                    }


                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    _last = (CommonTree)input.LT(1);
                    pushFollow(FOLLOW_variable_in_variable1845);
                    variable271=variable();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) 
                    adaptor.addChild(root_1, variable271.getTree());

                    match(input, Token.UP, null); if (state.failed) return retval;adaptor.addChild(root_0, root_1);_last = _save_last_1;
                    }


                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;
                case 2 :
                    // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:234:7: UnquotedString
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    _last = (CommonTree)input.LT(1);
                    UnquotedString272=(CommonTree)match(input,UnquotedString,FOLLOW_UnquotedString_in_variable1854); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    UnquotedString272_tree = (CommonTree)adaptor.dupNode(UnquotedString272);

                    adaptor.addChild(root_0, UnquotedString272_tree);
                    }

                    if ( state.backtracking==0 ) {
                    }
                    }
                    break;

            }
            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable"

    // $ANTLR start synpred83_PhpTree
    public final void synpred83_PhpTree_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:162:7: ( ^( AMPERSAND expression expression ) )
        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:162:7: ^( AMPERSAND expression expression )
        {
        match(input,AMPERSAND,FOLLOW_AMPERSAND_in_synpred83_PhpTree1268); if (state.failed) return ;

        match(input, Token.DOWN, null); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred83_PhpTree1270);
        expression();

        state._fsp--;
        if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred83_PhpTree1272);
        expression();

        state._fsp--;
        if (state.failed) return ;

        match(input, Token.UP, null); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred83_PhpTree

    // $ANTLR start synpred88_PhpTree
    public final void synpred88_PhpTree_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:167:7: ( ^( MINUS expression expression ) )
        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:167:7: ^( MINUS expression expression )
        {
        match(input,MINUS,FOLLOW_MINUS_in_synpred88_PhpTree1338); if (state.failed) return ;

        match(input, Token.DOWN, null); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred88_PhpTree1340);
        expression();

        state._fsp--;
        if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred88_PhpTree1342);
        expression();

        state._fsp--;
        if (state.failed) return ;

        match(input, Token.UP, null); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred88_PhpTree

    // $ANTLR start synpred96_PhpTree
    public final void synpred96_PhpTree_fragment() throws RecognitionException {   
        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:175:7: ( ^( MINUS expression ) )
        // /home/iberiam/phpparser-1.2/grammar/PhpTree.g:175:7: ^( MINUS expression )
        {
        match(input,MINUS,FOLLOW_MINUS_in_synpred96_PhpTree1446); if (state.failed) return ;

        match(input, Token.DOWN, null); if (state.failed) return ;
        pushFollow(FOLLOW_expression_in_synpred96_PhpTree1448);
        expression();

        state._fsp--;
        if (state.failed) return ;

        match(input, Token.UP, null); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred96_PhpTree

    // Delegated rules

    public final boolean synpred88_PhpTree() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred88_PhpTree_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred96_PhpTree() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred96_PhpTree_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred83_PhpTree() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred83_PhpTree_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA49 dfa49 = new DFA49(this);
    static final String DFA49_eotS =
        "\55\uffff";
    static final String DFA49_eofS =
        "\55\uffff";
    static final String DFA49_minS =
        "\1\10\11\uffff\1\0\4\uffff\1\0\35\uffff";
    static final String DFA49_maxS =
        "\1\146\11\uffff\1\0\4\uffff\1\0\35\uffff";
    static final String DFA49_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\uffff\1\13\1\14"+
        "\1\15\1\16\1\uffff\1\20\1\21\1\22\1\23\1\24\1\25\1\26\1\30\1\31"+
        "\1\32\1\33\1\34\1\35\1\36\14\uffff\1\12\1\17\1\27";
    static final String DFA49_specialS =
        "\12\uffff\1\0\4\uffff\1\1\35\uffff}>";
    static final String[] DFA49_transitionS = {
            "\1\35\4\uffff\1\7\1\10\2\35\1\27\1\uffff\1\35\1\uffff\1\20\1"+
            "\12\1\11\1\24\1\16\1\17\1\21\1\23\1\22\1\26\1\4\1\33\1\34\22"+
            "\uffff\1\3\1\1\1\2\1\25\20\uffff\1\35\2\uffff\1\31\1\32\1\6"+
            "\1\uffff\1\30\7\uffff\1\35\1\uffff\1\35\1\uffff\1\5\1\13\1\14"+
            "\1\15\2\uffff\6\35",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "\1\uffff",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA49_eot = DFA.unpackEncodedString(DFA49_eotS);
    static final short[] DFA49_eof = DFA.unpackEncodedString(DFA49_eofS);
    static final char[] DFA49_min = DFA.unpackEncodedStringToUnsignedChars(DFA49_minS);
    static final char[] DFA49_max = DFA.unpackEncodedStringToUnsignedChars(DFA49_maxS);
    static final short[] DFA49_accept = DFA.unpackEncodedString(DFA49_acceptS);
    static final short[] DFA49_special = DFA.unpackEncodedString(DFA49_specialS);
    static final short[][] DFA49_transition;

    static {
        int numStates = DFA49_transitionS.length;
        DFA49_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA49_transition[i] = DFA.unpackEncodedString(DFA49_transitionS[i]);
        }
    }

    class DFA49 extends DFA {

        public DFA49(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 49;
            this.eot = DFA49_eot;
            this.eof = DFA49_eof;
            this.min = DFA49_min;
            this.max = DFA49_max;
            this.accept = DFA49_accept;
            this.special = DFA49_special;
            this.transition = DFA49_transition;
        }
        public String getDescription() {
            return "152:1: expression : ( ^( OR expression expression ) | ^( XOR expression expression ) | ^( AND expression expression ) | ^( EQUALS expression expression ) | ^( AsignmentOperator expression expression ) | ^( IfExpression expression expression expression ) | ^( LOGICAL_OR expression expression ) | ^( LOGICAL_AND expression expression ) | ^( PIPE expression expression ) | ^( AMPERSAND expression expression ) | ^( EqualityOperator expression expression ) | ^( ComparisionOperator expression expression ) | ^( ShiftOperator expression expression ) | ^( PLUS expression expression ) | ^( MINUS expression expression ) | ^( DOT expression expression ) | ^( ASTERISK expression expression ) | ^( FORWARD_SLASH expression expression ) | ^( PERCENT expression expression ) | ^( BANG expression ) | ^( INSTANCE_OF expression expression ) | ^( TILDE expression ) | ^( MINUS expression ) | ^( SUPPRESS_WARNINGS expression ) | ^( Cast PrimitiveType expression ) | ^( Prefix IncrementOperator name ) | ^( Postfix IncrementOperator name ) | ^( NEW nameOrFunctionCall ) | ^( CLONE name ) | atomOrReference );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TreeNodeStream input = (TreeNodeStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA49_10 = input.LA(1);

                         
                        int index49_10 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred83_PhpTree()) ) {s = 42;}

                        else if ( (true) ) {s = 29;}

                         
                        input.seek(index49_10);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA49_15 = input.LA(1);

                         
                        int index49_15 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred88_PhpTree()) ) {s = 43;}

                        else if ( (synpred96_PhpTree()) ) {s = 44;}

                         
                        input.seek(index49_15);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 49, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

    public static final BitSet FOLLOW_statement_in_prog43 = new BitSet(new long[]{0x83FFCF9FFFEBE102L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_BodyString_in_statement56 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Block_in_statement65 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_statement67 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_classDefinition_in_statement82 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_interfaceDefinition_in_statement90 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_complexStatement_in_statement98 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleStatement_in_statement106 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTERFACE_in_interfaceDefinition124 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceDefinition126 = new BitSet(new long[]{0x4400000000000008L,0x0000000000200000L});
    public static final BitSet FOLLOW_interfaceExtends_in_interfaceDefinition128 = new BitSet(new long[]{0x4000000000000008L,0x0000000000200000L});
    public static final BitSet FOLLOW_interfaceMember_in_interfaceDefinition131 = new BitSet(new long[]{0x4000000000000008L,0x0000000000200000L});
    public static final BitSet FOLLOW_Extends_in_interfaceExtends150 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceExtends153 = new BitSet(new long[]{0x0000000000000002L,0x0000000000800000L});
    public static final BitSet FOLLOW_CONST_in_interfaceMember171 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceMember173 = new BitSet(new long[]{0x0000000000000008L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_interfaceMember175 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_Method_in_interfaceMember186 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_Modifiers_in_interfaceMember189 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fieldModifier_in_interfaceMember191 = new BitSet(new long[]{0x1008000000000008L,0x0020000001000000L});
    public static final BitSet FOLLOW_UnquotedString_in_interfaceMember195 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_Params_in_interfaceMember198 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_paramDef_in_interfaceMember200 = new BitSet(new long[]{0x0000000080480008L});
    public static final BitSet FOLLOW_CLASS_in_classDefinition223 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_Modifiers_in_classDefinition226 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_classModifier_in_classDefinition228 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_UnquotedString_in_classDefinition232 = new BitSet(new long[]{0x6C00000000000008L,0x0000000000300000L});
    public static final BitSet FOLLOW_Extends_in_classDefinition236 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_classDefinition238 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_classImplements_in_classDefinition243 = new BitSet(new long[]{0x6000000000000008L,0x0000000000300000L});
    public static final BitSet FOLLOW_classMember_in_classDefinition246 = new BitSet(new long[]{0x6000000000000008L,0x0000000000300000L});
    public static final BitSet FOLLOW_IMPLEMENTS_in_classImplements271 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_classImplements273 = new BitSet(new long[]{0x0000000000000008L,0x0000000000800000L});
    public static final BitSet FOLLOW_Method_in_classMember293 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_Modifiers_in_classMember296 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fieldModifier_in_classMember298 = new BitSet(new long[]{0x1008000000000008L,0x0020000001000000L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember302 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_Params_in_classMember305 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_paramDef_in_classMember307 = new BitSet(new long[]{0x0000000080480008L});
    public static final BitSet FOLLOW_statementBlock_in_classMember311 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_VAR_in_classMember322 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_in_classMember325 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember327 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_atom_in_classMember330 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONST_in_classMember342 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember344 = new BitSet(new long[]{0x0000000000000008L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_classMember346 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_Field_in_classMember357 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_Modifiers_in_classMember360 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_fieldModifier_in_classMember362 = new BitSet(new long[]{0x1008000000000008L,0x0020000001000000L});
    public static final BitSet FOLLOW_DOLLAR_in_classMember367 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_classMember369 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_atom_in_classMember372 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_Block_in_statementBlock396 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_statementBlock398 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_Field_in_fieldDefinition418 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_in_fieldDefinition421 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_fieldDefinition423 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_atom_in_fieldDefinition426 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ABSTRACT_in_classModifier449 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_fieldModifier0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_in_complexStatement496 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_complexStatement498 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_complexStatement500 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_complexStatement502 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_in_complexStatement513 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_forInit_in_complexStatement515 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_forCondition_in_complexStatement517 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_forUpdate_in_complexStatement519 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_complexStatement521 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FOR_EACH_in_complexStatement531 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_complexStatement533 = new BitSet(new long[]{0x83FFCF9FFFEBF100L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_arrayEntry_in_complexStatement535 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_complexStatement537 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WHILE_in_complexStatement547 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_complexStatement549 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_complexStatement551 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DO_in_complexStatement561 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_complexStatement563 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_complexStatement565 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SWITCH_in_complexStatement575 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_complexStatement577 = new BitSet(new long[]{0x0000300000000000L});
    public static final BitSet FOLLOW_cases_in_complexStatement579 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TRY_in_complexStatement589 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_complexStatement591 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_catchStatement_in_complexStatement593 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_THROW_in_complexStatement603 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_throwException_in_complexStatement605 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DECLARE_in_complexStatement615 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_declareList_in_complexStatement617 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_complexStatement619 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_USE_in_complexStatement630 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_atom_in_complexStatement632 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_functionDefinition_in_complexStatement641 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ECHO_in_simpleStatement659 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_simpleStatement661 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_PRINT_in_simpleStatement672 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_simpleStatement674 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_GLOBAL_in_simpleStatement685 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_name_in_simpleStatement687 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_STATIC_in_simpleStatement698 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_simpleStatement700 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_simpleStatement702 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BREAK_in_simpleStatement717 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_Integer_in_simpleStatement719 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CONTINUE_in_simpleStatement730 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_Integer_in_simpleStatement732 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RETURN_in_simpleStatement748 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_simpleStatement750 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_RequireOperator_in_simpleStatement761 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_simpleStatement763 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_expression_in_simpleStatement772 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ForInit_in_forInit791 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_forInit793 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_ForCondition_in_forCondition813 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_forCondition815 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_ForUpdate_in_forUpdate839 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_forUpdate841 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_casestatement_in_cases861 = new BitSet(new long[]{0x0000300000000000L});
    public static final BitSet FOLLOW_defaultcase_in_cases865 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_in_casestatement883 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_casestatement885 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_statement_in_casestatement887 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_DEFAULT_in_defaultcase908 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_defaultcase910 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_CATCH_in_catchStatement930 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_catchException_in_catchStatement932 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94FL});
    public static final BitSet FOLLOW_statement_in_catchStatement934 = new BitSet(new long[]{0x0000000000000008L,0x0000000000000001L});
    public static final BitSet FOLLOW_catchStatement_in_catchStatement936 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_UnquotedString_in_catchException955 = new BitSet(new long[]{0x83FFCF9FFFEBE100L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_variable_in_catchException957 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEW_in_throwException975 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_throwException977 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_throwException979 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_variable_in_throwException988 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DeclareList_in_declareList1006 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_declareList1008 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_FUNCTION_in_functionDefinition1028 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_functionDefinition1030 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_Params_in_functionDefinition1033 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_paramDef_in_functionDefinition1035 = new BitSet(new long[]{0x0000000080480008L});
    public static final BitSet FOLLOW_Block_in_functionDefinition1040 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_statement_in_functionDefinition1042 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_EQUALS_in_paramDef1067 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_paramName_in_paramDef1069 = new BitSet(new long[]{0x0000000000000000L,0x0000007E02000000L});
    public static final BitSet FOLLOW_atom_in_paramDef1071 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_paramName_in_paramDef1081 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DOLLAR_in_paramName1099 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_paramName1101 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AMPERSAND_in_paramName1111 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_DOLLAR_in_paramName1114 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_paramName1116 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_OR_in_expression1140 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1142 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1144 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_XOR_in_expression1154 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1156 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1158 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AND_in_expression1168 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1170 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1172 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EQUALS_in_expression1182 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1184 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1186 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AsignmentOperator_in_expression1196 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1198 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1200 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IfExpression_in_expression1210 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1212 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1214 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1216 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_OR_in_expression1226 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1228 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1230 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LOGICAL_AND_in_expression1240 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1242 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1244 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PIPE_in_expression1254 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1256 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1258 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_AMPERSAND_in_expression1268 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1270 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1272 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EqualityOperator_in_expression1282 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1284 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1286 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ComparisionOperator_in_expression1296 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1298 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1300 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ShiftOperator_in_expression1310 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1312 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1314 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PLUS_in_expression1324 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1326 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1328 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_in_expression1338 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1340 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1342 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOT_in_expression1352 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1354 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1356 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ASTERISK_in_expression1366 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1368 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1370 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FORWARD_SLASH_in_expression1380 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1382 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1384 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_PERCENT_in_expression1394 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1396 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1398 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_BANG_in_expression1408 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1410 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INSTANCE_OF_in_expression1420 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1422 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1424 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TILDE_in_expression1434 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1436 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_in_expression1446 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1448 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_SUPPRESS_WARNINGS_in_expression1459 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_expression1461 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_Cast_in_expression1471 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_PrimitiveType_in_expression1473 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_expression1475 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_Prefix_in_expression1485 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IncrementOperator_in_expression1487 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_name_in_expression1489 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_Postfix_in_expression1499 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_IncrementOperator_in_expression1501 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_name_in_expression1503 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NEW_in_expression1513 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_nameOrFunctionCall_in_expression1515 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLONE_in_expression1525 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_name_in_expression1527 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_atomOrReference_in_expression1537 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_in_atomOrReference1555 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reference_in_atomOrReference1563 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Array_in_arrayDeclaration1581 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_arrayEntry_in_arrayDeclaration1583 = new BitSet(new long[]{0x83FFCF9FFFEBF108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_keyValuePair_in_arrayEntry1603 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_arrayEntry1607 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_ASSIGN_in_keyValuePair1626 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_keyValuePair1628 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_SingleQuotedString_in_atom1642 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DoubleQuotedString_in_atom1646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_HereDoc_in_atom1650 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Integer_in_atom1654 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Real_in_atom1658 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Boolean_in_atom1662 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_arrayDeclaration_in_atom1666 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AMPERSAND_in_reference1685 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_nameOrFunctionCall_in_reference1687 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_nameOrFunctionCall_in_reference1696 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_Apply_in_nameOrFunctionCall1714 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_name_in_nameOrFunctionCall1716 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_nameOrFunctionCall1718 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_name_in_nameOrFunctionCall1728 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_staticMemberAccess_in_name1740 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_memberAccess_in_name1748 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_name1756 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CLASS_MEMBER_in_staticMemberAccess1778 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_UnquotedString_in_staticMemberAccess1780 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_variable_in_staticMemberAccess1783 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_OPEN_SQUARE_BRACE_in_memberAccess1802 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_memberAccess1804 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_memberAccess1806 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INSTANCE_MEMBER_in_memberAccess1816 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_memberAccess1818 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_UnquotedString_in_memberAccess1820 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_DOLLAR_in_variable1843 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_variable_in_variable1845 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_UnquotedString_in_variable1854 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AMPERSAND_in_synpred83_PhpTree1268 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_synpred83_PhpTree1270 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_synpred83_PhpTree1272 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_in_synpred88_PhpTree1338 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_synpred88_PhpTree1340 = new BitSet(new long[]{0x83FFCF9FFFEBE108L,0x0000007E7EC0B94EL});
    public static final BitSet FOLLOW_expression_in_synpred88_PhpTree1342 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_MINUS_in_synpred96_PhpTree1446 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expression_in_synpred96_PhpTree1448 = new BitSet(new long[]{0x0000000000000008L});

}
